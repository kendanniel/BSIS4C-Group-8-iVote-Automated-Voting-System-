<?php
session_start();
require '../inc/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM voters WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $voter = $result->fetch_assoc();

        if (password_verify($password, $voter['password'])) {
            $_SESSION['voter_id'] = $voter['id'];
            $_SESSION['voter_name'] = $voter['firstname'] . ' ' . $voter['lastname'];

            if ($voter['password_changed'] == 0) {
                echo json_encode(['status' => 'success', 'redirect' => 'change_password.php']);
            } else {
                echo json_encode(['status' => 'success', 'redirect' => 'dashboard.php']);
            }
            exit;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Incorrect password!']);
            exit;
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Student ID not found!']);
        exit;
    }
}

echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
