<?php
require '../inc/db.php';
header('Content-Type: application/json');

$student_id = $_GET['student_id'] ?? '';

if ($student_id === '') {
    echo json_encode(['success' => false, 'error' => 'Student ID is required']);
    exit();
}

// Idinagdag ang strand at section sa SELECT
$stmt = $conn->prepare("SELECT firstname, lastname, grade_level, strand, section FROM voters WHERE student_id = ?");
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if ($result) {
    echo json_encode([
        'success' => true,
        'firstname' => $result['firstname'],
        'lastname' => $result['lastname'],
        'grade_level' => $result['grade_level'], // Iniba ko ang key para malinis
        'strand' => $result['strand'],
        'section' => $result['section']
    ]);
} else {
    echo json_encode(['success' => false, 'error' => 'Student not found']);
}