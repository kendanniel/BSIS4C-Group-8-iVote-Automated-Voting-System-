<?php
session_start();
if (!isset($_SESSION['voter_id'])) {
  header("Location: voter_login.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Voting Guidelines | iVote</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  background-color: #f4f4f9;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.container {
  background-color: #1f1f5e;
  color: #000;
  border-radius: 12px;
  padding: 30px;
  width: 420px;
}
.inner {
  background: #fff;
  padding: 25px;
  border-radius: 10px;
  text-align: justify;
}
h2 {
  color: #ffcc00;
  text-align: center;
  font-weight: bold;
  font-size: 26px;
}
p {
  margin-bottom: 12px;
  font-size: 14px;
  line-height: 1.5;
}
input[type="checkbox"] {
  margin-top: 15px;
}
button {
  background-color: #4a3aff;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 10px 0;
  width: 100%;
  font-weight: bold;
  margin-top: 15px;
  cursor: pointer;
  transition: 0.3s;
}
button:disabled {
  background-color: #999;
  cursor: not-allowed;
}
</style>
</head>
<body>
  <div class="container">
    <div class="inner">
      <h2>iVote</h2>
      <p>Voting is anonymous and confidential. Your identity will not be linked to your ballot.</p>
      <p>Do not share your login credentials with anyone.</p>
      <p>Once submitted, your vote cannot be changed.</p>
      <p>Attempting to vote multiple times or tampering with the system is strictly prohibited.</p>
      <p>Exercise your right responsibly—vote based on the candidates’ platforms and qualifications.</p>
      <p>Respect the election process and avoid spreading false information.</p>
      <p>Report any technical issues or suspicious activity to the Election Committee immediately.</p>

      <label>
        <input type="checkbox" id="agree"> Check here to indicate that you have read the guidelines of iVote System
      </label>

      <button id="proceedBtn" disabled onclick="window.location.href='vote.php'">PROCEED</button>
    </div>
  </div>

  <script>
    const checkbox = document.getElementById('agree');
    const proceedBtn = document.getElementById('proceedBtn');
    checkbox.addEventListener('change', () => {
      proceedBtn.disabled = !checkbox.checked;
    });
  </script>
</body>
</html>
