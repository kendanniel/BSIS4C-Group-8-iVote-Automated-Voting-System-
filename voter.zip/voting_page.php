<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit();
}

$voter_id = (int) $_SESSION['voter_id'];

date_default_timezone_set('Asia/Manila');
$now = date('Y-m-d H:i:s');

// KUNIN ANG GRADE LEVEL NG VOTER
$voter_data = $conn->query("SELECT grade_level FROM voters WHERE id = $voter_id")->fetch_assoc();
$voter_grade = $voter_data['grade_level']; // Halimbawa: 8

/* GET CURRENT ELECTION */
$election = $conn->query("
SELECT * FROM elections
ORDER BY created_at DESC
LIMIT 1
")->fetch_assoc();

if(!$election){
    header("Location: dashboard.php");
    exit();
}

/* CHECK IF ELECTION IS ACTIVE */
if(!($now >= $election['start_datetime'] && $now <= $election['end_datetime'])){
    header("Location: dashboard.php");
    exit();
}

$election_id = $election['id'];


// Redirect if already voted
$checkVote = $conn->prepare("SELECT id FROM votes WHERE voter_id=? AND election_id=?");
$checkVote->bind_param("ii", $voter_id, $election_id);
$checkVote->execute();
$result = $checkVote->get_result();
if($result && $result->num_rows > 0) {
    header("Location: dashboard.php?already_voted=1");
    exit();
}

// // Fetch positions in desired order
// $desired_order = ['PRESIDENT','VICE PRESIDENT','SECRETARY','TREASURER'];
// $positions = $conn->query("SELECT * FROM positions");
// $all_positions = [];
// while($pos = $positions->fetch_assoc()) $all_positions[$pos['name']] = $pos;
// $sorted_positions = [];
// foreach($desired_order as $name){
//     if(isset($all_positions[$name])) {
//         $sorted_positions[] = $all_positions[$name];
//         unset($all_positions[$name]);
//     }
// }
// foreach($all_positions as $p) $sorted_positions[] = $p;

// Fetch positions in desired order
$desired_order = ['PRESIDENT','VICE PRESIDENT','SECRETARY','TREASURER'];
$positions = $conn->query("SELECT * FROM positions");
$all_positions = [];
while($pos = $positions->fetch_assoc()) $all_positions[$pos['name']] = $pos;

$sorted_positions = [];

// 1. Unahin ang main positions (Pres, VP, etc.)
foreach($desired_order as $name){
    if(isset($all_positions[$name])) {
        $sorted_positions[] = $all_positions[$name];
        unset($all_positions[$name]);
    }
}

// 2. I-filter ang natitirang positions (Grade Reps)
foreach($all_positions as $name => $p) {
    // Check kung ang position name ay naglalaman ng salitang "GRADE"
    if (stripos($name, 'GRADE') !== false) {
        // Ipakita lang kung ang grade level ng voter ay nasa loob ng name ng position
        // Halimbawa: Kung $voter_grade ay 8, ipapakita ang "GRADE 8 REPRESENTATIVE"
        if (stripos($name, (string)$voter_grade) !== false) {
            $sorted_positions[] = $p;
        }
    } else {
        // Para sa ibang positions na wala sa desired_order at walang salitang "GRADE"
        $sorted_positions[] = $p;
    }
}


// Handle submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->begin_transaction();
    try {
        foreach($_POST as $position_id => $candidate_id) {
            // $stmt = $conn->prepare("INSERT INTO votes (voter_id, candidate_id, position_id, created_at) VALUES (?,?,?,NOW())");
            $stmt = $conn->prepare("
            INSERT INTO votes (voter_id, candidate_id, position_id, election_id, created_at)
            VALUES (?,?,?,?,NOW())
            ");
            $pid = (int)$position_id; $cid = (int)$candidate_id;
            $stmt->bind_param("iiii",$voter_id,$cid,$pid,$election_id);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();
        header("Location: dashboard.php?success=1");
        exit();
    } catch(Exception $e) {
        $conn->rollback();
        header("Location: voting_page.php?error=1");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Vote Now | iVote</title>
<link rel="stylesheet" href="../voter/dashboard.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
<style>
/* ===== RESET & BASE ===== */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', sans-serif;
  background: #0d1b3e;
  min-height: 100vh;
  padding: 0;
  position: relative;
  overflow-x: hidden;
}

/* ===== BACKGROUND PATTERN ===== */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 60% at 20% 10%, rgba(79,70,229,0.25) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 80% 90%, rgba(38,107,197,0.2) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 60% 40%, rgba(120,114,250,0.1) 0%, transparent 60%);
  pointer-events: none;
  z-index: 0;
}

/* ===== PAGE WRAPPER ===== */
.page-wrap {
  position: relative;
  z-index: 1;
  max-width: 880px;
  margin: 0 auto;
  padding: 36px 20px 60px;
}

/* ===== HEADER ===== */
.vote-header {
  text-align: center;
  margin-bottom: 40px;
  animation: fadeDown 0.6s ease both;
}

.vote-header img {
  height: 72px;
  margin-bottom: 16px;
  filter: drop-shadow(0 4px 16px rgba(120,114,250,0.4));
}

.vote-header-eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(79,70,229,0.18);
  border: 1px solid rgba(120,114,250,0.35);
  color: #a5b4fc;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1.4px;
  text-transform: uppercase;
  padding: 5px 14px;
  border-radius: 20px;
  margin-bottom: 14px;
}

.vote-header-eyebrow::before {
  content: '';
  width: 7px; height: 7px;
  border-radius: 50%;
  background: #4ade80;
  box-shadow: 0 0 8px #4ade80;
  animation: pulse 1.8s ease-in-out infinite;
}

.vote-header h1 {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 32px;
  font-weight: 700;
  color: #f1f5f9;
  line-height: 1.2;
  margin-bottom: 10px;
  text-shadow: 0 2px 20px rgba(79,70,229,0.3);
}

.vote-header p {
  color: #94a3b8;
  font-size: 14.5px;
  line-height: 1.6;
}

/* ===== PROGRESS BAR ===== */
.progress-bar-wrap {
  background: rgba(255,255,255,0.06);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  padding: 14px 20px;
  margin-bottom: 30px;
  display: flex;
  align-items: center;
  gap: 14px;
  animation: fadeDown 0.6s 0.1s ease both;
}

.progress-label {
  color: #94a3b8;
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
}

.progress-track {
  flex: 1;
  height: 6px;
  background: rgba(255,255,255,0.1);
  border-radius: 99px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  width: 0%;
  background: linear-gradient(90deg, #4f46e5, #7872fa);
  border-radius: 99px;
  transition: width 0.4s ease;
}

.progress-count {
  color: #7872fa;
  font-size: 12px;
  font-weight: 700;
  white-space: nowrap;
}

/* ===== ERROR BANNER ===== */
.error-banner {
  background: rgba(239,68,68,0.12);
  border: 1px solid rgba(239,68,68,0.35);
  color: #fca5a5;
  border-radius: 10px;
  padding: 12px 18px;
  margin-bottom: 24px;
  font-size: 13.5px;
  display: flex;
  align-items: center;
  gap: 10px;
}

/* ===== POSITION BLOCK ===== */
.position-block {
  margin-bottom: 28px;
  animation: fadeUp 0.5s ease both;
}

.position-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
}

.position-icon {
  width: 38px; height: 38px;
  background: linear-gradient(135deg, #4f46e5, #7872fa);
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(79,70,229,0.35);
}

.position-title {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 18px;
  font-weight: 700;
  color: #e2e8f0;
  flex: 1;
}

.position-instruction {
  font-size: 11.5px;
  color: #64748b;
  font-weight: 500;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.08);
  padding: 3px 10px;
  border-radius: 20px;
  white-space: nowrap;
}

/* ===== CANDIDATE GRID ===== */
.candidates {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
  gap: 14px;
}

/* ===== CANDIDATE CARD ===== */
.candidate {
  position: relative;
  cursor: pointer;
  border-radius: 14px;
  overflow: hidden;
  background: rgba(255,255,255,0.04);
  border: 1.5px solid rgba(255,255,255,0.09);
  transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease, background 0.2s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.candidate:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0,0,0,0.3);
  border-color: rgba(120,114,250,0.4);
  background: rgba(79,70,229,0.08);
}

/* Selected state via JS class */
.candidate.selected {
  border-color: #7872fa !important;
  background: rgba(79,70,229,0.15) !important;
  box-shadow: 0 0 0 3px rgba(120,114,250,0.25), 0 12px 32px rgba(79,70,229,0.2) !important;
}

.candidate.selected .candidate-check {
  opacity: 1;
  transform: scale(1);
}

/* Hide the native radio */
.candidate input[type=radio] {
  position: absolute;
  opacity: 0;
  pointer-events: none;
  width: 0; height: 0;
}

/* Checkmark badge */
.candidate-check {
  position: absolute;
  top: 10px; right: 10px;
  width: 24px; height: 24px;
  background: #7872fa;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  opacity: 0;
  transform: scale(0.6);
  transition: opacity 0.2s ease, transform 0.2s ease;
  box-shadow: 0 2px 8px rgba(120,114,250,0.5);
  z-index: 2;
}

.candidate-check svg {
  width: 13px; height: 13px; fill: #fff;
}

/* Photo banner */
.candidate-photo-wrap {
  width: 100%;
  padding: 20px 20px 12px;
  background: linear-gradient(160deg, rgba(30,58,95,0.6) 0%, rgba(15,23,42,0.4) 100%);
  display: flex;
  justify-content: center;
}

.candidate-photo-wrap img {
  width: 84px;
  height: 84px;
  border-radius: 50%;
  object-fit: cover;
  border: 2.5px solid rgba(255,255,255,0.2);
  box-shadow: 0 4px 16px rgba(0,0,0,0.35);
  transition: border-color 0.2s ease;
}

.candidate.selected .candidate-photo-wrap img {
  border-color: #7872fa;
}

/* Card body */
.candidate-body {
  padding: 10px 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  width: 100%;
}

.candidate-name {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 13.5px;
  font-weight: 700;
  color: #f1f5f9;
  line-height: 1.3;
}

.candidate-party {
  font-size: 10.5px;
  font-weight: 600;
  letter-spacing: 0.6px;
  color: #a5b4fc;
  text-transform: uppercase;
}

.candidate-bio {
  font-size: 11px;
  color: #64748b;
  line-height: 1.55;
  margin-top: 2px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* Empty position */
.no-candidates {
  background: rgba(255,255,255,0.03);
  border: 1.5px dashed rgba(255,255,255,0.1);
  border-radius: 12px;
  padding: 24px;
  text-align: center;
  color: #475569;
  font-size: 13px;
  font-style: italic;
}

/* ===== SUBMIT SECTION ===== */
.submit-section {
  margin-top: 36px;
  text-align: center;
  animation: fadeUp 0.5s 0.3s ease both;
}

.submit-note {
  color: #64748b;
  font-size: 12.5px;
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.vote-submit {
  background: linear-gradient(135deg, #4f46e5 0%, #7872fa 100%);
  color: #fff;
  border: none;
  padding: 15px 52px;
  border-radius: 40px;
  font-family: 'DM Sans', sans-serif;
  font-weight: 700;
  font-size: 16px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 10px;
  letter-spacing: 0.4px;
  box-shadow: 0 8px 28px rgba(79,70,229,0.45);
  transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}

.vote-submit:hover {
  background: linear-gradient(135deg, #eae128 0%, #f5e840 100%);
  color: #221f5d;
  transform: translateY(-2px);
  box-shadow: 0 12px 36px rgba(234,225,40,0.35);
}

.vote-submit:active {
  transform: translateY(0);
}

/* ===== ANIMATIONS ===== */
@keyframes fadeDown {
  from { opacity: 0; transform: translateY(-16px); }
  to   { opacity: 1; transform: translateY(0); }
}

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(18px); }
  to   { opacity: 1; transform: translateY(0); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.4; }
}
</style>
</head>
<body>
<div class="page-wrap">

  <!-- Header -->
  <div class="vote-header">
    <img src="srnhs-logo.png" alt="logo">
    <div>
      <div class="vote-header-eyebrow">Election Now Open</div>
    </div>
    <h1>Student Council Election<br>S.Y. 2025–2026</h1>
    <p>Select one candidate per position. Review your choices before submitting.</p>
  </div>

  <?php if(isset($_GET['error'])): ?>
  <div class="error-banner">
    <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="#fca5a5"><path d="M480-280q17 0 28.5-11.5T520-320q0-17-11.5-28.5T480-360q-17 0-28.5 11.5T440-320q0 17 11.5 28.5T480-280Zm-40-160h80v-240h-80v240Zm40 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Z"/></svg>
    Something went wrong submitting your vote. Please try again.
  </div>
  <?php endif; ?>

  <!-- Progress bar -->
  <div class="progress-bar-wrap">
    <span class="progress-label">Positions filled</span>
    <div class="progress-track">
      <div class="progress-fill" id="progressFill"></div>
    </div>
    <span class="progress-count" id="progressCount">0 / <?= count($sorted_positions) ?></span>
  </div>

  <!-- Form -->
  <form method="POST" id="voteForm">
    <?php
    $posIndex = 0;
    foreach($sorted_positions as $pos):
      $pid = (int)$pos['id'];
      $pname = htmlspecialchars($pos['name']);
      $delay = round($posIndex * 0.07, 2);
      $posIndex++;
    ?>
    <div class="position-block" style="animation-delay:<?= $delay ?>s;">

      <div class="position-header">
        <div class="position-icon">
          <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#fff"><path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Z"/></svg>
        </div>
        <span class="position-title"><?= $pname ?></span>
        <span class="position-instruction">Vote for 1</span>
      </div>

      <div class="candidates" id="group-<?= $pid ?>">
        <?php
        $cands = $conn->query("
            SELECT c.*, p.name AS party_name
            FROM candidates c
            LEFT JOIN partylist p ON c.partylist_id=p.id
            WHERE c.position_id={$pid}
            AND c.status='approved'
            AND c.election_id={$election_id}
        ");
        $candCount = 0;
        while($c = $cands->fetch_assoc()):
          $cid = (int)$c['id'];
          $photo = !empty($c['photo']) ? $c['photo'] : 'default.png';
          $fullname = htmlspecialchars(trim($c['firstname'].' '.$c['lastname']));
          $party = htmlspecialchars($c['party_name'] ?? '');
          $bio = htmlspecialchars($c['biography'] ?? '');
          $candCount++;
        ?>
        <label class="candidate" onclick="selectCandidate(this, <?= $pid ?>)">
          <input type="radio" name="<?= $pid ?>" value="<?= $cid ?>" required>

          <!-- Check badge -->
          <span class="candidate-check">
            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          </span>

          <!-- Photo -->
          <div class="candidate-photo-wrap">
            <img src="../uploads/<?= $photo ?>" alt="<?= $fullname ?>">
          </div>

          <!-- Info -->
          <div class="candidate-body">
            <div class="candidate-name"><?= $fullname ?></div>
            <?php if($party !== ''): ?>
              <div class="candidate-party"><?= $party ?></div>
            <?php endif; ?>
            <?php if($bio !== ''): ?>
              <div class="candidate-bio"><?= $bio ?></div>
            <?php endif; ?>
          </div>
        </label>
        <?php endwhile; ?>

        <?php if($candCount === 0): ?>
        <div class="no-candidates">No approved candidates for this position.</div>
        <?php endif; ?>
      </div>

    </div>
    <?php endforeach; ?>

    <!-- Submit -->
    <div class="submit-section">
      <div class="submit-note">
        <svg xmlns="http://www.w3.org/2000/svg" height="15px" viewBox="0 -960 960 960" width="15px" fill="#64748b"><path d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 200h80v-240h-80v240Zm0-320h80v-80h-80v80Z"/></svg>
        Once submitted, your vote cannot be changed.
      </div>
      <button type="submit" class="vote-submit">
        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="currentColor"><path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/></svg>
        Submit My Vote
      </button>
    </div>

  </form>
</div>

<script>
const totalPositions = <?= count($sorted_positions) ?>;
const filled = {};

function selectCandidate(label, positionId) {
  // Deselect siblings
  const group = document.getElementById('group-' + positionId);
  group.querySelectorAll('.candidate').forEach(c => c.classList.remove('selected'));

  // Select clicked
  label.classList.add('selected');
  label.querySelector('input[type=radio]').checked = true;

  // Track filled
  filled[positionId] = true;
  updateProgress();
}

function updateProgress() {
  const count = Object.keys(filled).length;
  const pct = (count / totalPositions) * 100;
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressCount').textContent = count + ' / ' + totalPositions;
}

// Restore selection state if user navigates back
document.querySelectorAll('input[type=radio]').forEach(radio => {
  if (radio.checked) {
    const label = radio.closest('.candidate');
    if (label) {
      label.classList.add('selected');
      const pid = radio.name;
      filled[pid] = true;
    }
  }
});
updateProgress();
</script>
</body>
</html>