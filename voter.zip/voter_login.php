<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>iVote | Voter's Login</title>
  <link rel="stylesheet" href="voter_login.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
  <div class="login-container">
    <!-- LEFT PANEL -->
    <div class="left-panel">
      <img src="srnhs-logo.png" alt="School Logo">
    </div>

    <!-- RIGHT PANEL -->
    <div class="right-panel">
      <div class="logo-text">
        <small>i</small><span>Vote</span>
      </div>

      <!-- LOGIN FORM -->
      <form id="loginForm">
        <div class="input-group">
          <i class="fa fa-user"></i>
          <input type="text" name="student_id" placeholder="Student ID" required>
        </div>

        <div class="input-group">
          <i class="fa fa-lock"></i>
          <input type="password" name="password" placeholder="Password" required>
        </div>

        <button type="submit" class="login-btn">LOG IN</button>
      </form>
    </div>
  </div>

  <script>
  document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Stop page reload
    const formData = new FormData(this);

    fetch('voter_login_process.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      if (data.status === 'success') {
        window.location.href = data.redirect; // Go to next page
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Login Failed',
          text: data.message,
          confirmButtonColor: '#d33',
          background: '#fff'
        });
      }
    })
    .catch(() => {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Something went wrong. Please try again.',
      });
    });
  });
  </script>
</body>
</html>
