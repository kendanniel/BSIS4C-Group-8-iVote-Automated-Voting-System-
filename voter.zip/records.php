<?php
session_start();
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit;
}

$voter_id = $_SESSION['voter_id'];
$voter_name = isset($_SESSION['voter_name']) ? $_SESSION['voter_name'] : 'Voter';

// Check if voter has voted
// Check if voter has voted IN THE CURRENT ACTIVE ELECTION
$voteCheck = $conn->prepare("SELECT id FROM votes WHERE voter_id = ? AND is_archived = 0");
$voteCheck->bind_param("i", $voter_id);
$voteCheck->execute();
$voteResult = $voteCheck->get_result();
$hasVoted = ($voteResult && $voteResult->num_rows > 0);

// Fetch previous votes if voter has voted (Filtered by current non-archived election)
$votes = [];
if ($hasVoted) {
    $query = "
        SELECT 
            p.name AS position_name, 
            c.firstname, 
            c.lastname, 
            c.biography AS platform, 
            c.photo AS image
        FROM votes v
        JOIN candidates c ON v.candidate_id = c.id
        JOIN positions p ON c.position_id = p.id
        WHERE v.voter_id = ? 
          AND v.is_archived = 0  -- Eto ang mahalaga: para active election lang ang makita
        ORDER BY p.position_order ASC
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $voter_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $votes = $result->fetch_all(MYSQLI_ASSOC);
    
    // I-update ang $hasVoted base sa active votes lang
    $hasVoted = (count($votes) > 0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Record | iVote</title>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
 body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: #f1f5f9;
            overflow-x: hidden;
        }

        /* --- SIDEBAR LOGIC --- */
        .sidebar {
            width: 240px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg,#0f172a,#1e293b);
            padding-top: 20px;
            box-shadow: 4px 0 15px rgba(0,0,0,0.4);
            color: white;
            transition: 0.3s ease;
            z-index: 1000;
        }

        .main-content {
            margin-left: 240px;
            padding: 20px;
            transition: 0.3s ease;
            min-height: 100vh;
        }


/* Mobile Nav Toggle Styles */
.mobile-nav-bar {
  display: none;
  background: #0f172a;
  color: white;
  padding: 15px;
  position: sticky;
  top: 0;
  z-index: 1100;
  justify-content: space-between;
  align-items: center;
}

.hamburger {
  cursor: pointer;
  font-size: 24px;
}

@media (max-width: 768px) {
  .sidebar {
    left: -240px;
  }
  .sidebar.active {
    left: 0;
  }
  .main-content {
    margin-left: 0;
    padding: 15px;
  }
  .mobile-nav-bar {
    display: flex;
  }
  .record-banner {
    flex-direction: column;
    text-align: center;
    padding: 20px !important;
  }
  .record-banner-status {
    align-items: center !important;
    margin-left: 0 !important;
    width: 100%;
  }
}

/* Navigation Buttons */
.nav-btn {
  padding: 12px 15px;
  border-radius: 10px;
  cursor: pointer;
  background: #1e293b;
  transition: 0.25s;
  font-weight: 500;
  color: white;
  margin: 0 15px 10px 15px;
  display: flex;
  align-items: center;
  gap: 10px;
  text-decoration: none;
}

.nav-btn:hover {
  background: #334155;
  transform: translateX(5px);
}

.nav-btn.active {
  background: #3b82f6;
  box-shadow: 0 0 10px rgba(59,130,246,0.7);
}

/* Original Selectors Restored */
.record-container {
  background: #f2f2f2;
  padding: 25px;
  border-radius: 15px;
  max-width: 900px;
  margin: 40px auto;
}
.vote-table {
  width: 100%;
  border-collapse: collapse;
  border: 2px solid #333;
  background: white;
}
.vote-table td {
  border: 1px solid #333;
  padding: 12px;
}

/* Professional Style Classes */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(18px); }
  to   { opacity: 1; transform: translateY(0); }
}

.records-page-inner {
  max-width: 860px;
  margin: 0 auto;
}

.record-banner {
  background: linear-gradient(135deg, #1e3a5f 0%, #266bc5 100%);
  border-radius: 18px;
  padding: 28px 32px;
  display: flex;
  align-items: center;
  gap: 22px;
  margin-bottom: 28px;
  box-shadow: 0 8px 28px rgba(38,107,197,0.2);
  animation: fadeInUp 0.5s ease both;
}

.record-banner-icon {
  width: 56px; height: 56px;
  background: rgba(255,255,255,0.15);
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}

.record-banner-text h2 {
  font-family: 'Playfair Display', serif;
  font-size: 22px; color: #fff; margin: 0;
}

.record-banner-text p {
  color: rgba(255,255,255,0.72); font-size: 13.5px; margin: 0;
}

.record-banner-status {
  margin-left: auto; display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
}

.status-pill {
  display: inline-flex; align-items: center; gap: 7px; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 700;
}

.status-pill.voted { background: rgba(74,222,128,0.18); border: 1px solid rgba(74,222,128,0.4); color: #86efac; }
.status-pill.not-voted { background: rgba(251,191,36,0.15); border: 1px solid rgba(251,191,36,0.35); color: #fde68a; }

.cert-action-btn {
  display: inline-flex; align-items: center; gap: 7px; padding: 9px 18px; border-radius: 25px; border: none; font-weight: 700; cursor: pointer; transition: 0.25s;
}
.cert-action-btn.enabled { background: #fff; color: #1e3a5f; }
.cert-action-btn.enabled:hover { background: #eae128; color: #221f5d; }
.cert-action-btn.disabled { background: rgba(255,255,255,0.12); color: rgba(255,255,255,0.35); cursor: not-allowed; }

.vote-card {
  background: #ffffff; border-radius: 14px; border: 1px solid #e8eef5; display: flex; align-items: center; margin-bottom: 12px; overflow: hidden;
}

.vote-card-position {
  background: linear-gradient(160deg, #1e3a5f, #266bc5);
  color: #fff; writing-mode: vertical-rl; transform: rotate(180deg);
  font-size: 10px; font-weight: 700; padding: 18px 10px; display: flex; align-items: center; justify-content: center;
}

.vote-card-candidate { display: flex; align-items: center; gap: 18px; padding: 18px 22px; flex: 1; }
.vote-card-photo { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; border: 2.5px solid #e2e8f0; }
.vote-card-name { font-family: 'Playfair Display', serif; font-size: 16px; font-weight: 700; color: #1e293b; }
.vote-card-bio { font-size: 12.5px; color: #64748b; line-height: 1.55; }
.vote-card-check { width: 32px; height: 32px; background: #4f46e5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-left: auto; }
</style>
</head>
<body>

<div class="mobile-nav-bar">
    <div style="display:flex; align-items:center; gap:10px;">
        <img src="srnhs-logo.png" style="width:35px;">
        <span style="font-weight:700; font-size:14px;">SAN ROQUE NHS</span>
    </div>
    <div class="hamburger" onclick="toggleSidebar()">☰</div>
</div>

<div class="sidebar" id="sidebar">
    <div style="text-align:center;margin-bottom:30px;">
        <img src="srnhs-logo.png" style="width:70px;">
        <h3 style="margin-top:10px; font-size: 18px;">SAN ROQUE NHS</h3>
    </div>

    <div style="padding:0;">
        <div class="nav-btn" onclick="location.href='dashboard.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> 
            Dashboard
        </div>
        <div class="nav-btn" onclick="location.href='profile.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M400-80v-280h-80v-240q0-33 23.5-56.5T400-680h160q33 0 56.5 23.5T640-600v240h-80v280H400Zm80-640q-33 0-56.5-23.5T400-800q0-33 23.5-56.5T480-880q33 0 56.5 23.5T560-800q0 33-23.5 56.5T480-720Z"/></svg> 
            My Profile
        </div>
        <div class="nav-btn active" onclick="location.href='records.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M280-280h280v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80Zm-80 480q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> 
            Records
        </div>
        <div class="nav-btn" onclick="confirmLogout()">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> 
            Logout
        </div>
    </div>
</div>


<div class="main-content">
  <header style="display:flex;justify-content:flex-end;align-items:center;flex-wrap:wrap;margin-bottom:20px;">
     <div style="font-size:13px; text-align:right; color:#64748b;"><?php date_default_timezone_set('Asia/Manila'); ?><?php echo date("F d, Y") . "<br>" . date("g:i A"); ?></div>
  </header>

  <div class="records-page-inner">
    <div class="record-banner">
      <div class="record-banner-icon">
        <svg xmlns="http://www.w3.org/2000/svg" height="28px" viewBox="0 -960 960 960" width="28px" fill="#fff"><path d="M280-280h280v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80Zm-80 480q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg>
      </div>
      <div class="record-banner-text">
        <h2>Voting Record</h2>
        <p>
          <?php if($hasVoted): ?>
            Votes securely recorded. Positions voted: <strong style="color:#fff;"><?= count($votes) ?></strong>
          <?php else: ?>
            You haven't cast your vote yet.
          <?php endif; ?>
        </p>
      </div>
      <div class="record-banner-status">
        <?php if($hasVoted): ?>
          <span class="status-pill voted">Vote Submitted</span>
        <?php else: ?>
          <span class="status-pill not-voted">Not Yet Voted</span>
        <?php endif; ?>

        <button class="cert-action-btn <?= $hasVoted ? 'enabled' : 'disabled' ?>" 
                <?= $hasVoted ? "onclick=\"window.location.href='certificate.php'\"" : 'disabled' ?>>
          Certificate
        </button>
      </div>
    </div>

    <?php if ($hasVoted && count($votes) > 0): ?>
      <div class="vote-cards-list">
       <?php foreach ($votes as $index => $vote): 
    // --- LOGIC PARA SA DISPLAY ---
    if (trim(strtolower($vote['firstname'])) == 'abstain') {
        $displayName = "ABSTAIN";
        $displayPhoto = "images/abstain_logo.png"; // Siguraduhin na may ganito kang file o gumamit ng default
        $displayPlatform = "You chose not to vote for any candidate in this position.";
    } else {
        $displayName = htmlspecialchars($vote['firstname'] . ' ' . $vote['lastname']);
        // Path papunta sa Admin folder
        $photoPath = '../admin/uploads/' . $vote['image'];
        $displayPhoto = (!empty($vote['image']) && file_exists($photoPath)) ? $photoPath : 'images/default.png';
        $displayPlatform = htmlspecialchars($vote['platform']);
    }
    
    $delay = round($index * 0.05, 2);
?>
       <div class="vote-card" style="animation: fadeInUp 0.45s <?= $delay ?>s ease both;">
  <div class="vote-card-position"><?= htmlspecialchars(strtoupper($vote['position_name'])) ?></div>
  <div class="vote-card-candidate">
    <img class="vote-card-photo" src="<?= $displayPhoto ?>" alt="Candidate">
    <div class="vote-card-info">
      <div class="vote-card-name"><?= $displayName ?></div>
      <?php if (!empty($displayPlatform)): ?>
        <div class="vote-card-bio"><?= $displayPlatform ?></div>
      <?php endif; ?>
    </div>
    <div class="vote-card-check">
      <svg xmlns="http://www.w3.org/2000/svg" height="17px" viewBox="0 -960 960 960" width="17px" fill="#fff"><path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/></svg>
    </div>
  </div>
</div>
<?php endforeach; ?>
      </div>
    <?php else: ?>
      <div style="text-align:center; padding: 50px 20px; background:white; border-radius:15px; border: 2px dashed #cbd5e1;">
          <h3>No records found.</h3>
          <p>Please vote first to see your records here.</p>
          <a href="dashboard.php" style="color: #4f46e5; font-weight:bold;">Go to Dashboard</a>
      </div>
    <?php endif; ?>

    <div class="record-container" style="display:none;">
      <h2>Your Previous Vote</h2>
      <button class="cert-btn <?= $hasVoted ? 'enabled' : 'disabled' ?>" <?= $hasVoted ? "onclick=\"window.location.href='certificate.php'\"" : 'disabled' ?>>Voter's Certificate</button>
    </div>
  </div>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
}

// Added SweetAlert Logout Confirmation
function confirmLogout() {
    Swal.fire({
        title: 'Are you sure?',
        text: "You will be logged out of your account.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3b82f6',
        cancelButtonColor: '#64748b',
        confirmButtonText: 'Yes, logout',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php';
        }
    });
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    var sidebar = document.getElementById('sidebar');
    var hamburger = document.querySelector('.hamburger');
    if (window.innerWidth <= 768 && sidebar && !sidebar.contains(event.target) && event.target !== hamburger) {
        sidebar.classList.remove('active');
    }
});
</script>
</body>
</html>