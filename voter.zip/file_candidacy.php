<?php
session_start();
require '../inc/db.php';
// require '../inc/session_check.php';


header('Content-Type: application/json');
error_reporting(E_ERROR | E_PARSE);

/* ===============================
   CHECK SESSION
================================ */
if (!isset($_SESSION['voter_id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Session expired. Please login again.'
    ]);
    exit();
}

$voter_id = $_SESSION['voter_id'];
$position_id = $_POST['position_id'] ?? '';
$partylist_id = $_POST['partylist_id'] ?? '';
$biography = $_POST['biography'] ?? '';

if ($position_id === '' || $partylist_id === '') {
    echo json_encode([
        'success' => false,
        'error' => 'Please select position and partylist.'
    ]);
    exit();
}

/* ===============================
   GET STUDENT INFO
================================ */
$stmt = $conn->prepare("
    SELECT student_id, grade_level, firstname, lastname, strand, section
    FROM voters 
    WHERE id = ?
");
$stmt->bind_param("i", $voter_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    echo json_encode([
        'success' => false,
        'error' => 'Student not found.'
    ]);
    exit();
}

$student_id = $student['student_id'];
$grade_raw = $student['grade_level'];

/* extract grade number */
preg_match('/\d+/', $grade_raw, $m);
$grade = $m[0] ?? '';

/* ===============================
   CHECK DUPLICATE
================================ */
$check = $conn->prepare("
    SELECT id FROM candidates WHERE student_id = ? AND election_id = ?
");
$check->bind_param("si", $student_id, $election_id);
$check->execute();

if ($check->get_result()->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'error' => 'You already filed a candidacy.'
    ]);
    exit();
}

/* ===============================
   GET POSITION NAME
================================ */
$pstmt = $conn->prepare("SELECT name FROM positions WHERE id = ?");
$pstmt->bind_param("i", $position_id);
$pstmt->execute();
$position = $pstmt->get_result()->fetch_assoc();

$position_name = strtoupper($position['name'] ?? '');

/* ===============================
   GRADE VALIDATION
================================ */
if (in_array($position_name, ['PRESIDENT', 'VICE PRESIDENT'])) {
    if (!in_array($grade, ['11', '12'])) {
        echo json_encode([
            'success' => false,
            'error' => "$position_name is only allowed for Grade 11 or Grade 12. Your grade: $grade"
        ]);
        exit();
    }
}

if (str_contains($position_name, 'GRADE')) {
    preg_match('/\d+/', $position_name, $pm);
    $position_grade = $pm[0] ?? '';

    if ($position_grade !== $grade) {
        echo json_encode([
            'success' => false,
            'error' => "This position is only allowed for Grade $position_grade students. Your grade: $grade"
        ]);
        exit();
    }
}

/* ===============================
   BUILD GRADE/STRAND/SECTION STRING
================================ */
$display_parts = [];

// 1. Ilagay ang Grade (Siguradong may laman ito)
if (!empty($grade)) {
    $display_parts[] = "Grade " . $grade;
}

// 2. Ilagay ang Strand kung hindi empty at hindi "N/A"
if (!empty($student['strand']) && strtoupper($student['strand']) !== 'N/A') {
    $display_parts[] = $student['strand'];
}

// 3. Ilagay ang Section kung hindi empty at hindi "N/A"
if (!empty($student['section']) && strtoupper($student['section']) !== 'N/A') {
    $display_parts[] = $student['section'];
}

// 4. Pag-isahin gamit ang " - " (implode)
// Kung Grade 11 lang ang meron, output: "Grade 11"
// Kung may Strand, output: "Grade 11 - STEM"
// Kung kompleto, output: "Grade 11 - STEM - A"
$grade_section = implode(" - ", $display_parts);

/* ===============================
   HANDLE PHOTO UPLOAD
================================ */
$photo_name = null;

if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = __DIR__ . '/../admin/uploads';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $original = basename($_FILES['photo']['name']);
    $photo_name = time() . '_' . preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $original);
    move_uploaded_file($_FILES['photo']['tmp_name'], $upload_dir . '/' . $photo_name);
}


  //HANDLE REQUIREMENTS UPLOAD

$requirements_name = null;

if (isset($_FILES['requirements']) && $_FILES['requirements']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = __DIR__ . '/../admin/uploads';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $original_req = basename($_FILES['requirements']['name']);
    $requirements_name = 'REQ_' . time() . '_' . preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $original_req);
    move_uploaded_file($_FILES['requirements']['tmp_name'], $upload_dir . '/' . $requirements_name);
}

// /* ===============================
//    GET ACTIVE ELECTION (ADDED AUTOMATIC)
// ================================ */
// $election_id = $_POST['election_id'] ?? 0;

// // Auto-fetch active election kung walang election_id galing sa form
// if ($election_id == 0) {
//     $active_election = $conn->query("SELECT id FROM elections WHERE status='active' LIMIT 1")->fetch_assoc();
//     $election_id = $active_election['id'] ?? 0;
// }

// if ($election_id == 0) {
//     echo json_encode([
//         'success' => false,
//         'error' => 'No active election selected.'
//     ]);
//     exit();
// }

// $chk = $conn->prepare("
//     SELECT id FROM elections 
//     WHERE id = ? AND status = 'active'
// ");
// $chk->bind_param("i", $election_id);
// $chk->execute();

// if ($chk->get_result()->num_rows === 0) {
//     echo json_encode([
//         'success' => false,
//         'error' => 'Election is not active.'
//     ]);
//     exit();
// }


/* ===============================
   GET CURRENT ELECTION
================================ */

date_default_timezone_set('Asia/Manila');
$now = date('Y-m-d H:i:s');

$election = $conn->query("
SELECT * FROM elections
ORDER BY created_at DESC
LIMIT 1
")->fetch_assoc();

if(!$election){
    echo json_encode([
        'success'=>false,
        'error'=>'No election available.'
    ]);
    exit();
}

if(!($now >= $election['filing_start'] && $now <= $election['filing_end'])){
    echo json_encode([
        'success'=>false,
        'error'=>'Filing of candidacy is closed.'
    ]);
    exit();
}

$election_id = $election['id'];

/* ===============================
   CHECK PARTYLIST POSITION DUPLICATE
================================ */

$partyCheck = $conn->prepare("
    SELECT id FROM candidates
    WHERE partylist_id = ? 
    AND position_id = ?
    AND election_id = ?
    AND status IN ('pending','approved')
");

$partyCheck->bind_param("iii", $partylist_id, $position_id, $election_id);
$partyCheck->execute();
$partyResult = $partyCheck->get_result();

if ($partyResult->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'error' => 'This partylist already has a candidate for this position.'
    ]);
    exit();
}

/* ===============================
   INSERT AS PENDING WITH FULL INFO
================================ */
$insert = $conn->prepare("
    INSERT INTO candidates 
    (student_id, firstname, lastname, grade_section, position_id, partylist_id, election_id, biography, status, photo, requirements)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)
");

$insert->bind_param(
    "ssssiiisss", // Added one 's' for requirements
    $student_id,
    $student['firstname'],
    $student['lastname'],
    $grade_section,
    $position_id,
    $partylist_id,
    $election_id,
    $biography,
    $photo_name,
    $requirements_name // New variable
);

if ($insert->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to submit candidacy.'
    ]);
}
