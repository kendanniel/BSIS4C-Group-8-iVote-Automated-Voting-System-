<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit();
}

$voter_id = $_SESSION['voter_id'];
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_pass = trim($_POST['new_password']);
    $confirm_pass = trim($_POST['confirm_password']);

    if ($new_pass === "" || $confirm_pass === "") {
        $message = "⚠️ Please fill in all fields.";
    } elseif ($new_pass !== $confirm_pass) {
        $message = "❌ Passwords do not match.";
    } elseif (strlen($new_pass) < 6) {
        $message = "⚠️ Password must be at least 6 characters long.";
    } else {
        $hashed = password_hash($new_pass, PASSWORD_DEFAULT);

        // ✅ Update the password and flag in DB
        $stmt = $conn->prepare("UPDATE voters SET password = ?, password_changed = 1 WHERE id = ?");
        $stmt->bind_param("si", $hashed, $voter_id);

        if ($stmt->execute()) {
            // ✅ Log out the voter after changing password (clean session)
            session_unset();
            session_destroy();

            header("Location: voter_login.php?changed=1");
            exit;
        } else {
            $message = "❌ Failed to update password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password</title>
<style>
body { font-family: Poppins, Arial; background:#f7f8ff; display:flex; align-items:center; justify-content:center; height:100vh; }
.container { background:#fff; padding:30px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.1); width:350px; }
h2 { color:#2b2a66; text-align:center; }
input[type=password], button { width:100%; padding:10px; margin:8px 0; border-radius:8px; border:1px solid #ccc; }
button { background:#7872fa; color:#fff; border:none; font-weight:600; cursor:pointer; }
button:hover { background:#eae128; color:#222; }
p { color:red; text-align:center; }
</style>
</head>
<body>
  <div class="container">
    <h2>Change Your Password</h2>
    <?php if (!empty($message)) echo "<p>$message</p>"; ?>
    <form method="POST">
      <input type="password" name="new_password" placeholder="New Password" required>
      <input type="password" name="confirm_password" placeholder="Confirm Password" required>
      <button type="submit">Update Password</button>
    </form>
  </div>
</body>
</html>
