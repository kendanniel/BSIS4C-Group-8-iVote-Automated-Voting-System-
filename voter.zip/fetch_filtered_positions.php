<?php
require '../inc/db.php';

$grade = $_GET['grade'] ?? '';
$election_id = (int)($_GET['election_id'] ?? 0);

// 1. Kunin lahat ng positions sa election na ito
$sql = "SELECT id, name FROM positions WHERE election_id = ? AND is_archived = 0 ORDER BY position_order ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $election_id);
$stmt->execute();
$result = $stmt->get_result();

$filtered_positions = [];

while ($row = $result->fetch_assoc()) {
    $posName = strtoupper($row['name']);
    
    // LOGIC 1: President at Vice President (Para sa Grade 11 at 12 LANG)
    if (strpos($posName, 'PRESIDENT') !== false) {
        if ($grade == '11' || $grade == '12') {
            $filtered_positions[] = $row;
        }
        continue;
    }

    // LOGIC 2: Grade Representative (Dapat saktong match sa grade level niya)
    // Halimbawa: "GRADE 8 REPRESENTATIVE" ay para lang sa Grade 8
    if (strpos($posName, 'REPRESENTATIVE') !== false) {
        if (strpos($posName, "GRADE $grade") !== false) {
            $filtered_positions[] = $row;
        }
        continue;
    }

    // LOGIC 3: Lahat ng General Positions (Secretary, Treasurer, Auditor, etc.)
    // Ipakita ito kahit anong grade level
    $filtered_positions[] = $row;
}

echo json_encode($filtered_positions);
?>