<?php
// require '../inc/db.php';
// date_default_timezone_set('Asia/Manila');

// $query = "SELECT * FROM election ORDER BY id DESC LIMIT 1";
// $result = $conn->query($query);
// $election = $result->fetch_assoc();

// $current_time = new DateTime("now");
// $start_time = new DateTime($election['start_datetime']);
// $end_time = new DateTime($election['end_datetime']);
// $can_vote = ($current_time >= $start_time && $current_time <= $end_time);

// echo json_encode(['can_vote' => $can_vote]);
?>
