<?php
session_start();

// Clear all session data
$_SESSION = [];
session_unset();
session_destroy();

// Redirect to main index.php in the root
header("Location: /index.php"); 
exit();
?>
