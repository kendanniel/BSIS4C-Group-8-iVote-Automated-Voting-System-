<?php
session_start();
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit;
}

$voter_id = $_SESSION['voter_id'];
$email = trim($_POST['email']);
$old = $_POST['old_password'] ?? '';
$new = $_POST['new_password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

// Update email
if (!empty($email)) {
    $stmt = $conn->prepare("UPDATE voters SET email=? WHERE id=?");
    $stmt->bind_param("si", $email, $voter_id);
    $stmt->execute();
}

// Change password if fields filled
if (!empty($old) && !empty($new) && !empty($confirm)) {
    $stmt = $conn->prepare("SELECT password FROM voters WHERE id=?");
    $stmt->bind_param("i", $voter_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (password_verify($old, $row['password'])) {
        if ($new === $confirm) {
            $hashed = password_hash($new, PASSWORD_DEFAULT);
            $update = $conn->prepare("UPDATE voters SET password=?, password_changed=1 WHERE id=?");
            $update->bind_param("si", $hashed, $voter_id);
            $update->execute();
            header("Location: profile.php?success=" . urlencode("Profile updated successfully!"));
            exit;
        } else {
            header("Location: profile.php?error=" . urlencode("New passwords do not match."));
            exit;
        }
    } else {
        header("Location: profile.php?error=" . urlencode("Old password is incorrect."));
        exit;
    }
}

header("Location: profile.php?success=" . urlencode("Profile updated successfully!"));
exit;
