<?php
session_start();
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit;
}

$voter_id = $_SESSION['voter_id'];

$stmt = $conn->prepare("SELECT lastname, firstname, middlename, strand, grade_level, section, student_id, email FROM voters WHERE id = ?");
$stmt->bind_param("i", $voter_id);
$stmt->execute();
$result = $stmt->get_result();
$voter = $result->fetch_assoc();

$voter_name = $voter['firstname'] ?? 'Voter';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | iVote</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: #f1f5f9;
            overflow-x: hidden;
        }

        /* --- SIDEBAR LOGIC --- */
        .sidebar {
            width: 240px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg,#0f172a,#1e293b);
            padding-top: 20px;
            box-shadow: 4px 0 15px rgba(0,0,0,0.4);
            color: white;
            transition: 0.3s ease;
            z-index: 1000;
        }

        .main-content {
            margin-left: 240px;
            padding: 20px;
            transition: 0.3s ease;
            min-height: 100vh;
        }

        /* Mobile Adjustments */
        @media (max-width: 768px) {
            .sidebar {
                left: -240px; /* Hidden by default on mobile */
            }
            .sidebar.active {
                left: 0;
            }
            .main-content {
                margin-left: 0;
            }
            .mobile-header {
                display: flex !important;
            }
        }

        .mobile-header {
            display: none;
            background: #0f172a;
            color: white;
            padding: 10px 20px;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        /* Navigation Buttons */
        .nav-btn {
            padding: 12px 15px;
            border-radius: 10px;
            cursor: pointer;
            background: #1e293b;
            transition: 0.25s;
            font-weight: 500;
            color: white;
            margin: 0 15px 10px 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .nav-btn:hover {
            background: #334155;
            transform: translateX(5px);
        }

        .nav-btn.active {
            background: #3b82f6;
            box-shadow: 0 0 10px rgba(59,130,246,0.7);
        }

        /* --- PROFILE FORM STYLING --- */
        .profile-container {
            margin: 20px auto;
            background: #ffffff; /* Professional White */
            padding: 40px;
            border-radius: 15px;
            max-width: 900px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }

        .profile-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #1e293b;
        }

        form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px 25px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 14px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 6px;
        }

        .form-group input {
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            font-size: 14px;
            width: 100%;
            box-sizing: border-box;
            background: #fff;
        }

        input[readonly] {
            background: #f8fafc;
            color: #64748b;
            cursor: not-allowed;
            border: 1px solid #e2e8f0;
        }

        .section-title {
            grid-column: 1 / -1;
            margin-top: 20px;
            font-weight: bold;
            color: #3b82f6;
            font-size: 16px;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 10px;
        }

        .save-btn {
            grid-column: 1 / -1;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 14px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: 0.3s;
        }

        .save-btn:hover {
            background: #1d4ed8;
            box-shadow: 0 10px 15px -3px rgba(59, 130, 246, 0.3);
        }

        @media (max-width: 600px) {
            .profile-container { padding: 20px; margin: 10px; }
            form { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="mobile-header">
    <div style="display:flex; align-items:center; gap:10px;">
        <img src="srnhs-logo.png" style="width:35px;">
        <span style="font-weight:bold; font-size:14px;">SAN ROQUE NHS</span>
    </div>
    <div id="hamburger" style="cursor:pointer; font-size:24px;" onclick="toggleSidebar()">☰</div>
</div>

<div class="sidebar" id="sidebar">
    <div style="text-align:center;margin-bottom:30px;">
        <img src="srnhs-logo.png" style="width:70px;">
        <h3 style="margin-top:10px; font-size: 18px;">SAN ROQUE NHS</h3>
    </div>

    <div style="padding:0;">
        <div class="nav-btn" onclick="location.href='dashboard.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> 
            Dashboard
        </div>
        <div class="nav-btn active" onclick="location.href='profile.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M400-80v-280h-80v-240q0-33 23.5-56.5T400-680h160q33 0 56.5 23.5T640-600v240h-80v280H400Zm80-640q-33 0-56.5-23.5T400-800q0-33 23.5-56.5T480-880q33 0 56.5 23.5T560-800q0 33-23.5 56.5T480-720Z"/></svg> 
            My Profile
        </div>
        <div class="nav-btn" onclick="location.href='records.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M280-280h280v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80Zm-80 480q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> 
            Records
        </div>
        <div class="nav-btn" onclick="confirmLogout()">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> 
            Logout
        </div>
    </div>
</div>

<div class="main-content" id="mainContent">
    <header style="display:flex; justify-content: flex-end; align-items:center; flex-wrap: wrap; gap: 10px;">
        <div style="font-size:13px; text-align:right; color:#64748b;">
            <?php date_default_timezone_set('Asia/Manila'); ?>
            <?= date("F d, Y") ?><br>
            <?= date("g:i A") ?>
        </div>
    </header>

    <div class="profile-container">
        <h2>My Profile</h2>

        <form action="update_profile.php" method="POST">
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" value="<?= htmlspecialchars($voter['lastname']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>First Name</label>
                <input type="text" value="<?= htmlspecialchars($voter['firstname']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Middle Name</label>
                <input type="text" value="<?= htmlspecialchars($voter['middlename']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Strand</label>
                <input type="text" value="<?= htmlspecialchars($voter['strand']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Grade Level</label>
                <input type="text" value="<?= htmlspecialchars($voter['grade_level']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Section</label>
                <input type="text" value="<?= htmlspecialchars($voter['section']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Student ID</label>
                <input type="text" value="<?= htmlspecialchars($voter['student_id']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" value="<?= htmlspecialchars($voter['email']) ?>">
            </div>

            <div class="section-title">Change Password</div>

            <div class="form-group">
                <label>Old Password</label>
                <input type="password" name="old_password" placeholder="Old Password">
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" placeholder="New Password">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" placeholder="Confirm Password">
            </div>

            <button type="submit" class="save-btn">Save Changes</button>
        </form>
    </div>
</div>

<script>
    // Toggle Sidebar Function
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('active');
    }

    // Logout Confirmation using SweetAlert2
    function confirmLogout() {
        Swal.fire({
            title: 'Are you sure?',
            text: "You will be logged out of your account.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3b82f6',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        });
    }

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
        const sidebar = document.getElementById('sidebar');
        const hamburger = document.getElementById('hamburger');
        if (window.innerWidth <= 768) {
            if (!sidebar.contains(event.target) && event.target !== hamburger) {
                sidebar.classList.remove('active');
            }
        }
    });
</script>

<?php if (isset($_GET['success'])): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Success',
    text: '<?= htmlspecialchars($_GET['success']) ?>',
    confirmButtonColor: '#3b82f6'
});
</script>
<?php elseif (isset($_GET['error'])): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: '<?= htmlspecialchars($_GET['error']) ?>',
    confirmButtonColor: '#3b82f6'
});
</script>
<?php endif; ?>

</body>
</html>