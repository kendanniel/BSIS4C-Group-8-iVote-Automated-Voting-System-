<?php
session_start();
require '../inc/db.php';
// require '../inc/session_check.php';

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit();
}

// 1. DEFINISYON: Kunin muna ang ID bago gamitin sa queries sa ibaba
$voter_id = $_SESSION['voter_id']; 

// 2. CHECK VOTING STATUS (May is_archived = 0 para sa bagong election)
$voteCheck = $conn->prepare("SELECT id FROM votes WHERE voter_id = ? AND is_archived = 0");
$voteCheck->bind_param("i", $voter_id);
$voteCheck->execute();
$voteResult = $voteCheck->get_result();
$hasVoted = ($voteResult && $voteResult->num_rows > 0);

// Fetch voter's name
$stmt = $conn->prepare("SELECT firstname, lastname FROM voters WHERE id = ?");
$stmt->bind_param("i", $voter_id);
$stmt->execute();
$result = $stmt->get_result();
$voter = $result->fetch_assoc();
$voter_name = !empty($voter['firstname']) ? $voter['firstname'] : 'Voter';

$default_positions = [
    'PRESIDENT',
    'VICE PRESIDENT',
    'SECRETARY',
    'TREASURER',
    'AUDITOR',
    'PUBLIC INFORMATION OFFICER',
    'PROTOCOL OFFICER',
    'GRADE 8 REPRESENTATIVE',
    'GRADE 9 REPRESENTATIVE',
    'GRADE 10 REPRESENTATIVE',
    'GRADE 11 REPRESENTATIVE',
    'GRADE 12 REPRESENTATIVE'
];

// Check if voter is already a candidate
$candidateCheck = $conn->prepare("SELECT id FROM candidates WHERE student_id = (SELECT student_id FROM voters WHERE id = ?) AND status IN ('pending','approved')");
$candidateCheck->bind_param("i", $voter_id);
$candidateCheck->execute();
$candidateResult = $candidateCheck->get_result();
$isCandidate = ($candidateResult && $candidateResult->num_rows > 0);


date_default_timezone_set('Asia/Manila');
$now = date('Y-m-d H:i:s');

// Fetch the latest election
$electionRes = $conn->query("SELECT * FROM elections ORDER BY created_at DESC LIMIT 1");
$election = $electionRes->fetch_assoc();

$canVote = false;
$canFileCandidacy = false;
$electionMessage = '';
$ordered_candidates = []; 

if ($election) {
    $election_id = (int)$election['id'];
    
    // --- FETCH ACTUAL POSITIONS FROM DB ---
    // Imbes na gumamit lang ng $default_positions, kunin ang totoong positions sa database
    $posRes = $conn->query("SELECT id, name FROM positions WHERE election_id = $election_id AND is_archived = 0 ORDER BY position_order ASC");
    $db_positions = [];
    while($p = $posRes->fetch_assoc()) {
        $db_positions[] = $p;
    }

    // --- FETCH PARTYLISTS ---
    $partyRes = $conn->query("SELECT id, name FROM partylist WHERE is_archived = 0 ORDER BY name ASC");
    $db_partylists = [];
    while($pl = $partyRes->fetch_assoc()) {
        $db_partylists[] = $pl;
    }

    // --- TIME CHECKS ---
    // --- TIME & STATUS CHECKS ---
    // Mas safe gamitin ang status column dahil na-force update na natin sa admin
    $isElectionOpen = ($election['status'] == 'active'); 
    $isFilingOpen   = ($election['filing_status'] == 1);
    // $isElectionOpen = ($now >= $election['start_datetime'] && $now <= $election['end_datetime']);
    // $isFilingOpen   = ($now >= $election['filing_start'] && $now <= $election['filing_end']);
    // $isUpcoming     = ($now < $election['start_datetime']);
    // $isOver         = ($now > $election['end_datetime']);

    if ($isElectionOpen) {
        $canVote = true;
    }

    if ($isFilingOpen) {
        $canFileCandidacy = true;
    }

    // Set messages based on time
    if ($isUpcoming) {
        $electionMessage = "The election will start on " . date("F d, Y g:i A", strtotime($election['start_datetime']));
    } elseif ($isOver) {
        $electionMessage = "The election has already ended.";
    }

    // --- FETCH CANDIDATES ---
    // (Gamit ang LEFT JOIN para lumabas ang Abstain)
    $candidatesRes = $conn->query("
        SELECT c.*, 
               IFNULL(v.firstname, c.firstname) AS display_fname, 
               IFNULL(v.lastname, c.lastname) AS display_lname, 
               v.strand, v.section, 
               p.name AS position_name, pl.name AS partylist_name
        FROM candidates c
        LEFT JOIN voters v ON c.student_id = v.student_id
        LEFT JOIN positions p ON c.position_id = p.id
        LEFT JOIN partylist pl ON c.partylist_id = pl.id
        WHERE c.status = 'approved' AND c.election_id = $election_id
        ORDER BY p.position_order ASC, c.lastname ASC
    ");
    
    $candidates = $candidatesRes->fetch_all(MYSQLI_ASSOC);
    $grouped_candidates = [];

    foreach ($candidates as $c) {
        $posName = strtoupper(trim($c['position_name'] ?? 'UNASSIGNED'));
        $grouped_candidates[$posName][] = $c;
    }

    $ordered_candidates = [];
    foreach ($default_positions as $pos) {
        $key = strtoupper(trim($pos));
        if (isset($grouped_candidates[$key])) {
            $ordered_candidates[$key] = $grouped_candidates[$key];
            unset($grouped_candidates[$key]);
        }
    }

    foreach ($grouped_candidates as $pos => $cands) {
        $ordered_candidates[$pos] = $cands;
    }

} else {
    $electionMessage = "No active election.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Voter Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<style>
     body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: #f1f5f9;
            overflow-x: hidden;
        }

        /* --- SIDEBAR LOGIC --- */
        .sidebar {
            width: 240px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg,#0f172a,#1e293b);
            padding-top: 20px;
            box-shadow: 4px 0 15px rgba(0,0,0,0.4);
            color: white;
            transition: 0.3s ease;
            z-index: 1000;
        }

        .main-content {
            margin-left: 240px;
            padding: 20px;
            transition: 0.3s ease;
            min-height: 100vh;
        }

    /* Mobile Sidebar Toggle */
    @media (max-width: 768px) {
        .sidebar { transform: translateX(-100%); }
        .sidebar.active { transform: translateX(0); }
        .main-content { margin-left: 0 !important; }
        .mobile-header { display: flex !important; }
    }

    .mobile-header {
        display: none;
        background: #0f172a;
        color: white;
        padding: 15px;
        justify-content: space-between;
        align-items: center;
        position: sticky;
        top: 0;
        z-index: 999;
    }

    .nav-btn {
        padding: 12px 15px;
        border-radius: 10px;
        cursor: pointer;
        background: #1e293b;
        transition: 0.25s;
        font-weight: 500;
        color: white;
        margin: 0 15px 10px 15px;
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
    }

    .nav-btn:hover {
        background: #334155;
        transform: translateX(5px);
        color: white;
    }

    .nav-btn.active {
        background: #3b82f6;
        box-shadow: 0 0 10px rgba(59,130,246,0.7);
        color: white;
    }

    /* Modal Styling */
    .popup {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.6);
        backdrop-filter: blur(5px);
        justify-content: center;
        align-items: center;
        z-index: 10001;
        padding: 20px;
    }

    .popup-content {
        background: #fff;
        border-radius: 15px;
        padding: 30px;
        width: 100%;
        max-width: 450px;
        max-height: 90vh;
        overflow-y: auto;
    }

    /* Form Elements */
    input, select, textarea {
        width: 100%;
        padding: 10px;
        margin: 8px 0 15px 0;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        box-sizing: border-box;
    }

    .vote-btn {
        background: #7872fa;
        color: #fff;
        padding: 12px 25px;
        border: none;
        border-radius: 25px;
        cursor: pointer;
        font-weight: bold;
        transition: 0.3s;
    }

    /* Grid & Cards */
    .candidates-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 18px;
    }

    .candidate-card {
        background: #ffffff;
        border-radius: 16px;
        overflow: hidden;
        border: 1px solid #f1f5f9;
        transition: 0.3s;
    }

    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .position-section { animation: fadeInUp 0.4s ease both; margin-bottom: 40px; }
</style>
</head>
<body>

<div class="mobile-header">
    <div style="display:flex; align-items:center; gap:10px;">
        <img src="srnhs-logo.png" style="width:35px;">
        <span style="font-weight:bold; font-size:14px;">SAN ROQUE NHS</span>
    </div>
    <div id="hamburger" style="cursor:pointer; font-size:24px;" onclick="toggleSidebar()">☰</div>
</div>

<div class="sidebar" id="sidebar">
    <div style="text-align:center;margin-bottom:30px;">
        <img src="srnhs-logo.png" style="width:70px;">
        <h3 style="margin-top:10px; font-size: 18px;">SAN ROQUE NHS</h3>
    </div>

    <div style="padding:0;">
        <div class="nav-btn active" onclick="location.href='dashboard.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> 
            Dashboard
        </div>
        <div class="nav-btn" onclick="location.href='profile.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M400-80v-280h-80v-240q0-33 23.5-56.5T400-680h160q33 0 56.5 23.5T640-600v240h-80v280H400Zm80-640q-33 0-56.5-23.5T400-800q0-33 23.5-56.5T480-880q33 0 56.5 23.5T560-800q0 33-23.5 56.5T480-720Z"/></svg> 
            My Profile
        </div>
        <div class="nav-btn" onclick="location.href='records.php'">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M280-280h280v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80Zm-80 480q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> 
            Records
        </div>
        <div class="nav-btn" onclick="confirmLogout()">
            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> 
            Logout
        </div>
    </div>
</div>
<div class="main-content">
    <div class="page-inner">
        <header style="display:flex;justify-content:space-between;align-items:center; flex-wrap: wrap; gap:10px; margin-bottom:20px;">
            <h3 style="margin:0;">Welcome, <?= htmlspecialchars($voter_name) ?>!</h3>
            <div style="font-size:13px; text-align:right; color:#64748b;"><?= date("F d, Y") ?><br><?= date("g:i A") ?></div>
        </header>

        <?php if(!empty($electionMessage)): ?>
            <div style="text-align:center; background:#fee2e2; border-radius:10px; padding:10px; margin-bottom:20px;">
                <p style="color:#dc2626; font-weight:bold; margin:0;"><?= htmlspecialchars($electionMessage) ?></p>
            </div>
        <?php endif; ?>

        <div style="display: flex; gap: 20px; justify-content: center; margin-bottom: 30px; flex-wrap: wrap;">
            <div style="background: linear-gradient(135deg, #4f46e5 0%, #7872fa 100%); border-radius: 18px; padding: 25px; flex: 1; min-width: 280px; color: white; text-align: center; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);">
                <div style="font-size:20px; font-weight:700;">Vote Now</div>
                <p style="font-size:13px; opacity:0.9;">
                    <?php if($hasVoted): ?> You have already cast your vote.
                    <?php elseif($canVote): ?> Voting is open!
                    <?php else: ?> Not available. <?php endif; ?>
                </p>
                <button id="voteNowBtn" <?= ($hasVoted || !$canVote) ? 'disabled' : '' ?> class="vote-btn" style="width:100%; background:white; color:#4f46e5;">
                    <?= $hasVoted ? 'Already Voted' : 'VOTE NOW' ?>
                </button>
            </div>

            <div style="background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%); border-radius: 18px; padding: 25px; flex: 1; min-width: 280px; color: white; text-align: center; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);">
                <div style="font-size:20px; font-weight:700;">File Candidacy</div>
                <p style="font-size:13px; opacity:0.9;">
                    <?php if($isCandidate): ?> Already filed.
                    <?php elseif($canFileCandidacy): ?> Filing is open.
                    <?php else: ?> Filing is closed. <?php endif; ?>
                </p>
                <button id="fileCandidacyBtn" <?= ($isCandidate || !$canFileCandidacy) ? 'disabled' : '' ?> onclick="openModal()" class="vote-btn" style="width:100%; background:white; color:#0f766e;">
                    <?= $isCandidate ? 'Already Filed' : 'FILE NOW' ?>
                </button>
            </div>
        </div>

        <div style="background: #fff; border-radius: 20px; padding: 20px; border: 1px solid #e2e8f0;">
    <h2 style="font-family:'Playfair Display'; color:#1e293b; margin-top:0;">Official Candidates</h2>
    
    <?php foreach($ordered_candidates as $position => $cands): 
        if(empty($cands)) continue; // OPTIONAL: Itago ang position kung walang candidate
    ?>
        <div class="position-section">
            <h4 style="border-left: 4px solid #3b82f6; padding-left: 10px; color:#334155; text-transform: uppercase;">
                <?= htmlspecialchars($position) ?>
            </h4>
            <div class="candidates-grid">
                <?php foreach($cands as $c): ?>
                    <div class="candidate-card">
    <div style="background: #1e293b; padding: 20px; text-align:center;">
        <?php 
            $photoPath = '../admin/uploads/'.$c['photo'];
            $displayPhoto = (!empty($c['photo']) && file_exists($photoPath)) ? $photoPath : 'images/default.png';
            // Kung Abstain, pwedeng ibang icon ang ipakita
            if($c['firstname'] == 'Abstain') $displayPhoto = 'images/abstain_logo.png'; 
        ?>
        <img src="<?= $displayPhoto ?>" style="width:80px; height:80px; border-radius:50%; object-fit:cover; border:3px solid white;">
    </div>
    <div style="padding:15px; text-align:center;">
        <div style="font-weight:700; color:#1e293b;"><?= htmlspecialchars($c['display_fname'].' '.$c['display_lname']) ?></div>
        <div style="font-size:11px; color:#3b82f6; font-weight:600; text-transform:uppercase; margin-bottom:5px;"><?= htmlspecialchars($c['partylist_name'] ?? 'Independent') ?></div>
        <div style="font-size:12px; color:#64748b;"><?= htmlspecialchars($c['grade_section'] ?? '') ?></div>
    </div>
</div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
    </div>
</div>

<div id="guidelinesPopup" class="popup">
    <div class="popup-content">
        <h2>Voting Guidelines</h2>
        <p>Please review the rules before proceeding with your vote.</p>
        <label style="display:flex; align-items:center; gap:10px;">
            <input type="checkbox" id="agreeCheckbox" style="width:auto; margin:0;"> I understand and agree to the guidelines.
        </label>
        <button id="proceedBtn" disabled class="vote-btn" style="width:100%; margin-top:15px;">PROCEED TO VOTE</button>
        <button type="button" onclick="document.getElementById('guidelinesPopup').style.display='none'" class="vote-btn" style="width:100%; background:#cbd5e1; color:#475569; margin-top:10px;">CLOSE</button>
    </div>
</div>

<div id="candidacyModal" class="popup">
    <div class="popup-content">
        <h2>File for Candidacy</h2>
        <form id="candidacyForm" enctype="multipart/form-data">
            <input type="hidden" name="election_id" value="<?= $election_id ?>">
            
            <label>Student ID</label>
            <input type="text" name="student_id" id="student_id" required>
            
            <div style="display: flex; gap: 10px;">
                <div style="flex: 1;">
                    <label>First Name</label>
                    <input type="text" id="firstname" readonly style="background: #f1f5f9;">
                </div>
                <div style="flex: 1;">
                    <label>Last Name</label>
                    <input type="text" id="lastname" readonly style="background: #f1f5f9;">
                </div>
            </div>

           <div style="margin-bottom: 15px;">
    <label style="display: block; font-size: 14px; font-weight: 500; color: #1e293b; margin-bottom: 5px;">Grade & Section</label>
    <input type="text" id="academic_info" readonly 
        style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; background: #f8fafc; color: #64748b; font-family: 'Poppins', sans-serif; font-size: 14px;" 
        placeholder="Waiting for Student ID...">
</div>

            <label>Position</label>
<select name="position_id" id="position_select" required>
    <option value="">-- Enter Student ID First --</option>
</select>
            
        
            
            <label>Partylist</label>
            <select name="partylist_id" required>
                <option value="">-- Select Partylist --</option>
                <?php foreach($db_partylists as $pl): ?>
                    <option value="<?= $pl['id'] ?>"><?= htmlspecialchars($pl['name']) ?></option>
                <?php endforeach; ?>
            </select>

            <label>Biography</label>
            <textarea name="biography" rows="3" required></textarea>

            <label>Photo</label>
            <input type="file" name="photo" accept="image/*" id="photoInput" required>
            
            <div id="candidacy-warning" style="color:red; font-size:12px; display:none; margin-bottom:10px;"></div>

            <button type="button" id="submitCandidacy" class="vote-btn" style="width:100%;">SUBMIT</button>
            <button type="button" onclick="closeModal()" class="vote-btn" style="width:100%; background:#cbd5e1; color:#475569; margin-top:10px;">CANCEL</button>
        </form>
    </div>
</div>
<script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('active');
    }
    
    function confirmLogout() {
        Swal.fire({
            title: 'Are you sure?',
            text: "You will be logged out of your account.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3b82f6',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        });
    }

    function openModal() { document.getElementById('candidacyModal').style.display = 'flex'; }
    function closeModal() { document.getElementById('candidacyModal').style.display = 'none'; }

    document.addEventListener('DOMContentLoaded', function() {
        const voteBtn = document.getElementById('voteNowBtn');
        const guidelinesPopup = document.getElementById('guidelinesPopup');
        const agreeCheckbox = document.getElementById('agreeCheckbox');
        const proceedBtn = document.getElementById('proceedBtn');
        const submitBtn = document.getElementById('submitCandidacy');

        if (voteBtn) voteBtn.addEventListener('click', () => guidelinesPopup.style.display = 'flex');

        if (agreeCheckbox) {
            agreeCheckbox.addEventListener('change', () => proceedBtn.disabled = !agreeCheckbox.checked);
        }

        if (proceedBtn) {
            proceedBtn.addEventListener('click', () => window.location.href = 'voting_page.php');
        }

        if (submitBtn) {
            submitBtn.addEventListener('click', function() {
                const warning = document.getElementById('candidacy-warning');
                submitBtn.disabled = true;
                
                fetch('file_candidacy.php', {
                    method: 'POST',
                    body: new FormData(document.getElementById('candidacyForm'))
                })
                .then(res => res.json())
                .then(data => {
                    // Hanapin ang part na ito sa loob ng submitBtn.addEventListener
if (data.success) {
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Candidate saved successfully',
        confirmButtonColor: '#3b82f6',
        // ITO ANG MAGPAPALUTANG SA SWAL SA HARAP NG MODAL
        didOpen: () => {
            const swalContainer = document.querySelector('.swal2-container');
            if (swalContainer) {
                swalContainer.style.zIndex = '20000'; // Mas mataas sa 10001 ng modal mo
            }
        }
    }).then(() => {
        location.reload();
    });

                    } else {
                        warning.innerText = data.error;
                        warning.style.display = 'block';
                        submitBtn.disabled = false;
                        Swal.fire({
                            icon: 'error',
                            title: 'Filing Failed',
                            text: data.error,
                            confirmButtonColor: '#3b82f6'
                        });
                    }
                })
                .catch(() => {
                    submitBtn.disabled = false;
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An unexpected error occurred.',
                        confirmButtonColor: '#3b82f6'
                    });
                });
            });
        }

//      document.getElementById('student_id').addEventListener('input', function() {
//     if(this.value.length >= 3){
//         fetch(`fetch_student.php?student_id=${this.value}`)
//         .then(res => res.json())
//         .then(data => {
//             if(data.success){
//                 document.getElementById('firstname').value = data.firstname;
//                 document.getElementById('lastname').value = data.lastname;
                
//                 // PINAGSAMANG LOGIC:
//                 let grade = data.grade_level || '';
//                 let strand = (data.strand && data.strand !== 'N/A') ? ' - ' + data.strand : '';
//                 let section = (data.section && data.section !== 'N/A') ? ' - ' + data.section : '';
                
//                 // Dito isasaksak sa iisang input field (academic_info)
//                 document.getElementById('academic_info').value = grade + strand + section;
//             } else {
//                 // I-clear lahat kapag walang nahanap
//                 document.getElementById('firstname').value = '';
//                 document.getElementById('lastname').value = '';
//                 document.getElementById('academic_info').value = '';
//             }
//         });
//     }
// });

document.getElementById('student_id').addEventListener('input', function() {
    const posSelect = document.getElementById('position_select');
    const studentId = this.value;

    if (studentId.length >= 3) {
        fetch(`fetch_student.php?student_id=${studentId}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    // 1. I-fill ang name at academic info
                    document.getElementById('firstname').value = data.firstname;
                    document.getElementById('lastname').value = data.lastname;

                    let grade = data.grade_level || '';
                    let strand = (data.strand && data.strand !== 'N/A') ? ' - ' + data.strand : '';
                    let section = (data.section && data.section !== 'N/A') ? ' - ' + data.section : '';
                    document.getElementById('academic_info').value = grade + strand + section;

                    // 2. FETCH FILTERED POSITIONS
                    // Dito tatawagin ang script na ginawa natin para sa grade-based filtering
                    fetch(`fetch_filtered_positions.php?grade=${encodeURIComponent(grade)}&election_id=<?= $election_id ?>`)
                        .then(res => res.json())
                        .then(positions => {
                            posSelect.innerHTML = '<option value="">-- Select Position --</option>';
                            positions.forEach(p => {
                                posSelect.innerHTML += `<option value="${p.id}">${p.name}</option>`;
                            });
                        })
                        .catch(err => console.error("Error fetching positions:", err));

                } else {
                    // I-reset lahat kapag invalid ang ID o walang nahanap
                    document.getElementById('firstname').value = '';
                    document.getElementById('lastname').value = '';
                    document.getElementById('academic_info').value = '';
                    posSelect.innerHTML = '<option value="">-- Enter Student ID First --</option>';
                }
            })
            .catch(err => console.error("Error fetching student:", err));
    }
});
    });
</script>
</body>
</html>