<?php
session_start();
require_once __DIR__ . '/../inc/db.php';
if (!isset($_SESSION['voter_id'])) {
  header("Location: voter_login.php");
  exit;
}
// require '../inc/session_check.php';

// Fetch candidates grouped by position
$sql = "
  SELECT p.id AS position_id, p.position_name, c.id AS candidate_id, c.candidate_name, c.image
  FROM positions p
  LEFT JOIN candidates c ON c.position_id = p.id
  ORDER BY p.position_order ASC, c.candidate_name ASC
";
$result = $conn->query($sql);

$positions = [];
while ($row = $result->fetch_assoc()) {
  $positions[$row['position_name']][] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Vote Now | iVote</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  background-color: #f4f4f9;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  min-height: 100vh;
}
.card {
  background-color: #fff;
  border: 10px solid #1f1f5e;
  border-radius: 12px;
  padding: 30px;
  width: 650px;
  text-align: center;
}
h2 {
  margin-bottom: 0;
}
h3 {
  margin: 15px 0 10px;
  color: #000;
}
.position {
  margin-top: 25px;
}
.candidates {
  display: flex;
  justify-content: center;
  gap: 30px;
  flex-wrap: wrap;
}
.candidate {
  border: 2px solid #000;
  border-radius: 10px;
  width: 150px;
  padding: 10px;
  text-align: center;
  transition: transform 0.2s;
}
.candidate:hover {
  transform: scale(1.05);
}
.candidate img {
  width: 80px;
  height: 80px;
  border-radius: 12px;
  object-fit: cover;
  background: #ddd;
}
input[type="radio"] {
  margin-top: 10px;
}
button {
  background-color: #4a3aff;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 25px;
  font-weight: bold;
  margin-top: 25px;
  cursor: pointer;
  transition: 0.3s;
}
button:hover {
  background-color: #3027b8;
}
</style>
</head>
<body>
  <div class="card">
    <img src="logo.png" alt="Logo" style="height:70px; float:left;">
    <h2>STUDENT COUNCIL ELECTION</h2>
    <p>S.Y. 2025–2026</p>
    <h2 style="color:#ffcc00;">iVote</h2>

    <form action="submit_vote.php" method="POST">
      <?php foreach ($positions as $pos_name => $cands): ?>
        <div class="position">
          <h3><?= htmlspecialchars($pos_name) ?> (1)</h3>
          <div class="candidates">
            <?php foreach ($cands as $cand): ?>
              <label class="candidate">
                <img src="uploads/<?= htmlspecialchars($cand['image'] ?: 'default.png') ?>" alt="">
                <p><strong><?= htmlspecialchars($cand['candidate_name']) ?></strong></p>
                <input type="radio" name="position_<?= $cand['position_id'] ?>" value="<?= $cand['candidate_id'] ?>" required>
              </label>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
      <button type="submit">SUBMIT VOTE</button>
    </form>
  </div>
</body>
</html>
