<?php
session_start();
require_once __DIR__ . '/../inc/db.php';
require_once __DIR__ . '/../fpdf/fpdf.php'; 

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter_login.php");
    exit;
}

$voter_id = (int) $_SESSION['voter_id'];

// 1. FETCH VOTER INFO
$stmt = $conn->prepare("SELECT firstname, lastname, grade_level, strand, section, student_id FROM voters WHERE id = ?");
$stmt->bind_param("i", $voter_id);
$stmt->execute();
$voter = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$voter) {
    die("Voter not found.");
}

// 2. FETCH LATEST ELECTION INFO (Para sa Title at School Year)
// Siguraduhin na may 'title' at 'school_year' columns ang elections table mo
$elecQuery = $conn->query("SELECT title, school_year FROM elections ORDER BY id DESC LIMIT 1");
$election = $elecQuery->fetch_assoc();
$election_title = $election['title'] ?? "Student Council Election";
$school_year = $election['school_year'] ?? "2025-2026";

// Create PDF
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();

// --- HEADER ---
$pdf->SetFont('Arial','B',20);
$pdf->Cell(0,10,'SAN ROQUE NATIONAL HIGH SCHOOL',0,1,'C');
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,8, strtoupper($election_title), 0, 1, 'C'); // Dynamic Election Title
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,6,'School Year: ' . $school_year, 0, 1, 'C'); // Dynamic School Year
$pdf->Ln(5);
$pdf->Cell(0,0,'',1,1); // Horizontal Line
$pdf->Ln(10);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,"VOTER'S CERTIFICATE",0,1,'C');
$pdf->Ln(10);

// --- VOTER INFO ---
$pdf->SetFont('Arial','B',12);
$pdf->Cell(60,10,'Full Name:',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10, strtoupper($voter['firstname'].' '.$voter['lastname']),0,1);

$pdf->SetFont('Arial','B',12);
$pdf->Cell(60,10,'Student ID:',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10,$voter['student_id'],0,1);

$pdf->SetFont('Arial','B',12);
$pdf->Cell(60,10,'Grade / Strand / Section:',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10,$voter['grade_level'].' / '.$voter['strand'].' - '.$voter['section'],0,1);

$pdf->Ln(15);

// --- CERTIFICATION TEXT ---
$pdf->SetFont('Arial','',12);
$text = "This certifies that the above-named student is a registered voter for the " . $election_title . " (S.Y. " . $school_year . ") at San Roque National High School. The student's participation has been successfully recorded through the iVote Online Voting System.";
$pdf->MultiCell(0,8,$text,0,'J');

$pdf->Ln(25);

// --- SIGNATURE ---
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,'_____________________________',0,1,'R');
$pdf->Cell(0,5,'Election Officer',0,1,'R');
$pdf->SetFont('Arial','I',10);
$pdf->Cell(0,10,'Date Generated: '.date('F d, Y'),0,1,'L');

// Output PDF
$pdf->Output('I','Voter_Certificate_'.$voter['student_id'].'.pdf');
exit;