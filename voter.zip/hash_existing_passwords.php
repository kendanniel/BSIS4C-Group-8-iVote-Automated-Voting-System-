<?php
// ===================================================================
// hash_existing_passwords.php
// One-time script to hash all voters' plaintext passwords (like @sr01)
// ===================================================================

require '../inc/db.php'; // Adjust path if needed

if (!($conn instanceof mysqli)) {
    die("❌ Database connection not found. Check inc/db.php");
}

// --- SETTINGS ---
// Hash only rows where password is exactly '@sr01' (default password)
$onlyDefault = true;

$sql = "SELECT id, password FROM voters";
$res = $conn->query($sql);
if (!$res) die("❌ Query failed: " . $conn->error);

$updated = 0;
while ($row = $res->fetch_assoc()) {
    $id = (int)$row['id'];
    $pw = $row['password'];

    // Skip if already hashed (bcrypt or argon format)
    if (preg_match('/^\$2[aby]\$|\$argon2/i', $pw)) {
        continue;
    }

    // Optional: only hash if password is the known default
    if ($onlyDefault && $pw !== '@sr01') {
        continue;
    }

    // Hash password securely
    $newHash = password_hash($pw, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("UPDATE voters SET password = ? WHERE id = ?");
    $stmt->bind_param('si', $newHash, $id);
    $stmt->execute();
    if ($stmt->affected_rows > 0) $updated++;
    $stmt->close();
}

echo "<h2>✅ Done.</h2>";
echo "<p>Updated <b>$updated</b> voter password(s) to secure hashes.</p>";
echo "<p>Now all affected voters can still log in using <b>@sr01</b> as password.</p>";
echo "<p><b>IMPORTANT:</b> Delete this file after running it once for security.</p>";
