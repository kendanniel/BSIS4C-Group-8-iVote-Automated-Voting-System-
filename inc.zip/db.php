<?php
$servername = "localhost";
$username = "u648814226_ivote";
$password = "u648814226_iVote25";
$dbname = "u648814226_ivote";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
