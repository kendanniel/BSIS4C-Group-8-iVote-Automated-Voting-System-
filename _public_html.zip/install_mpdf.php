<?php
// Script para i-install ang mPDF gamit ang system command
echo "Nag-uumpisa na ang installation, pakihintay...<br>";

// Sinusubukan itakbo ang composer require
$output = shell_exec('composer require mpdf/mpdf 2>&1');

echo "<pre>$output</pre>";
echo "<br>Tapos na! I-check kung may 'vendor' folder na.";
?>