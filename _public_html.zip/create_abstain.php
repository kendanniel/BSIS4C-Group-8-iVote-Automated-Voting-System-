<?php
require 'inc/db.php';

echo "<h2>Creating Abstain Candidates...</h2>";

/* GET CURRENT ELECTION */
$election = $conn->query("
SELECT * FROM elections
ORDER BY created_at DESC
LIMIT 1
")->fetch_assoc();

if(!$election){
    die("No election found.");
}

$election_id = $election['id'];

/* GET POSITIONS OF THIS ELECTION */
$positions = $conn->query("
SELECT * FROM positions
WHERE election_id = $election_id
");

while($pos = $positions->fetch_assoc()){

    $position_id = $pos['id'];

    /* CHECK IF ABSTAIN ALREADY EXISTS */
    $check = $conn->query("
    SELECT id FROM candidates
    WHERE firstname='Abstain'
    AND lastname='Vote'
    AND position_id=$position_id
    AND election_id=$election_id
    ");

    if($check->num_rows == 0){

        /* INSERT ABSTAIN */
        $conn->query("
        INSERT INTO candidates
        (firstname, lastname, position_id, election_id, status)
        VALUES
        ('Abstain','Vote',$position_id,$election_id,'approved')
        ");

        echo "Added Abstain for position ID: ".$position_id."<br>";

    } else {

        echo "Abstain already exists for position ID: ".$position_id."<br>";

    }
}

echo "<br><b>Done!</b>";
?>