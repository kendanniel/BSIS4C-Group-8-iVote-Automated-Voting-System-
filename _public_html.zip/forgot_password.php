<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'inc/db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim(strtolower($_POST['email']));
    $user = null;
    $table = '';

    // 1️⃣ Check admin table
    $stmt = $conn->prepare("SELECT id, name, email FROM admin WHERE LOWER(email) = ?");
    if (!$stmt) { die("Admin prepare failed: " . $conn->error); }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $table = 'admin';
    } 

    // 2️⃣ If not found in admin, check voters table
    if (!$user) {
        $stmt = $conn->prepare("SELECT id, firstname, lastname, email FROM voters WHERE LOWER(email) = ?");
        if (!$stmt) { die("Voter prepare failed: " . $conn->error); }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $table = 'voters';
        }
    }

    // 3️⃣ If found, generate token & save
    if ($user) {
        $token = bin2hex(random_bytes(16));
        $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));

        $update = $conn->prepare("UPDATE $table SET reset_token = ?, token_expiry = ? WHERE LOWER(email) = ?");
        if (!$update) { die("Update failed: " . $conn->error); }
        $update->bind_param("sss", $token, $expiry, $email);
        $update->execute();

        // Send email
        $reset_link = "https://kakaelect.com/reset_password.php?token=" . $token;
        $to = $email;
        $subject = "iVote Password Reset";
        $name = $user['name'] ?? $user['firstname']; // admin have 'name', voters have 'firstname'
        $body = "Hi $name,\n\nYou requested a password reset. Click below to reset (valid 15 mins):\n$reset_link\n\nIf you didn't request this, ignore this email.\n\n-iVote System";
        $headers = "From: noreply@kakaelect.com\r\nReply-To: noreply@kakaelect.com\r\nX-Mailer: PHP/" . phpversion();

        if (mail($to, $subject, $body, $headers)) {
            $message = "A password reset link has been sent to your email.";
        } else {
            $message = "Failed to send email. Please contact the admin.";
        }
    } else {
        $message = "No account found with that email.";
    }
}
?>

<!-- HTML Form same as your design -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>iVote | Forgot Password</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: url('srnhs.jpg') no-repeat center center fixed; /* Replace with your image path */
      background-size: cover; /* Covers the full screen */
      background-color: #1877f2; /* Fallback to blue if image fails */
    }


    .login-wrapper {
      position: relative;
      z-index: 2;
      width: 400px;
      max-width: 95%;
    }

    .login-card {
      background: #ffffff; /* White background for the form */
      border-radius: 15px;
      padding: 35px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1); /* Adjusted shadow */
      text-align: center;
      color: #333; /* Dark text for contrast */
      animation: fadeIn 0.6s ease;
      border: 1px solid #e0e0e0; /* Subtle border */
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .school-logo img {
      width: 90px;
      border-radius: 50%;
      margin-bottom: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1); /* Adjusted shadow */
    }

    .school-name {
      font-size: 16px;
      font-weight: 500;
      margin-bottom: 5px;
      letter-spacing: 0.5px;
      color: #555; /* Darker color */
    }

    .logo-text {
      font-size: 2.2em;
      font-weight: bold;
      margin-bottom: 5px;
      color: #1e3c72; /* Dark blue */
    }

    .logo-text small {
      color: #1877f2; /* Blue for 'i' */
    }

    .subtitle {
      font-size: 13px;
      margin-bottom: 20px;
      color: #777; /* Gray */
    }

    form {
      display: flex;
      flex-direction: column;
      text-align: left;
    }

    label {
      font-size: 13px;
      margin-top: 10px;
      margin-bottom: 5px;
      color: #333; /* Dark */
    }

    input {
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #ddd;
      outline: none;
      font-size: 14px;
      margin-bottom: 5px;
      background: #f9f9f9;
      color: #333; /* Dark text in inputs */
    }

    input:focus {
      box-shadow: 0 0 6px rgba(24, 119, 242, 0.3); /* Blue focus */
      border-color: #1877f2;
    }

    .message {
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 5px;
      background: #f0f2f5;
      color: #1877f2;
      font-size: 14px;
    }

    button {
      margin-top: 15px;
      padding: 12px;
      border: none;
      border-radius: 8px;
      background: #1877f2; /* Blue button */
      color: #ffffff; /* White text */
      font-weight: bold;
      font-size: 14px;
      cursor: pointer;
      transition: 0.3s ease;
    }

    button:hover {
      background: #166fe5; /* Darker blue on hover */
      transform: translateY(-2px);
    }

    .footer {
      text-align: center;
      margin-top: 15px;
      font-size: 12px;
      color: #777; /* Gray */
    }

    @media (max-width: 480px) {
      .login-card {
        padding: 25px;
      }
    }
  </style>
</head>

<body>

  <div class="login-wrapper">
    <div class="login-card">

      <div class="school-logo">
        <img src="srnhs-logo.png" alt="School Logo">
      </div>

      <div class="school-name">San Roque National High School</div>
      <div class="logo-text"><small>i</small>Vote</div>
      <div class="subtitle">Online Voting System</div>

      <h2 style="color: #333; margin-bottom: 20px;">Forgot Password</h2>
      <?php if ($message): ?>
        <div class="message"><?= $message ?></div>
      <?php endif; ?>
      <form method="POST" action="">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
        <button type="submit">Send Reset Link</button>
      </form>

      <div class="footer">
        <a href="/index.php" style="color: #1877f2; text-decoration: none;">Back to Login</a>
      </div>

    </div>
   
    <div class="footer">
      © <?php echo date("Y"); ?> San Roque NHS | All Rights Reserved
    </div>
  </div>

</body>
</html>