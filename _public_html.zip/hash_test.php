<?php
$plain = "12345";
$hash = password_hash($plain, PASSWORD_DEFAULT);
echo "<h3>Generated hash:</h3><p>$hash</p>";

if (password_verify($plain, $hash)) {
    echo "<p style='color:green;'>✅ password_verify() works correctly on this server</p>";
} else {
    echo "<p style='color:red;'>❌ password_verify() FAILED — something is wrong</p>";
}

echo "<p>PHP Version: " . PHP_VERSION . "</p>";
?>
