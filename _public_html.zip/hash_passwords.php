<?php
require 'inc/db.php';

// list of your user tables
$tables = ['admin', 'moderators', 'voters'];

foreach ($tables as $t) {
    $res = $conn->query("SELECT id, password FROM $t");
    while ($row = $res->fetch_assoc()) {
        // only hash if not already hashed
        if (!password_get_info($row['password'])['algo']) {
            $hashed = password_hash($row['password'], PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE $t SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed, $row['id']);
            $stmt->execute();
        }
    }
}
echo "✅ All passwords updated to hashed!";
?>
