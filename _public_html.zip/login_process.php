<?php
session_start();
require 'inc/db.php';

header("Content-Type: application/json"); // Important for Fetch API

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}

$id = trim($_POST['id']);
$password = trim($_POST['password']);


// 1️⃣ ADMIN LOGIN
$stmt = $conn->prepare("SELECT * FROM admin WHERE admin_id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if ($admin && password_verify($password, $admin['password'])) {
    session_regenerate_id(true);
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['name'] = $admin['name'];
    $_SESSION['role'] = 'admin';

    echo json_encode([
        "status" => "success",
        "redirect" => "admin/dashboard.php"
    ]);
    exit;
}


// 2️⃣ MODERATOR LOGIN
$stmt = $conn->prepare("SELECT * FROM moderators WHERE faculty_id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$mod = $stmt->get_result()->fetch_assoc();

if ($mod && password_verify($password, $mod['password'])) {
    session_regenerate_id(true);
    $_SESSION['moderator_id'] = $mod['id'];
    $_SESSION['first_name'] = $mod['first_name'];
    $_SESSION['last_name'] = $mod['last_name'];
    $_SESSION['school_year'] = $mod['school_year'];
    $_SESSION['role'] = 'moderator';

    echo json_encode([
        "status" => "success",
        "redirect" => "mod/dashboard.php"
    ]);
    exit;
}


// 3️⃣ VOTER LOGIN
$stmt = $conn->prepare("SELECT * FROM voters WHERE student_id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$voter = $stmt->get_result()->fetch_assoc();

if ($voter) {
    // Check muna kung 'active' ang account
    if ($voter['status'] !== 'active') {
        echo json_encode([
            "status" => "error", 
            "message" => "Account not activated. Please check your email."
        ]);
        exit;
    }

    // Kung active, i-verify ang password
    if (password_verify($password, $voter['password'])) {
        session_regenerate_id(true);
        $_SESSION['voter_id'] = $voter['id'];
        $_SESSION['firstname'] = $voter['firstname'];
        $_SESSION['lastname'] = $voter['lastname'];
        $_SESSION['grade_level'] = $voter['grade_level'];
        $_SESSION['section'] = $voter['section'];
        $_SESSION['strand'] = $voter['strand'];
        $_SESSION['role'] = 'voter';

        echo json_encode([
            "status" => "success",
            "redirect" => "voter/dashboard.php"
        ]);
        exit;
    }
}



// ❌ INVALID LOGIN
echo json_encode([
    "status" => "error",
    "message" => "Invalid ID or password."
]);
exit;

?>
