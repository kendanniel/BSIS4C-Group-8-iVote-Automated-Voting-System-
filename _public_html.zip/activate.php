<?php
require 'inc/db.php';
require 'vendor/autoload.php'; // Para sa PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_GET['token'])) {
    $token = trim($_GET['token']);

    // 1. Hanapin ang voter gamit ang token at dapat 'inactive' pa
    $stmt = $conn->prepare("SELECT * FROM voters WHERE reset_token = ? AND status = 'inactive'");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $voter_id = $user['id'];
        $email = $user['email'];
        $firstname = $user['firstname'];

        // 2. Generate Random Password (8 characters)
        $chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        $random_password = substr(str_shuffle($chars), 0, 8);
        $hashed_password = password_hash($random_password, PASSWORD_DEFAULT);

        // 3. I-update ang voter: Gawing active, i-save ang hashed password, at BURAHIN ang token
        $update = $conn->prepare("UPDATE voters SET password = ?, status = 'active', reset_token = NULL WHERE id = ?");
        $update->bind_param("si", $hashed_password, $voter_id);

        if ($update->execute()) {
            // 4. I-email ang PASSWORD sa student
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'kakaelect.ivote@gmail.com'; // IYONG GMAIL
                $mail->Password   = 'zbfmdcrrusouoskx';    // IYONG 16-DIGIT APP PASSWORD
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                $mail->setFrom('kakaelect.ivote@gmail.com', 'SRNHS iVote');
                $mail->addAddress($email, $firstname);

                $mail->isHTML(true);
                $mail->Subject = 'Account Activated - Your Login Credentials';
               $mail->Body = "<h3>Hello $firstname!</h3>
              <p>Your account is now active. You can now log in to the iVote system using your Student ID and the password below:</p>
              <h2 style='color:#1877f2; background: #f0f2f5; padding: 10px; display: inline-block;'>$random_password</h2>
              <p>Please change your password after your first login for security purposes.</p>
              <br>
              <a href='https://kakaelect.com/index.php' 
                 style='background: #1877f2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;'>
                 Click Here to Login
              </a>";

                $mail->send();
                $msg = "Success! Your account is activated. Check your email (including Spam) for your password.";
            } catch (Exception $e) {
                $msg = "Account activated, but we couldn't send the password email. Error: {$mail->ErrorInfo}";
            }
        } else {
            $msg = "Error updating account. Please contact admin.";
        }
    } else {
        $msg = "Invalid or expired activation link. Maybe you already activated your account?";
    }
} else {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account Activation</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f1f5f9; margin: 0; }
        .card { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }
        h2 { color: #0077b6; }
        p { color: #475569; line-height: 1.6; }
        .btn { display: inline-block; margin-top: 20px; padding: 12px 25px; background: #0077b6; color: white; text-decoration: none; border-radius: 6px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Activation</h2>
        <p><?php echo $msg; ?></p>
        <!--<a href="index.php" class="btn">Go to Login</a>-->
    </div>
</body>
</html>