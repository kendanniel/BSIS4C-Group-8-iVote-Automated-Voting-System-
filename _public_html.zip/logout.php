<?php
session_start();
session_unset();
session_destroy();

// Prevent caching
header("Cache-Control: no-cache, must-revalidate");
header("Expires: 0");

// Always go back to main index page
header("Location: index.php");
exit();
?>