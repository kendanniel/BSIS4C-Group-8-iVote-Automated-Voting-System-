<?php
session_start();
require 'inc/db.php'; // adjust path if needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>iVote | Login</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: url('srnhs.jpg') no-repeat center center fixed; /* Replace with your image path */
      background-size: cover; /* Covers the full screen */
      background-color: #1877f2; /* Fallback to blue if image fails */
    }

    .login-wrapper {
      position: relative;
      z-index: 2;
      width: 400px;
      max-width: 95%;
    }

    .login-card {
      background: rgba(255, 255, 255, 0.95); /* Semi-transparent white for readability over image */
      border-radius: 15px;
      padding: 35px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      text-align: center;
      color: #333;
      animation: fadeIn 0.6s ease;
      border: 1px solid #e0e0e0;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .school-logo img {
      width: 90px;
      border-radius: 50%;
      margin-bottom: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .school-name {
      font-size: 16px;
      font-weight: 500;
      margin-bottom: 5px;
      letter-spacing: 0.5px;
      color: #555;
    }

    .logo-text {
      font-size: 2.2em;
      font-weight: bold;
      margin-bottom: 5px;
      color: #1e3c72;
    }

    .logo-text small {
      color: #1877f2;
    }

    .subtitle {
      font-size: 13px;
      margin-bottom: 20px;
      color: #777;
    }

    form {
      display: flex;
      flex-direction: column;
      text-align: left;
    }

    label {
      font-size: 13px;
      margin-top: 10px;
      margin-bottom: 5px;
      color: #333;
    }

    input {
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #ddd;
      outline: none;
      font-size: 14px;
      margin-bottom: 5px;
      background: #f9f9f9;
      color: #333;
      width: 100%;
      box-sizing: border-box;
    }

    input:focus {
      box-shadow: 0 0 6px rgba(24, 119, 242, 0.3);
      border-color: #1877f2;
    }

    /* Password Container and Eye Icon */
    .password-container {
      position: relative;
      display: flex;
      align-items: center;
    }

    .toggle-password {
      position: absolute;
      right: 12px;
      cursor: pointer;
      color: #777;
      font-size: 14px;
      z-index: 10;
      /* Adjust position to account for the input's margin-bottom if necessary */
      transform: translateY(-2.5px); 
    }

    .toggle-password:hover {
      color: #1877f2;
    }

    .forgot-password {
      text-align: right;
      margin-top: 5px;
      margin-bottom: 10px;
    }

    .forgot-password a {
      color: #1877f2;
      text-decoration: none;
      font-size: 12px;
    }

    .forgot-password a:hover {
      text-decoration: underline;
    }

    button {
      margin-top: 15px;
      padding: 12px;
      border: none;
      border-radius: 8px;
      background: #1877f2;
      color: #ffffff;
      font-weight: bold;
      font-size: 14px;
      cursor: pointer;
      transition: 0.3s ease;
    }

    button:hover {
      background: #166fe5;
      transform: translateY(-2px);
    }

    .footer {
      text-align: center;
      margin-top: 15px;
      font-size: 12px;
      color: #ffffff;
    }

    @media (max-width: 480px) {
      .login-card {
        padding: 25px;
      }
    }
  </style>
</head>

<body>

  <div class="login-wrapper">
    <div class="login-card">

      <div class="school-logo">
        <img src="srnhs-logo.png" alt="School Logo">
      </div>

      <div class="school-name">San Roque National High School</div>
      <div class="logo-text"><small>i</small>Vote</div>
      <div class="subtitle">Online Voting System</div>

      <form id="loginForm" action="login_process.php" method="POST">
        <label for="id">ID Number</label>
        <input type="text" id="id" name="id" required>

        <label for="password">Password</label>
        <div class="password-container">
          <input type="password" id="password" name="password" required>
          <i class="fas fa-eye toggle-password" id="eyeIcon"></i>
        </div>

        <div class="forgot-password">
          <a href="forgot_password.php">Forgot Password?</a>
        </div>

        <button type="submit">Sign In</button>
      </form>

    </div>
    
    <div class="footer">
      © <?php echo date("Y"); ?> San Roque NHS | All Rights Reserved
    </div>
  </div>

  <script>
    // Toggle Password Visibility
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');

    eyeIcon.addEventListener('click', function() {
      // Toggle the type attribute
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      
      // Toggle the eye icon class
      this.classList.toggle('fa-eye');
      this.classList.toggle('fa-eye-slash');
    });

    // Handle form submission with AJAX to avoid page reload
    document.getElementById('loginForm').addEventListener('submit', function(e) {
      e.preventDefault(); // Prevent default form submission
      const formData = new FormData(this); // Get form data

      // Send data to server using fetch
      fetch('login_process.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json()) // Parse JSON response
      .then(data => {
        if (data.status === 'success') {
          // Redirect on success
          window.location.href = data.redirect;
        } else {
          // Show error with SweetAlert
          Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            text: data.message,
            confirmButtonColor: '#d33'
          });
        }
      })
      .catch(() => {
        // Handle any errors
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Something went wrong. Please try again.'
        });
      });
    });
  </script>

</body>
</html>