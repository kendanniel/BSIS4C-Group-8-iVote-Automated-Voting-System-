<?php
require 'inc/db.php';
$message = '';
$showForm = false;
$status = ''; 

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // 1. Check Voters
    $stmt = $conn->prepare("SELECT id, email, token_expiry FROM voters WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $table = 'voters';

    if (!$user) {
        // 2. Check Admin
        $stmt = $conn->prepare("SELECT id, email, token_expiry FROM admin WHERE reset_token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $table = 'admin';
    }

    // 3. Validate Token
    if ($user && strtotime($user['token_expiry']) > time()) {
        $showForm = true;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pass = $_POST['password'];
            $confirm_pass = $_POST['confirm_password'] ?? ''; // Added confirm password

            if ($pass !== $confirm_pass) {
                $message = "Passwords do not match!";
                $status = 'error';
            } elseif (strlen($pass) < 6) { // Basic security check
                $message = "Password must be at least 6 characters long.";
                $status = 'error';
            } else {
                $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

                $stmt = $conn->prepare("UPDATE $table SET password = ?, reset_token = NULL, token_expiry = NULL WHERE email = ?");
                $stmt->bind_param("ss", $hashed_password, $user['email']);
                
                if ($stmt->execute()) {
                    $message = "Your password has been reset successfully. <a href='index.php' style='color: #4f46e5; font-weight: 600; text-decoration: none;'>Login here</a>";
                    $showForm = false;
                    $status = 'success';
                } else {
                    $message = "Something went wrong. Please try again.";
                    $status = 'error';
                }
            }
        }
    } else {
        $message = "Invalid or expired token. Please request a new reset link.";
        $status = 'error';
    }
} else {
    $message = "No token provided.";
    $status = 'error';
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | iVote</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: url('srnhs.jpg') no-repeat center center fixed; /* Replace with your image path */
      background-size: cover; /* Covers the full screen */
      background-color: #1877f2; /* Fallback to blue if image fails */
    }


        .reset-card {
            background: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .brand-logo {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
         .school-logo img {
      width: 90px;
      border-radius: 50%;
      margin-bottom: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1); /* Adjusted shadow */
    }
    
     .school-name {
      font-size: 16px;
      font-weight: 500;
      margin-bottom: 5px;
      letter-spacing: 0.5px;
      color: #555; /* Darker color */
    }

    .logo-text {
      font-size: 2.2em;
      font-weight: bold;
      margin-bottom: 5px;
      color: #1e3c72; /* Dark blue */
    }

    .logo-text small {
      color: #1877f2; /* Blue for 'i' */
    }

    .subtitle {
      font-size: 13px;
      margin-bottom: 20px;
      color: #777; /* Gray */
    }


        .brand-logo span {
            color: #4f46e5;
        }

        h2 {
            font-size: 20px;
            color: #1f2937;
            margin-bottom: 8px;
        }

        p.subtitle {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 24px;
        }

        .form-group {
            text-align: left;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #374151;
            margin-bottom: 6px;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            border: 1px solid #d1d5db;
            font-size: 16px;
            transition: border-color 0.2s, box-shadow 0.2s;
            box-sizing: border-box;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #4f46e5;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        button {
            width: 100%;
            background-color: #4f46e5;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        button:hover {
            background-color: #4338ca;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .alert-error {
            background-color: #fef2f2;
            color: #991b1b;
            border: 1px solid #fee2e2;
        }

        .alert-success {
            background-color: #f0fdf4;
            color: #166534;
            border: 1px solid #dcfce7;
        }

        .alert-info {
            background-color: #eff6ff;
            color: #1e40af;
            border: 1px solid #dbeafe;
        }
    </style>
</head>
<body>

<div class="reset-card">
    <div class="school-logo">
        <img src="srnhs-logo.png" alt="School Logo">
      </div>

      <div class="school-name">San Roque National High School</div>
      <div class="logo-text"><small>i</small>Vote</div>
      <div class="subtitle">Online Voting System</div>

    
    <h2>Reset Password</h2>
    <p class="subtitle">Please enter your new secure password below.</p>

    <?php if ($message): ?>
        <div class="alert <?= ($status == 'success') ? 'alert-success' : (($status == 'error') ? 'alert-error' : 'alert-info') ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <?php if ($showForm): ?>
    <form method="POST">
        <div class="form-group">
            <label for="password">New Password</label>
            <input type="password" name="password" id="password" placeholder="••••••••" required autofocus>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Confirm New Password</label>
            <input type="password" name="confirm_password" id="confirm_password" placeholder="••••••••" required>
        </div>
        
        <button type="submit">Reset Password</button>
    </form>
<?php endif; ?>

    <div style="margin-top: 24px;">
        <a href="index.php" style="font-size: 13px; color: #6b7280; text-decoration: none;">&larr; Back to Login</a>
    </div>
</div>

</body>
</html>