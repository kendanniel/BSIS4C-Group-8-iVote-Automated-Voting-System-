<?php
require '../vendor/autoload.php';  // PhpSpreadsheet library
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Header row
$sheet->setCellValue('A1', 'Student ID');
$sheet->setCellValue('B1', 'Lastname');
$sheet->setCellValue('C1', 'Firstname');
$sheet->setCellValue('D1', 'Middlename');
$sheet->setCellValue('E1', 'Strand');
$sheet->setCellValue('F1', 'Grade Level');
$sheet->setCellValue('G1', 'Section');
$sheet->setCellValue('H1', 'Email');

// Optional: Example row
$sheet->setCellValue('A2', '2025-001');
$sheet->setCellValue('B2', 'Dela Cruz');
$sheet->setCellValue('C2', 'Juan');
$sheet->setCellValue('D2', 'Santos');
$sheet->setCellValue('E2', 'STEM');
$sheet->setCellValue('F2', '11');
$sheet->setCellValue('G2', 'A');
$sheet->setCellValue('H2', 'juan@example.com');

// Send file to browser for download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="voter_template.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
