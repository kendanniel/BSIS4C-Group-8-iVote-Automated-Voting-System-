<?php
session_start();
require '../inc/db.php';
if(!isset($_SESSION['admin_id'])) exit('Unauthorized');

if(!isset($_GET['id'])) exit('Missing ID');

$id = $conn->real_escape_string($_GET['id']);
$query = "SELECT * FROM moderators WHERE faculty_id='$id'";
$result = $conn->query($query);

if(!$result || $result->num_rows == 0) exit('Not found');

header('Content-Type: application/json');
echo json_encode($result->fetch_assoc());
