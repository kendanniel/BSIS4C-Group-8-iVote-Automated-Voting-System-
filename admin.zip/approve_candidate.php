<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');
error_reporting(E_ERROR | E_PARSE);

$id = $_POST['id'] ?? null;
$status = $_POST['status'] ?? null;

if (!$id || !$status) {
    echo json_encode(['success' => false, 'error' => 'Missing ID or status']);
    exit;
}

// validate status
if (!in_array($status, ['approved', 'rejected'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid status']);
    exit;
}

// check if candidate exists
$check = $conn->prepare("SELECT id FROM candidates WHERE id = ?");
$check->bind_param("i", $id);
$check->execute();
$res = $check->get_result();

if ($res->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'Candidate not found']);
    exit;
}

// update status
$update = $conn->prepare("UPDATE candidates SET status = ? WHERE id = ?");
$update->bind_param("si", $status, $id);

if ($update->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Update failed']);
}
exit;
