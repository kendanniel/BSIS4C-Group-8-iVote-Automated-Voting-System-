<?php
require '../inc/db.php'; // adjust path if needed

header('Content-Type: application/json');

if (!isset($_GET['student_id']) || trim($_GET['student_id']) === '') {
    echo json_encode(['success' => false, 'error' => 'No Student ID provided.']);
    exit;
}

$student_id = trim($_GET['student_id']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    die(json_encode(['success' => false, 'error' => 'Database connection not found.']));
}

$stmt = $conn->prepare("SELECT * FROM voters WHERE student_id = ?");
$stmt->bind_param('s', $student_id);
$stmt->execute();
$res = $stmt->get_result();
$voter = $res->fetch_assoc();

if ($voter) {
    $grade_section = trim(($voter['grade_level'] ?? '') . ' ' . ($voter['strand'] ?? '') . ' ' . ($voter['section'] ?? ''));
    echo json_encode([
        'success' => true,
        'student_id' => $voter['student_id'],
        'firstname' => $voter['firstname'],
        'lastname' => $voter['lastname'],
        'grade_section' => trim($grade_section)
    ]);
} else {
    echo json_encode(['success' => false, 'error' => 'No voter found with that Student ID.']);
}
