<?php
require '../inc/db.php';
header('Content-Type: application/json');

// Get positions
$positionsData = $conn->query("SELECT id FROM positions ORDER BY position_order ASC");
$positions = [];
while ($row = $positionsData->fetch_assoc()) {
    $positions[] = $row['id'];
}

$result = [];

foreach ($positions as $pos_id) {
    $stmt = $conn->prepare("
        SELECT c.id, c.firstname, c.lastname,
               (SELECT COUNT(*) FROM votes v WHERE v.candidate_id = c.id AND v.position_id = c.position_id) AS votes
        FROM candidates c
        WHERE c.position_id = ?
    ");
    $stmt->bind_param("i", $pos_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $candidates = [];
    $maxVotes = 0;
    while ($row = $res->fetch_assoc()) {
        $row['fullname'] = $row['firstname'] . ' ' . $row['lastname'];
        $candidates[] = $row;
        if ($row['votes'] > $maxVotes) $maxVotes = $row['votes'];
    }

    foreach ($candidates as &$candidate) {
        $candidate['percent'] = ($maxVotes > 0) ? round(($candidate['votes'] / $maxVotes) * 100) : 0;
    }
    unset($candidate);

    $result[$pos_id] = $candidates;
}

echo json_encode($result);
