<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: election.php");
    exit();
}

$id = intval($_GET['id']);
$query = "SELECT * FROM elections WHERE id = $id";
$result = $conn->query($query);

if (!$result || $result->num_rows == 0) {
    die("Election not found!");
}

$election = $result->fetch_assoc();

// Update election
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $school_year = $conn->real_escape_string($_POST['school_year']);
    $start_datetime = $_POST['start_datetime'];
    $end_datetime = $_POST['end_datetime'];
    $status = $conn->real_escape_string($_POST['status']);

    $update = "UPDATE elections 
               SET title='$title', school_year='$school_year', start_datetime='$start_datetime', end_datetime='$end_datetime', status='$status'
               WHERE id=$id";

    if ($conn->query($update)) {
        echo "<script>alert('Election updated successfully!'); window.location='election.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error updating election: {$conn->error}');</script>";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Election</title>
<link rel="stylesheet" href="dashboard.css">
<style>
.main-content {
  padding: 30px;
}
.edit-container {
  max-width: 650px;
  background: #fff;
  padding: 25px;
  border-radius: 15px;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
  margin: auto;
}
.edit-container h2 {
  text-align: center;
  margin-bottom: 20px;
  color: #333;
}
form label {
  font-weight: 600;
  display: block;
  margin-top: 12px;
}
form input, form select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-top: 5px;
}
.btn-group {
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
}
.btn-group button {
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
}
.save-btn {
  background: #28a745;
  color: #fff;
}
.cancel-btn {
  background: #ccc;
}
.save-btn:hover {
  background: #218838;
}
.cancel-btn:hover {
  background: #b3b3b3;
}
</style>
</head>
<body>
<div class="sidebar">
  <div class="logo">
    <img src="images/logo.png" alt="Logo">
    <h3>SAN ROQUE NHS</h3>
  </div>
  <ul class="nav-links">
    <li onclick="location.href='dashboard.php'"><i>🏠</i>Dashboard</li>
    <li class="active" onclick="location.href='election.php'"><i>🗳️</i>Election</li>
    <li onclick="location.href='candidates.php'"><i>👤</i>Candidates</li>
    <li onclick="location.href='voters.php'"><i>🧾</i>Voters</li>
    <li onclick="location.href='moderators.php'"><i>👥</i>Moderators</li>
    <li onclick="location.href='reports.php'"><i>📊</i>Reports</li>
  </ul>
  <a class="logout" href="logout.php">🚪 Log Out</a>
</div>

<div class="main-content">
  <div class="edit-container">
    <h2>Edit Election</h2>
    <form method="POST">
      <label>Election Title</label>
      <input type="text" name="title" value="<?php echo htmlspecialchars($election['title']); ?>" required>

      <label>School Year</label>
      <select name="school_year" required>
        <option <?php if ($election['school_year'] == '2024-2025') echo 'selected'; ?>>2024-2025</option>
        <option <?php if ($election['school_year'] == '2025-2026') echo 'selected'; ?>>2025-2026</option>
        <option <?php if ($election['school_year'] == '2026-2027') echo 'selected'; ?>>2026-2027</option>
      </select>

      <label>Start Date & Time</label>
      <input type="datetime-local" name="start_datetime" value="<?php echo date('Y-m-d\TH:i', strtotime($election['start_datetime'])); ?>" required>

      <label>End Date & Time</label>
      <input type="datetime-local" name="end_datetime" value="<?php echo date('Y-m-d\TH:i', strtotime($election['end_datetime'])); ?>" required>

      <label>Status</label>
      <select name="status" required>
        <option value="upcoming" <?php if ($election['status']=='upcoming') echo 'selected'; ?>>Upcoming</option>
        <option value="active" <?php if ($election['status']=='active') echo 'selected'; ?>>Active</option>
        <option value="completed" <?php if ($election['status']=='completed') echo 'selected'; ?>>Completed</option>
        <option value="archived" <?php if ($election['status']=='archived') echo 'selected'; ?>>Archived</option>
      </select>

      <div class="btn-group">
        <button type="button" class="cancel-btn" onclick="window.location.href='election.php'">Cancel</button>
        <button type="submit" class="save-btn">Save Changes</button>
      </div>
    </form>
  </div>
</div>
</body>
</html>
