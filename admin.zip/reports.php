<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../inc/db.php';
require_once '../vendor/autoload.php'; // mPDF

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// 1. KUNIN ANG CURRENT ELECTION (is_archived = 0)
$recentElectionRes = $conn->query("SELECT * FROM elections WHERE is_archived = 0 ORDER BY created_at DESC LIMIT 1");
$recentElection = ($recentElectionRes && $recentElectionRes->num_rows > 0) ? $recentElectionRes->fetch_assoc() : null;

if (!$recentElection) {
    echo "<h1>No active election found.</h1>";
    exit;
}

$election_id = $recentElection['id'];
$recentElectionTitle = $recentElection['title'];

// 2. KUNIN ANG POSITIONS PARA SA ELECTION NA ITO
$positionsData = $conn->query("SELECT id, name FROM positions WHERE election_id = '$election_id' AND is_archived = 0 ORDER BY position_order ASC");
$positions = [];
while ($row = $positionsData->fetch_assoc()) {
    $positions[$row['id']] = $row['name'];
}

$selectedPosition = $_POST['position'] ?? 'all';

// 3. KUNIN ANG TALLY DATA
$votesData = [];
foreach ($positions as $pos_id => $pos_name) {
    if ($selectedPosition !== 'all' && $selectedPosition != $pos_id) continue;

    // Mas accurate na query: Bilangin ang votes na match sa candidate_id 
    // at siguraduhin na ang votes ay hindi archived.
    $stmt = $conn->prepare("
        SELECT c.id, c.firstname, c.lastname,
               (SELECT COUNT(*) FROM votes v 
                WHERE v.candidate_id = c.id 
                AND v.is_archived = 0) AS votes
        FROM candidates c
        WHERE c.position_id = ? 
          AND c.election_id = ? 
          AND c.is_archived = 0
        ORDER BY votes DESC
    ");
    $stmt->bind_param("ii", $pos_id, $election_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $posTotalVotes = 0;
    $tempCandidates = [];
    while ($row = $res->fetch_assoc()) {
        $row['fullname'] = $row['firstname'] . ' ' . $row['lastname'];
        $posTotalVotes += $row['votes'];
        $tempCandidates[] = $row;
    }

    foreach ($tempCandidates as &$cand) {
        $cand['percent'] = ($posTotalVotes > 0) ? round(($cand['votes'] / $posTotalVotes) * 100) : 0;
    }
    $votesData[$pos_id] = $tempCandidates;
}

// 4. PDF GENERATION LOGIC (FPDF VERSION)
if (isset($_POST['generate_report'])) {
    
    // Path papunta sa fpdf.php sa loob ng fpdf folder
    $fpdf_path = '../fpdf/fpdf.php'; 
    
    if (!file_exists($fpdf_path)) {
        die("Error: fpdf.php not found. Pakicheck kung nasaan ang file sa loob ng fpdf folder.");
    }

    require($fpdf_path);

    class PDF extends FPDF {
        function Header() {
            // Logo kung meron (Optional: palitan ang 'srnhs-logo.png' kung iba ang filename)
            // $this->Image('../srnhs-logo.png', 10, 6, 20); 

            $this->SetFont('Arial', 'B', 15);
            $this->Cell(0, 10, 'SAN ROQUE NATIONAL HIGH SCHOOL', 0, 1, 'C');
            
            $this->SetFont('Arial', 'B', 12);
            $this->Cell(0, 7, 'OFFICIAL ELECTION REPORT', 0, 1, 'C');
            
            // --- INDICATE SCHOOL YEAR HERE ---
            $currentYear = date('Y');
            $nextYear = date('Y') + 1;
            $schoolYear = "S.Y. " . $currentYear . "-" . $nextYear;
            
            $this->SetFont('Arial', '', 11);
            $this->Cell(0, 7, $schoolYear, 0, 1, 'C');
            
            $this->SetFont('Arial', 'I', 9);
            $this->Cell(0, 7, 'Date Generated: ' . date('F d, Y g:i A'), 0, 1, 'C');
            $this->Ln(5);
            $this->Line(10, $this->GetY(), 200, $this->GetY()); // Horizontal line
            $this->Ln(5);
        }

        function Footer() {
            $this->SetY(-15);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        }
    }

    if (ob_get_length()) ob_end_clean();

    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    
    // Election Title
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetFillColor(230, 230, 230);
    $pdf->Cell(0, 10, "Election Title: " . $GLOBALS['recentElectionTitle'], 1, 1, 'L', true);
    $pdf->Ln(5);

    foreach ($votesData as $pos_id => $candidates) {
        // Position Header
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->SetFillColor(30, 58, 95); 
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(0, 10, strtoupper($positions[$pos_id]), 1, 1, 'C', true);
        
        // Table Headers
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(20, 8, 'Rank', 1, 0, 'C');
        $pdf->Cell(100, 8, 'Candidate Name', 1, 0, 'L');
        $pdf->Cell(35, 8, 'Votes', 1, 0, 'C');
        $pdf->Cell(35, 8, '%', 1, 0, 'C');
        $pdf->Ln();

        // Candidates Data
        $pdf->SetFont('Arial', '', 10);
        foreach ($candidates as $idx => $c) {
            $isWinner = ($idx === 0 && $c['votes'] > 0);
            if($isWinner) {
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->SetFillColor(240, 255, 240); // Light green background para sa winner
            } else {
                $pdf->SetFillColor(255, 255, 255);
            }
            
            $name = ($isWinner ? 'WINNER: ' : '') . $c['fullname'];
            
            $pdf->Cell(20, 8, $idx + 1, 1, 0, 'C', $isWinner);
            $pdf->Cell(100, 8, $name, 1, 0, 'L', $isWinner);
            $pdf->Cell(35, 8, number_format($c['votes']), 1, 0, 'C', $isWinner);
            $pdf->Cell(35, 8, $c['percent'] . '%', 1, 0, 'C', $isWinner);
            $pdf->Ln();
            
            $pdf->SetFont('Arial', '', 10);
        }
        $pdf->Ln(10);
    }

    $pdf->Output('D', 'Election_Report_' . date('Ymd') . '.pdf');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Election Reports</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="dashboard.css">
<link rel="stylesheet" href="admin_reports.css">
<style>
    .position-section {
        margin-bottom: 20px;
        border-bottom: 1px solid #ddd;
        padding-bottom: 15px;
        display: flex;
        flex-direction: row;
        gap: 15px;
        align-items: flex-start;
    }
    .position-section:last-child {
        border-bottom: none;
    }
    .position-section h5 {
        color: #555;
        font-size: 1.1em;
        margin-bottom: 10px;
        flex-basis: 100%;
    }
    .chart-container {
        flex: 0 0 200px;
        height: 150px;
    }
    .candidate-list {
        flex: 1;
        min-width: 250px;
    }
    .candidate {
        margin-bottom: 8px;
        padding: 6px;
        background-color: #f8f9fa;
        border-radius: 4px;
        border-left: 3px solid #007bff;
        display: flex;
        align-items: center;
    }
    .rank {
        font-weight: bold;
        color: #007bff;
        margin-right: 6px;
        font-size: 0.9em;
    }
    .bar {
        flex: 1;
    }
    .name {
        font-weight: 500;
        font-size: 0.9em;
        margin-bottom: 4px;
    }
    .progress {
        background-color: #e9ecef;
        border-radius: 6px;
        height: 5px;
        overflow: hidden;
        position: relative;
    }
    .progress::after {
        content: '';
        height: 100%;
        background: linear-gradient(90deg, #28a745 0%, #20c997 100%);
        transition: width 0.5s ease;
        width: var(--width);
    }
    .tally-section {
  background: #fff;
  border-radius: 16px;
  padding: 28px 28px;
  box-shadow: 0 4px 18px rgba(15,23,42,0.07);
  border: 1px solid #e8eef5;
}

/* ===== POSITION TALLY BLOCK ===== */
.position-tally {
  margin-bottom: 32px;
  padding-bottom: 32px;
  border-bottom: 1px solid #f1f5f9;
}

.position-tally:last-child {
  margin-bottom: 0;
  padding-bottom: 0;
  border-bottom: none;
}

.position-tally-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
}

.position-tally-icon {
  width: 32px; height: 32px;
  border-radius: 8px;
  background: linear-gradient(135deg, #1e3a5f, #266bc5);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}

.position-tally-name {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 16px;
  font-weight: 700;
  color: #1e293b;
}

.position-tally-body {
  display: flex;
  align-items: center;
  gap: 28px;
  flex-wrap: wrap;
}

/* Bar chart area */
.tally-bars {
  flex: 1;
  min-width: 220px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.tally-bar-row {
  display: flex;
  align-items: center;
  gap: 10px;
}

.tally-bar-name {
  width: 160px;
  font-size: 12.5px;
  font-weight: 600;
  color: #334155;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

.tally-bar-track {
  flex: 1;
  height: 10px;
  background: #f1f5f9;
  border-radius: 99px;
  overflow: hidden;
}

.tally-bar-fill {
  height: 100%;
  border-radius: 99px;
  background: linear-gradient(90deg, #3b82f6, #6366f1);
  transition: width 0.8s ease;
}

.tally-bar-fill.leader {
  background: linear-gradient(90deg, #0ea5e9, #3b82f6);
}

.tally-bar-votes {
  font-size: 12px;
  font-weight: 700;
  color: #3b82f6;
  width: 52px;
  text-align: right;
  flex-shrink: 0;
}

/* Pie chart wrapper */
.tally-pie-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.tally-pie-label {
  font-size: 11px;
  color: #94a3b8;
  font-weight: 500;
}

/* ===== ANIMATIONS ===== */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(16px); }
  to   { opacity: 1; transform: translateY(0); }
}

.anim { animation: fadeInUp 0.45s ease both; }
    @media (max-width: 768px) {
        .position-section {
            flex-direction: column;
            gap: 10px;
        }
        .chart-container {
            flex: 0 0 auto;
            width: 100%;
            height: 120px;
        }
        .candidate-list {
            min-width: auto;
        }
    }
</style>
</head>
<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;width:100%;">

<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(#0077b6);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Admin</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">
    

<div class="nav-btn" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn" onclick="location.href='election.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-80q-33 0-56.5-23.5T120-160v-182l110-125 57 57-80 90h546l-78-88 57-57 108 123v182q0 33-23.5 56.5T760-80H200Zm0-80h560v-80H200v80Zm225-225L284-526q-23-23-22.5-56.5T285-639l196-196q23-23 57-24t57 22l141 141q23 23 24 56t-22 56L538-384q-23 23-56.5 22.5T425-385Zm255-254L539-780 341-582l141 141 198-198ZM200-160v-80 80Z"/></svg> Election</div>
<div class="nav-btn" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn" onclick="location.href='moderators.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M609-389q-29-29-29-71t29-71q29-29 71-29t71 29q29 29 29 71t-29 71q-29 29-71 29t-71-29ZM480-160v-56q0-24 12.5-44.5T528-290q36-15 74.5-22.5T680-320q39 0 77.5 7.5T832-290q23 9 35.5 29.5T880-216v56H480ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm113-113ZM80-160v-112q0-34 17-62.5t47-43.5q60-30 124.5-46T400-440q35 0 70 6t70 14l-34 34-34 34q-18-5-36-6.5t-36-1.5q-58 0-113.5 14T180-306q-10 5-15 14t-5 20v32h240v80H80Zm320-80Zm56.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5Z"/></svg> Moderators</div>
<div class="nav-btn active" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>

<style>
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}
</style>

<!-- MAIN CONTENT -->
<div style="margin-left:260px;padding:30px;width:100%;">


</header>


<div class="page-header">
    <h3>Election Reports</h3>
</div>

<form method="POST">
<div class="filter-section">
    <select name="position">
        <option value="all">All Positions (<?= htmlspecialchars($recentElectionTitle) ?>)</option>
        <?php foreach ($positions as $id => $name): ?>
            <option value="<?= $id ?>" <?= ($selectedPosition==$id)?'selected':''; ?>>
                <?= htmlspecialchars($name) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button type="submit" name="generate_report" class="btn purple">📄 Download as PDF</button>
</div>
</form>

 <div class="tally-section">
    <?php foreach ($votesData as $pos_id => $candidates): ?>
        <div class="position-tally">
            <h4 class="position-tally-name"><?= htmlspecialchars($positions[$pos_id]) ?></h4>
            <div class="position-tally-body">
                <div class="tally-bars">
                    <?php 
                    $maxVotes = max(array_column($candidates, 'votes') ?: [1]);
                    foreach ($candidates as $idx => $cand): 
                        $isLeader = ($idx === 0 && $cand['votes'] > 0);
                        $barWidth = ($maxVotes > 0) ? ($cand['votes'] / $maxVotes) * 100 : 0;
                    ?>
                    <div class="tally-bar-row">
                        <div class="tally-bar-name"><?= ($isLeader ? '🏆 ' : '') . htmlspecialchars($cand['fullname']) ?></div>
                        <div class="tally-bar-track">
                            <div class="tally-bar-fill <?= $isLeader ? 'leader' : '' ?>" style="width: <?= $barWidth ?>%;"></div>
                        </div>
                        <div class="tally-bar-votes"><?= $cand['votes'] ?> (<?= $cand['percent'] ?>%)</div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="tally-pie-wrap">
                    <canvas id="pie-chart-<?= $pos_id ?>" width="160" height="130"></canvas>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
  </div>

<script>
// Pass PHP data to JS
const votesData = <?php echo json_encode($votesData); ?>;
const positions = <?php echo json_encode($positions); ?>;

// Uniform color palette for pie charts
const colorPalette = [
    '#3b82f6', '#6366f1', '#14b8a6', '#f59e0b', '#ec4899', '#10b981', '#f97316', '#8b5cf6', '#06b6d4', '#ef4444'
];

// Create pie charts for each position
for (let pos_id in votesData) {
    const ctx = document.getElementById('pie-chart-' + pos_id).getContext('2d');
    const labels = votesData[pos_id].map(c => c.fullname);
    const data = votesData[pos_id].map(c => c.votes);
    const colors = votesData[pos_id].map((c, index) => colorPalette[index % colorPalette.length]);

    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderColor: '#fff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                            return `${label}: ${value} votes (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}
</script>

</body>
</html>
