<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    exit('Unauthorized');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $title = $conn->real_escape_string($_POST['title']);
    $school_year = $conn->real_escape_string($_POST['school_year']);
    $start_datetime = $_POST['start_datetime'];
    $end_datetime = $_POST['end_datetime'];
    $status = $conn->real_escape_string($_POST['status']);

    $update = "UPDATE elections SET 
        title='$title', 
        school_year='$school_year', 
        start_datetime='$start_datetime', 
        end_datetime='$end_datetime', 
        status='$status' 
        WHERE id=$id";

    if ($conn->query($update)) {
        echo "Election updated successfully!";
    } else {
        http_response_code(500);
        echo "Error updating election: " . $conn->error;
    }
}
?>
