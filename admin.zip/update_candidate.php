<?php
session_start();
require '../inc/db.php';

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Setup DB (same logic as your main file)
$use_pdo = false;
$use_mysqli = false;
$pdo = $pdo ?? null;
$mysqli = $conn ?? null;

if ($pdo instanceof PDO) {
    $use_pdo = true;
} elseif ($mysqli instanceof mysqli) {
    $use_mysqli = true;
} else {
    echo json_encode(['success' => false, 'message' => 'Database not connected']);
    exit;
}

// Helper function
function db_prepare_execute($sql, $params = []) {
    global $use_pdo, $use_mysqli, $pdo, $mysqli;
    if ($use_pdo) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } else {
        $stmt = $mysqli->prepare($sql);
        if (!$stmt) throw new Exception("MySQLi prepare failed: " . $mysqli->error);
        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        return $stmt;
    }
}

// Get POST data
$id = $_POST['id'] ?? null;
$firstname = trim($_POST['firstname'] ?? '');
$lastname  = trim($_POST['lastname'] ?? '');
$grade_section = trim($_POST['grade_section'] ?? '');
$position_id = $_POST['position_id'] ?? null;
$partylist_id = $_POST['partylist_id'] ?? null;
$biography = trim($_POST['biography'] ?? '');

if (!$id || !$firstname || !$lastname || !$position_id || !$partylist_id) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $sql = "UPDATE candidates 
            SET firstname = ?, lastname = ?, grade_section = ?, position_id = ?, partylist_id = ?, biography = ?
            WHERE id = ?";
    db_prepare_execute($sql, [$firstname, $lastname, $grade_section, $position_id, $partylist_id, $biography, $id]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
