<?php
session_start();
require '../inc/db.php';
if(!isset($_SESSION['admin_id'])) exit('Unauthorized');

if(!isset($_GET['id'])) exit('Missing ID');
$id = $conn->real_escape_string($_GET['id']);

$conn->query("UPDATE moderators SET status='archived' WHERE faculty_id='$id'");
header('Location: moderators.php');
