<?php
session_start();
require '../inc/db.php';
if(!isset($_SESSION['admin_id'])) exit('Unauthorized');

if($_SERVER['REQUEST_METHOD']=='POST'){
    $id = $conn->real_escape_string($_POST['faculty_id']);
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $level = $conn->real_escape_string($_POST['level']);
    $status = $conn->real_escape_string($_POST['status']);

    $update = "UPDATE moderators SET first_name='$first_name', last_name='$last_name', email='$email', level='$level', status='$status' WHERE faculty_id='$id'";
    if($conn->query($update)){
        header('Location: moderators.php');
    } else {
        echo "Error: ".$conn->error;
    }
}
