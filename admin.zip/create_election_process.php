<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title']);
    $school_year = trim($_POST['school_year']);
    $filing_start = $_POST['filing_start'];
    $filing_end = $_POST['filing_end'];
    $start_datetime = $_POST['start_datetime'];
    $end_datetime = $_POST['end_datetime'];
    $created_by = $_SESSION['admin_id'];

    if (empty($title) || empty($school_year) || empty($filing_start) || empty($filing_end) || empty($start_datetime) || empty($end_datetime)) {
        echo "<script>alert('Please fill all fields');window.history.back();</script>";
        exit();
    }

    try {
        
        // --- DATE SEQUENCE VALIDATION ---
$f_start = strtotime($filing_start);
$f_end   = strtotime($filing_end);
$e_start = strtotime($start_datetime);
$e_end   = strtotime($end_datetime);

if ($f_end <= $f_start) {
    echo "<script>alert('Error: Filing End must be after Filing Start.');window.history.back();</script>";
    exit();
}

if ($e_start < $f_end) {
    echo "<script>alert('Error: Election cannot start while Filing is still ongoing. Election must start after Filing End.');window.history.back();</script>";
    exit();
}

if ($e_end <= $e_start) {
    echo "<script>alert('Error: Election End must be after Election Start.');window.history.back();</script>";
    exit();
}
// --------------------------------
      // --- 🧹 GRAND CLEANUP & ARCHIVE START ---

// 1. Archive Elections
$conn->query("UPDATE elections SET is_archived = 1, status = 'ended' WHERE is_archived = 0");

// 2. Archive Candidates
$conn->query("UPDATE candidates SET is_archived = 1, status = 'archived' WHERE is_archived = 0");

// 3. Archive Partylist at Positions
$conn->query("UPDATE partylist SET is_archived = 1 WHERE is_archived = 0");
$conn->query("UPDATE positions SET is_archived = 1 WHERE is_archived = 0");

// 4. Archive Votes (Base sa screenshot mo, may is_archived column ang votes table)
$conn->query("UPDATE votes SET is_archived = 1 WHERE is_archived = 0");

// 5. Reset Voters (is_candidate lang ang i-reset natin dito)
$conn->query("UPDATE voters SET is_candidate = 0"); 

// --- 🧹 GRAND CLEANUP & ARCHIVE END ---

        $status = "upcoming";

        $stmt = $conn->prepare("
            INSERT INTO elections 
            (title, school_year, filing_start, filing_end, start_datetime, end_datetime, created_by, status, filing_status, is_archived, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, NOW())
        ");

        $stmt->bind_param(
            "ssssssss",
            $title, $school_year, $filing_start, $filing_end, $start_datetime, $end_datetime, $created_by, $status
        );

        if ($stmt->execute()) {
            echo "<script>
            alert('Election created successfully! Previous data archived.');
            window.location='election.php';
            </script>";
        } else {
            throw new Exception($stmt->error);
        }

        $stmt->close();
    } catch (Exception $e) {
        // Ito ang magsasabi kung ano talaga ang error imbes na "500 Error" lang
        die("Database Error: " . $e->getMessage());
    }

    $conn->close();
}
?>