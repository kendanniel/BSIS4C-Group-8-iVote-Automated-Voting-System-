<?php
// ✅ Securely hash all unencrypted passwords in the voters table
require '../inc/db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'count' => 0, 'message' => ''];

try {
    // ✅ Verify DB connection
    if (!$conn) {
        throw new Exception("Database connection failed.");
    }

    // ✅ Fetch voters whose passwords are not yet hashed
    $sql = "SELECT id, password FROM voters";
    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }

    $count = 0;

    while ($row = $result->fetch_assoc()) {
        $password = $row['password'];

        // ✅ Only hash if not already hashed (bcrypt hashes start with $2y$)
        if (strpos($password, '$2y$') !== 0) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $update = $conn->prepare("UPDATE voters SET password = ? WHERE id = ?");
            $update->bind_param('si', $hashed, $row['id']);
            if ($update->execute()) {
                $count++;
            }
        }
    }

    $response = [
        'success' => true,
        'count' => $count,
        'message' => $count > 0 ? "Hashed $count password(s)." : "No passwords needed hashing."
    ];
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>
