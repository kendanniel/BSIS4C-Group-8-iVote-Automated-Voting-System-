<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    exit('Unauthorized');
}

if (!isset($_GET['id'])) {
    http_response_code(400);
    exit('Missing election ID');
}

$id = intval($_GET['id']);
$query = "SELECT * FROM elections WHERE id=$id";
$result = $conn->query($query);

if (!$result || $result->num_rows === 0) {
    http_response_code(404);
    exit('Election not found');
}

$election = $result->fetch_assoc();

// Return JSON
header('Content-Type: application/json');
echo json_encode([
    'id' => $election['id'],
    'title' => $election['title'],
    'school_year' => $election['school_year'],
    'start_datetime' => $election['start_datetime'],
    'end_datetime' => $election['end_datetime'],
    'status' => $election['status']
]);
?>
