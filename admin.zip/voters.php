<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require '../inc/db.php';            // must define $conn (mysqli)
require '../vendor/autoload.php';  // composer autoloader - PhpSpreadsheet installed

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PhpOffice\PhpSpreadsheet\IOFactory;

// Gawa tayo ng function para hindi paulit-ulit ang code
function sendActivationEmail($email, $name, $token) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'kakaelect.ivote@gmail.com'; // IYONG GMAIL
        $mail->Password   = 'zbfmdcrrusouoskx';    // IYONG 16-DIGIT APP PASSWORD
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('kakaelect.ivote@gmail.com', 'SRNHS iVote');
        $mail->addAddress($email, $name);

        $link = "https://kakaelect.com/activate.php?token=" . $token;

        $mail->isHTML(true);
        $mail->Subject = 'iVote Account Activation';
        $mail->Body    = "Hello $name,<br><br>Welcome to SRNHS iVote! To start voting, please activate your account by clicking the link below:<br><br><a href='$link' style='padding:10px; background:blue; color:white; text-decoration:none;'>ACTIVATE ACCOUNT</a><br><br>If the button doesn't work, copy this: $link";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
$current_page = basename($_SERVER['PHP_SELF']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection not found. Ensure inc/db.php defines \$conn as mysqli.");
}

/* ---------- helper ---------- */
function mysqli_prepare_execute($conn, $sql, $params = []) {
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    if (!empty($params)) {
        $types = str_repeat('s', count($params)); 
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

/* ---------- Handle single add voter ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_voter'])) {
    $student_id  = trim($_POST['student_id'] ?? '');
    $grade_section = trim($_POST['grade_section'] ?? '');
    $first_name  = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name   = trim($_POST['last_name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $password = null;
    $status   = 'inactive';

    $grade_level = '';
    $strand = '';
    $section = '';

    if (!empty($grade_section)) {
        $parts = preg_split('/[-,]/', $grade_section);
        if (count($parts) >= 2) {
            $grade_level = trim($parts[0]);
            $rest = trim($parts[1]);
            $restParts = explode(' ', $rest, 2);
            $strand = trim($restParts[0]);
            $section = $restParts[1] ?? '';
        } else {
            $grade_level = trim($grade_section);
        }
    }

    if ($student_id === '' || $first_name === '' || $last_name === '') {
        $error = "Student ID, First Name and Last Name are required.";
    } else {
        $chk = $conn->prepare("SELECT COUNT(*) AS c FROM voters WHERE student_id = ?");
        $chk->bind_param('s', $student_id);
        $chk->execute();
        $res = $chk->get_result()->fetch_assoc();
        $chk->close();
        $exists = $res['c'] ?? 0;

        if ($exists > 0) {
            $error = "Student ID already exists.";
        } else {
            try {
                $token = bin2hex(random_bytes(16));
                mysqli_prepare_execute($conn,
                    "INSERT INTO voters (student_id, lastname, firstname, middlename, strand, grade_level, section, email, password, status, reset_token)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$student_id, $last_name, $first_name, $middle_name, $strand, $grade_level, $section, $email, $password, $status, $token]
                );
                sendActivationEmail($email, $first_name, $token);
                $success = "Voter saved and activation email sent.";
            } catch (Exception $e) {
                $error = "Failed to add voter: " . $e->getMessage();
            }
        }
    }
}

/* ---------- Handle bulk import ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_voters'])) {
    if (!empty($_FILES['file']['tmp_name'])) {
        $fileTmp = $_FILES['file']['tmp_name'];
        try {
            $inputFileType = IOFactory::identify($fileTmp);
            $reader = IOFactory::createReader($inputFileType);
            $spreadsheet = $reader->load($fileTmp);
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray(null, true, true, true);

            $inserted = 0;
            foreach ($rows as $index => $row) {
                if ($index == 1) continue;
                $student_id = trim($row['A'] ?? '');
                $lastname   = trim($row['B'] ?? '');
                $firstname  = trim($row['C'] ?? '');
                $middlename = trim($row['D'] ?? '');
                $strand     = trim($row['E'] ?? '');
                $grade_level= trim($row['F'] ?? '');
                $section    = trim($row['G'] ?? '');
                $email      = trim($row['H'] ?? '');
                $password = null;
                $status   = 'inactive';

                if ($student_id === '' || $firstname === '' || $lastname === '') continue;
                
                $chk = $conn->prepare("SELECT COUNT(*) AS c FROM voters WHERE student_id = ?");
                $chk->bind_param('s', $student_id);
                $chk->execute();
                $cres = $chk->get_result()->fetch_assoc();
                $chk->close();

                if (($cres['c'] ?? 0) > 0) continue;

                $token = bin2hex(random_bytes(16));
                mysqli_prepare_execute($conn,
                    "INSERT INTO voters (student_id, lastname, firstname, middlename, strand, grade_level, section, email, password, status, reset_token)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$student_id, $lastname, $firstname, $middlename, $strand, $grade_level, $section, $email, $password, $status, $token]
                );
                sendActivationEmail($email, $firstname, $token); 
                $inserted++;
            }
            $success = "$inserted voter(s) successfully imported.";
        } catch (Exception $e) {
            $error = "Import error: " . $e->getMessage();
        }
    } else {
        $error = "Please select a file to upload.";
    }
}

/* ---------- Handle voter edit ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_voter'])) {
    $id = intval($_POST['voter_id'] ?? 0);
    $student_id = trim($_POST['student_id'] ?? '');
    $grade_section = trim($_POST['grade_section'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    $grade_level = ''; $strand = ''; $section = '';
    if (!empty($grade_section)) {
        $parts = preg_split('/[-,]/', $grade_section);
        if (count($parts) >= 2) {
            $grade_level = trim($parts[0]);
            $rest = trim($parts[1]);
            $restParts = explode(' ', $rest, 2);
            $strand = trim($restParts[0]);
            $section = $restParts[1] ?? '';
        } else {
            $grade_level = trim($grade_section);
        }
    }

    if ($id > 0 && $student_id !== '' && $first_name !== '' && $last_name !== '') {
        $stmt = $conn->prepare("UPDATE voters SET student_id=?, firstname=?, middlename=?, lastname=?, grade_level=?, strand=?, section=?, email=? WHERE id=?");
        $stmt->bind_param('ssssssssi', $student_id, $first_name, $middle_name, $last_name, $grade_level, $strand, $section, $email, $id);
        if ($stmt->execute()) {
            $success = "Voter updated successfully.";
        } else {
            $error = "Failed to update voter.";
        }
        $stmt->close();
    }
}

/* ---------- Fetch voters for display with Filter ---------- */
$filter_grade = $_GET['filter_grade'] ?? '';
$sql = "SELECT * FROM voters";
$params = [];
if ($filter_grade !== '') {
    $sql .= " WHERE grade_level = ?";
    $params[] = $filter_grade;
}
$sql .= " ORDER BY id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param("s", $params[0]);
}
$stmt->execute();
$voters = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get unique grade levels for the filter dropdown
$grade_res = $conn->query("SELECT DISTINCT grade_level FROM voters WHERE grade_level != '' ORDER BY grade_level ASC");
$all_grades = $grade_res ? $grade_res->fetch_all(MYSQLI_ASSOC) : [];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin - Manage Voters</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  
  <style>
 * { box-sizing: border-box; }
body { margin: 0; font-family: 'DM Sans', Poppins, sans-serif; background: #f0f4f8; }
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}



    /* Main Content Responsiveness */
    .main-content { 
        margin-left: 240px; 
        padding: 30px; 
        width: calc(100% - 240px); 
        box-sizing: border-box; 
    }

    .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
    
    /* Stats and Table */
    .stat-box { padding: 20px; border-radius: 12px; color: white; margin-bottom: 25px; width: fit-content; min-width: 220px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .stat-box.purple { background: linear-gradient(135deg, #8b5cf6, #6d28d9); }
    
    .table-container { 
        background: white; 
        border-radius: 10px; 
        padding: 10px; 
        box-shadow: 0 4px 6px rgba(0,0,0,0.05); 
        overflow-x: auto; /* This makes the table fit on small screens */
    }

    .data-table { width: 100%; border-collapse: collapse; min-width: 800px; }
    .data-table th, .data-table td { padding: 14px 15px; text-align: left; border-bottom: 1px solid #e2e8f0; }
    .data-table th { background: #f8fafc; font-weight: 600; color: #475569; }

    /* Modals */
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.5);
        align-items: center;
        justify-content: center;
    }
    .modal-content {
        background: white;
        padding: 30px;
        border-radius: 12px;
        width: 100%;
        max-width: 500px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }

    /* Form UI */
    .form-group { margin-bottom: 15px; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: 500; color: #334155; }
    .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px; box-sizing: border-box; }
    
    .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; color: white; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
    .btn.blue { background: #3b82f6; }
    .btn.blue:hover { background: #2563eb; }
    .btn-save { background: #10b981; color: white; border: none; border-radius: 6px; padding: 10px 20px; cursor: pointer; }
    .btn-cancel { background: #64748b; color: white; border: none; border-radius: 6px; padding: 10px 20px; cursor: pointer; }

    .notice { padding: 15px; background: #dcfce7; color: #166534; border-radius: 8px; margin-bottom: 20px; }
    .error { padding: 15px; background: #fee2e2; color: #991b1b; border-radius: 8px; margin-bottom: 20px; }

    .action-btn { border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; color: white; font-size: 13px; font-weight: 600; }
  </style>
</head>
<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(#0077b6);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Admin</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">
    

<div class="nav-btn" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn" onclick="location.href='election.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-80q-33 0-56.5-23.5T120-160v-182l110-125 57 57-80 90h546l-78-88 57-57 108 123v182q0 33-23.5 56.5T760-80H200Zm0-80h560v-80H200v80Zm225-225L284-526q-23-23-22.5-56.5T285-639l196-196q23-23 57-24t57 22l141 141q23 23 24 56t-22 56L538-384q-23 23-56.5 22.5T425-385Zm255-254L539-780 341-582l141 141 198-198ZM200-160v-80 80Z"/></svg> Election</div>
<div class="nav-btn" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn active" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn" onclick="location.href='moderators.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M609-389q-29-29-29-71t29-71q29-29 71-29t71 29q29 29 29 71t-29 71q-29 29-71 29t-71-29ZM480-160v-56q0-24 12.5-44.5T528-290q36-15 74.5-22.5T680-320q39 0 77.5 7.5T832-290q23 9 35.5 29.5T880-216v56H480ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm113-113ZM80-160v-112q0-34 17-62.5t47-43.5q60-30 124.5-46T400-440q35 0 70 6t70 14l-34 34-34 34q-18-5-36-6.5t-36-1.5q-58 0-113.5 14T180-306q-10 5-15 14t-5 20v32h240v80H80Zm320-80Zm56.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5Z"/></svg> Moderators</div>
<div class="nav-btn" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>


<div class="main-content">
    <div class="page-header">
        <h2 style="margin:0; color:#1e293b;">Manage Voters</h2>
        <div style="display:flex; gap:10px;">
            <button class="btn blue" id="openImportBtn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-480ZM202-65l-56-57 118-118h-90v-80h226v226h-80v-89L202-65Zm278-15v-80h240v-440H520v-200H240v400h-80v-400q0-33 23.5-56.5T240-880h320l240 240v480q0 33-23.5 56.5T720-80H480Z"/></svg> Bulk Registration</button>
            <button class="btn blue" id="addVoterBtn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M440-280h80v-160h160v-80H520v-160h-80v160H280v80h160v160Zm40 200q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg> Register Voter</button>
        </div>
    </div>

    <?php if (!empty($error)): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if (!empty($success)): ?><div class="notice"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <div class="stat-box purple">
        <p style="margin:0; opacity:0.9;">Total Registered Voters</p>
        <h1 style="margin:0; font-size:32px;"><?= count($voters); ?></h1>
    </div>

    <div style="margin-bottom:20px; display:flex; flex-wrap:wrap; gap:15px; background:white; padding:20px; border-radius:10px; box-shadow:0 2px 4px rgba(0,0,0,0.05);">
        <div style="flex:1; min-width:200px;">
            <label style="display:block; font-size:12px; font-weight:600; color:#64748b; margin-bottom:5px;">SEARCH VOTER</label>
            <input type="text" id="searchInput" placeholder="Enter Student ID or Name..." style="padding:10px; border:1px solid #cbd5e1; border-radius:8px; width:100%;">
        </div>
        <div style="width:180px;">
            <label style="display:block; font-size:12px; font-weight:600; color:#64748b; margin-bottom:5px;">GRADE LEVEL</label>
            <select id="gradeFilter" onchange="filterByGrade(this.value)" style="padding:10px; border:1px solid #cbd5e1; border-radius:8px; width:100%;">
                <option value="">All Grades</option>
                <?php foreach($all_grades as $g): ?>
                    <option value="<?= htmlspecialchars($g['grade_level']) ?>" <?= $filter_grade == $g['grade_level'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($g['grade_level']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="display:flex; align-items:flex-end; gap:8px;">
            <button id="searchBtn" class="btn-save">Search</button>
            <button onclick="location.href='voters.php'" class="btn-cancel">Reset</button>
        </div>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Grade Level</th>
                    <th>Strand/Section</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (count($voters) > 0): ?>
                <?php foreach ($voters as $v): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($v['student_id']); ?></strong></td>
                    <td><?= htmlspecialchars($v['grade_level']); ?></td>
                    <td><?= htmlspecialchars($v['strand'].' - '.$v['section']); ?></td>
                    <td><?= htmlspecialchars($v['firstname'].' '.$v['lastname']); ?></td>
                    <td><?= htmlspecialchars($v['email']); ?></td>
                    <td>
                        <button class="action-btn" style="background:#3b82f6" onclick="openViewModal(<?= $v['id'] ?>)"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M607.5-372.5Q660-425 660-500t-52.5-127.5Q555-680 480-680t-127.5 52.5Q300-575 300-500t52.5 127.5Q405-320 480-320t127.5-52.5Zm-204-51Q372-455 372-500t31.5-76.5Q435-608 480-608t76.5 31.5Q588-545 588-500t-31.5 76.5Q525-392 480-392t-76.5-31.5ZM214-281.5Q94-363 40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200q-146 0-266-81.5ZM480-500Zm207.5 160.5Q782-399 832-500q-50-101-144.5-160.5T480-720q-113 0-207.5 59.5T128-500q50 101 144.5 160.5T480-280q113 0 207.5-59.5Z"/></svg></button>
                        <button class="action-btn" style="background:#f59e0b" onclick="openEditModal(<?= $v['id'] ?>)"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z"/></svg></button>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center; padding:40px; color:#94a3b8;">No voters found in database.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal" id="voterModal">
    <div class="modal-content">
        <h3 style="margin-top:0">Register New Voter</h3>
        <form method="POST">
            <input type="hidden" name="save_voter" value="1">
            <div class="form-group"><label>Student ID</label><input type="text" name="student_id" required></div>
            <div class="form-group"><label>Grade/Strand & Section</label><input type="text" name="grade_section" placeholder="e.g. Grade 11 - STEM A" required></div>
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" required></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" required></div>
            <div class="form-group"><label>Email Address</label><input type="email" name="email"></div>
            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
                <button type="button" onclick="closeModal('voterModal')" class="btn-cancel">Cancel</button>
                <button type="submit" class="btn-save">Save Voter</button>
            </div>
        </form>
    </div>
</div>

<script>
    const closeModal = (id) => document.getElementById(id).style.display = 'none';
    const showModal = (id) => document.getElementById(id).style.display = 'flex';

    document.getElementById('addVoterBtn').onclick = () => showModal('voterModal');
    document.getElementById('openImportBtn').onclick = () => showModal('importModal');

    function filterByGrade(val) {
        window.location.href = 'voters.php?filter_grade=' + encodeURIComponent(val);
    }

    // Modal close when clicking outside
    window.onclick = (e) => {
        if(e.target.classList.contains('modal')) e.target.style.display = 'none';
    };
</script>

</body>
</html>