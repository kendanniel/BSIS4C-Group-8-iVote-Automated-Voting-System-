```php
<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// === COUNT TOTAL MODERATORS ===
function getCount($conn, $query, $key) {
    $res = $conn->query($query);
    return ($res && $res->num_rows > 0) ? $res->fetch_assoc()[$key] : 0;
}
// $totalModerators   = getCount($conn, "SELECT COUNT(*) AS total FROM moderators", "total");
// $activeModerators  = getCount($conn, "SELECT COUNT(*) AS active FROM moderators WHERE status='active'", "active");
// $inactiveModerators= getCount($conn, "SELECT COUNT(*) AS inactive FROM moderators WHERE status='inactive'", "inactive");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Manage Moderators</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="dashboard.css">
<link rel="stylesheet" href="admin_moderators.css">
<style>
    /* Improved UI Styles */
  
    
    .stat-box {
        background: linear-gradient(135deg, #ffffff 0%, #f9f9f9 100%);
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        padding: 15px;
        flex: 1;
        min-width: 200px;
        text-align: center;
        border: 1px solid #e0e0e0;
    }
    .stat-box.green { border-left: 4px solid #28a745; }
    .stat-box.blue { border-left: 4px solid #007bff; }
    .stat-box.red { border-left: 4px solid #dc3545; }
    .stat-box p { margin: 0; color: #666; }
    .stat-box h1 { margin: 10px 0 0 0; font-size: 2em; color: #333; }
    .moderators-table-container {
        background: linear-gradient(135deg, #ffffff 0%, #f9f9f9 100%);
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        padding: 15px;
        border: 1px solid #e0e0e0;
        overflow-x: auto;
    }
    .data-table {
        width: 100%;
        border-collapse: collapse;
    }
    .data-table th, .data-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    .data-table th {
        background-color: #f8f9fa;
        font-weight: bold;
    }
    .btn {
        padding: 8px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        transition: background-color 0.3s ease;
    }
    .btn.blue { background-color: #007bff; color: white; }
    .btn.blue:hover { background-color: #0056b3; }
    .edit-btn { background-color: #ffc107; color: black; margin-right: 5px; }
    .edit-btn:hover { background-color: #e0a800; }
    /* === MODAL STYLES === */
    .modal { display: none; position: fixed; z-index: 999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; overflow-y: auto; padding: 20px; }
    .modal-content { background: #fff; border-radius: 10px; padding: 25px; width: 100%; max-width: 500px; box-shadow: 0 5px 20px rgba(0,0,0,0.3); overflow-y: auto; max-height: 90vh; animation: fadeIn 0.25s ease-in-out; }
    .modal-content h2 { text-align: center; margin-bottom: 20px; }
    .modal-content label { display: block; margin-top: 10px; font-weight: bold; }
    .modal-content input, .modal-content select { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 6px; }
    .modal-buttons { display: flex; justify-content: flex-end; margin-top: 15px; gap: 10px; }
    .modal-buttons button { padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; }
    .btn-cancel { background: #ccc; }
    .btn-save { background: #007bff; color: white; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
    .status.active { background-color: #22c55e; color: white; padding: 4px 8px; border-radius: 4px; }
    .status.inactive { background-color: #f59e0b; color: white; padding: 4px 8px; border-radius: 4px; }
    @media (max-width: 768px) {
        .page-header {
            flex-direction: column;
            gap: 10px;
        }
        .stat-box {
            min-width: 150px;
        }
    }
</style>
</head>
<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<!-- SIDE PANEL -->
<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(#0077b6);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Admin</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">

<div class="nav-btn" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn" onclick="location.href='election.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-80q-33 0-56.5-23.5T120-160v-182l110-125 57 57-80 90h546l-78-88 57-57 108 123v182q0 33-23.5 56.5T760-80H200Zm0-80h560v-80H200v80Zm225-225L284-526q-23-23-22.5-56.5T285-639l196-196q23-23 57-24t57 22l141 141q23 23 24 56t-22 56L538-384q-23 23-56.5 22.5T425-385Zm255-254L539-780 341-582l141 141 198-198ZM200-160v-80 80Z"/></svg> Election</div>
<div class="nav-btn" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn active" onclick="location.href='moderators.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M609-389q-29-29-29-71t29-71q29-29 71-29t71 29q29 29 29 71t-29 71q-29 29-71 29t-71-29ZM480-160v-56q0-24 12.5-44.5T528-290q36-15 74.5-22.5T680-320q39 0 77.5 7.5T832-290q23 9 35.5 29.5T880-216v56H480ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm113-113ZM80-160v-112q0-34 17-62.5t47-43.5q60-30 124.5-46T400-440q35 0 70 6t70 14l-34 34-34 34q-18-5-36-6.5t-36-1.5q-58 0-113.5 14T180-306q-10 5-15 14t-5 20v32h240v80H80Zm320-80Zm56.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5Z"/></svg> Moderators</div>
<div class="nav-btn" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>

<style>
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}
</style>

<!-- MAIN CONTENT -->
<div style="margin-left:260px;padding:30px;width:100%;">


</header>

    <div class="page-header">
        <h3>Manage Moderators</h3>
        <button class="btn blue" id="openAddModalBtn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M440-280h80v-160h160v-80H520v-160h-80v160H280v80h160v160Zm40 200q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg> Add Moderator</button>
    </div>

    <!-- STAT BOXES -->
    <div style="display:flex; gap:20px; flex-wrap:wrap;">
        <!--<div class="stat-box green"><p>Total Moderators</p><h1><?= $totalModerators ?></h1></div>-->
        <!--<div class="stat-box blue"><p>Active Moderators</p><h1><?= $activeModerators ?></h1></div>-->
        <!--<div class="stat-box red"><p>Inactive Moderators</p><h1><?= $inactiveModerators ?></h1></div>-->
    </div>

    <!-- TABLE -->
    <div class="moderators-table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Name</th>
                    <th>Email</th> 
                    <!--<th>Status</th>-->
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = $conn->query("SELECT * FROM moderators ORDER BY created_at DESC");
                if($res && $res->num_rows > 0):
                    while($row = $res->fetch_assoc()):
                        $statusClass = strtolower($row['status']);
                ?>
                <tr>
                    <td><?= htmlspecialchars($row['faculty_id']) ?></td>
                    <td><?= htmlspecialchars($row['level']) ?></td>
                    <td><?= htmlspecialchars($row['first_name'].' '.$row['last_name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <!--<td><span class="status <?= $statusClass ?>"><?= strtoupper($row['status']) ?></span></td>-->
                    <td><?= date("m/d/Y", strtotime($row['created_at'])) ?></td>
                    <td>
                        <button class="edit-btn" onclick="openEditModal('<?= $row['faculty_id'] ?>')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z"/></svg> Edit</button>
                    </td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="7" style="text-align:center;">No moderators found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ADD MODAL -->
<div class="modal" id="addModal">
    <div class="modal-content">
        <h2>Add Moderator</h2>
        <form method="POST" action="save_moderator.php">
            <label>Faculty ID</label><input type="text" name="faculty_id" required>
            <label>First Name</label><input type="text" name="first_name" required>
            <label>Last Name</label><input type="text" name="last_name" required>
            <label>Email</label><input type="email" name="email" required>
            <label>Password</label><input type="password" name="password" required>
            <label>Type</label>
            <select name="level" required>
                <option value="">-- Select Type --</option>
                <option value="Moderator 1">Moderator 1</option>
                <option value="Moderator 2">Moderator 2</option>
                <option value="Moderator 3">Moderator 3</option>
            </select>
            <label>Status</label>
            <select name="status" required>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
            <div class="modal-buttons">
                <button type="button" class="btn-cancel" id="closeAddModalBtn">Cancel</button>
                <button type="submit" class="btn-save">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT MODAL -->
<div class="modal" id="editModal">
    <div class="modal-content">
        <h2>Edit Moderator</h2>
        <form id="editForm" method="POST" action="update_moderator.php">
            <input type="hidden" name="faculty_id" id="edit_id">
            <label>Faculty ID</label><input type="text" id="edit_faculty_id" name="faculty_id" required>
            <label>First Name</label><input type="text" id="edit_first_name" name="first_name" required>
            <label>Last Name</label><input type="text" id="edit_last_name" name="last_name" required>
            <label>Email</label><input type="email" id="edit_email" name="email" required>
            <label>Type</label>
            <select id="edit_level" name="level" required>
                <option value="Moderator 1">Moderator 1</option>
                <option value="Moderator 2">Moderator 2</option>
                <option value="Moderator 3">Moderator 3</option>
            </select>
            <label>Status</label>
            <select id="edit_status" name="status" required>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
            <div class="modal-buttons">
                <button type="button" class="btn-cancel" id="closeEditModalBtn">Cancel</button>
                <button type="submit" class="btn-save">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
// ADD MODAL
const addModal = document.getElementById('addModal');
document.getElementById('openAddModalBtn').onclick = () => addModal.style.display='flex';
document.getElementById('closeAddModalBtn').onclick = () => addModal.style.display='none';
window.onclick = e => { if(e.target === addModal) addModal.style.display='none'; };

// EDIT MODAL
const editModal = document.getElementById('editModal');
document.getElementById('closeEditModalBtn').onclick = () => editModal.style.display='none';

function openEditModal(faculty_id){
    fetch('get_moderator.php?id=' + faculty_id)
    .then(res => res.json())
    .then(data => {
        document.getElementById('edit_id').value = data.faculty_id;
        document.getElementById('edit_faculty_id').value = data.faculty_id;
        document.getElementById('edit_first_name').value = data.first_name;
        document.getElementById('edit_last_name').value = data.last_name;
        document.getElementById('edit_email').value = data.email;
        document.getElementById('edit_level').value = data.level;
        document.getElementById('edit_status').value = data.status;

        editModal.style.display = 'flex';
    })
    .catch(err => alert('Failed to fetch moderator data.'));
}
</script>

</body>
</html>
```