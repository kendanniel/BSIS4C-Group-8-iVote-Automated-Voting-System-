<?php
require '../inc/db.php';
header('Content-Type: application/json');

if (!isset($_GET['student_id'])) {
    echo json_encode(['error' => 'No student ID provided']);
    exit;
}

$student_id = trim($_GET['student_id']);
if ($student_id === '') {
    echo json_encode(['error' => 'Empty student ID']);
    exit;
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    echo json_encode(['error' => 'Database connection not found']);
    exit;
}

// ✅ Step 1: Check if student already exists in candidates table
$check = $conn->prepare("SELECT id FROM candidates WHERE student_id = ?");
$check->bind_param('s', $student_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['error' => 'This student is already registered as a candidate and cannot apply for another position.']);
    $check->close();
    $conn->close();
    exit;
}
$check->close();

// ✅ Step 2: Continue fetching from voters if not yet a candidate
$stmt = $conn->prepare("SELECT student_id, firstname, middlename, lastname, strand, grade_level, section FROM voters WHERE student_id = ?");
$stmt->bind_param('s', $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
    $grade_section = trim(($student['grade_level'] ? 'Grade '.$student['grade_level'] : '') . ' - ' . $student['strand'] . ' ' . $student['section']);
    echo json_encode([
        'success' => true,
        'student_id' => $student['student_id'],
        'firstname' => $student['firstname'],
        'middlename' => $student['middlename'],
        'lastname' => $student['lastname'],
        'grade_section' => $grade_section,
    ]);
} else {
    echo json_encode(['error' => 'Student not found in voters list.']);
}

$stmt->close();
$conn->close();
?>
