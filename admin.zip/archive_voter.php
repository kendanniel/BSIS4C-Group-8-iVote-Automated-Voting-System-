<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success'=>false, 'message'=>'Invalid ID']);
    exit;
}

// Update status to 'archived'
$stmt = $conn->prepare("UPDATE voters SET status='archived' WHERE id=?");
$stmt->bind_param('i', $id);
$success = $stmt->execute();
$stmt->close();

if ($success) {
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Failed to archive']);
}
