<?php
require '../inc/db.php';
header('Content-Type: application/json');

if (!isset($_GET['q']) || trim($_GET['q']) === '') {
    echo json_encode(['success' => false, 'message' => 'No query']);
    exit;
}

$q = trim($_GET['q']);
$search = "%{$q}%";

$stmt = $conn->prepare("
    SELECT * FROM voters
    WHERE student_id LIKE ?
       OR firstname LIKE ?
       OR lastname LIKE ?
       OR middlename LIKE ?
");
$stmt->bind_param('ssss', $search, $search, $search, $search);
$stmt->execute();
$result = $stmt->get_result();

$voters = [];
while ($row = $result->fetch_assoc()) {
    $voters[] = $row;
}

echo json_encode(['success' => true, 'voters' => $voters]);
?>
