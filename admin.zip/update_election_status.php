<?php
session_start();
// I-check kung tama ang path ng db.php mo
require '../inc/db.php'; 

// I-set ang timezone para laging match sa Pilipinas
date_default_timezone_set('Asia/Manila');

// 1. Siguraduhin na JSON ang output natin para mabasa ng JavaScript Fetch
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => 'Session expired. Please login again.']);
    exit();
}

// 2. Kunin ang input mula sa Fetch
$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (isset($data['election_id']) && isset($data['action'])) {
    $id = intval($data['election_id']);
    $action = $data['action'];
    $now = date('Y-m-d H:i:s');

   // ... sa loob ng update_election_status.php

switch ($action) {
    case 'start_filing':
        // Magdadagdag tayo ng +1 day extension para sa filing kapag binuksan manual
        $newEnd = date('Y-m-d H:i:s', strtotime('+1 day'));
        $sql = "UPDATE elections SET filing_status = 1, filing_end = '$newEnd' WHERE id = $id";
        break;

    case 'close_filing':
        // Isasara ang filing at i-set ang end date sa oras ngayon
        $sql = "UPDATE elections SET filing_status = 2, filing_end = '$now' WHERE id = $id";
        break;

   case 'start_election':
        // Kapag pinindot ang START, i-force ang start_datetime sa ORAS NGAYON
        // At mag-extend ng 1 day para siguradong PASOK sa logic ng "Active"
        $newEnd = date('Y-m-d H:i:s', strtotime('+1 day'));
        $sql = "UPDATE elections SET 
                    status = 'active', 
                    start_datetime = '$now', 
                    end_datetime = '$newEnd' 
                WHERE id = $id";
        break;

    case 'close_election':
        // Tatapusin ang election at i-set ang end date sa oras ngayon
        $sql = "UPDATE elections SET status = 'ended', end_datetime = '$now' WHERE id = $id";
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Unknown action.']);
        exit();
}

    // 4. Execute Query
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid data received.']);
}
?>