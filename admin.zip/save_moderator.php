<?php
session_start();
require '../inc/db.php';

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Check if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize inputs
    $faculty_id = trim($_POST['faculty_id']);
    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $password   = trim($_POST['password']);
    $level      = trim($_POST['level']);
    $status     = trim($_POST['status']);

    // Basic validation
    if (empty($faculty_id) || empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($level) || empty($status)) {
        echo "<script>alert('Please fill in all fields.'); window.history.back();</script>";
        exit();
    }

    // Check if moderator already exists by email or faculty_id
    $check = $conn->prepare("SELECT * FROM moderators WHERE email = ? OR faculty_id = ?");
    $check->bind_param("ss", $email, $faculty_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('A moderator with that email or faculty ID already exists.'); window.history.back();</script>";
        exit();
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert new moderator
    $stmt = $conn->prepare("INSERT INTO moderators (faculty_id, first_name, last_name, email, password, level, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssssss", $faculty_id, $first_name, $last_name, $email, $hashed_password, $level, $status);

    if ($stmt->execute()) {
        echo "<script>alert('Moderator added successfully!'); window.location='moderators.php';</script>";
    } else {
        echo "<script>alert('Error adding moderator. Please try again.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: moderators.php");
    exit();
}
?>
