<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: election.php");
    exit();
}

$id = intval($_GET['id']);

// Check if election exists
$check = $conn->query("SELECT * FROM elections WHERE id = $id");
if (!$check || $check->num_rows == 0) {
    echo "<script>alert('Election not found!'); window.location='election.php';</script>";
    exit();
}

$election = $check->fetch_assoc();

// Archive the election
$archive = $conn->query("UPDATE elections SET status='archived' WHERE id = $id");

if ($archive) {
    echo "<script>alert('Election archived successfully!'); window.location='election.php';</script>";
} else {
    echo "<script>alert('Error archiving election: {$conn->error}'); window.location='election.php';</script>";
}
exit();
?>
