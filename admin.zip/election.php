<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);
date_default_timezone_set('Asia/Manila');
$now = date('Y-m-d H:i:s');

// 🔁 AUTO UPDATE ELECTION STATUS
// Update to active ONLY if it's currently upcoming and time has reached
$conn->query("
    UPDATE elections 
    SET status = 'active' 
    WHERE status = 'upcoming' 
      AND start_datetime <= '$now' 
      AND end_datetime >= '$now'
");

// Update to ended ONLY if it's currently active and time has passed
$conn->query("
    UPDATE elections 
    SET status = 'ended' 
    WHERE status = 'active' 
      AND end_datetime < '$now'
");

// Calculate current school year
$currentYear = date('Y');
$currentMonth = date('n'); // 1-12
if ($currentMonth >= 6) {
    $schoolYear = $currentYear . '-' . ($currentYear + 1);
} else {
    $schoolYear = ($currentYear - 1) . '-' . $currentYear;
}

// Date restrictions for Create Election modal
list($startYear, $endYear) = explode('-', $schoolYear);
$schoolYearEnd = $endYear . "-05-31T23:59";
$currentDateTime = date('Y-m-d\TH:i');

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Election Management</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin_election.css">
</head>

<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(#0077b6);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Admin</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">
    

<div class="nav-btn" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn active" onclick="location.href='election.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-80q-33 0-56.5-23.5T120-160v-182l110-125 57 57-80 90h546l-78-88 57-57 108 123v182q0 33-23.5 56.5T760-80H200Zm0-80h560v-80H200v80Zm225-225L284-526q-23-23-22.5-56.5T285-639l196-196q23-23 57-24t57 22l141 141q23 23 24 56t-22 56L538-384q-23 23-56.5 22.5T425-385Zm255-254L539-780 341-582l141 141 198-198ZM200-160v-80 80Z"/></svg> Election</div>
<div class="nav-btn" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn" onclick="location.href='moderators.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M609-389q-29-29-29-71t29-71q29-29 71-29t71 29q29 29 29 71t-29 71q-29 29-71 29t-71-29ZM480-160v-56q0-24 12.5-44.5T528-290q36-15 74.5-22.5T680-320q39 0 77.5 7.5T832-290q23 9 35.5 29.5T880-216v56H480ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm113-113ZM80-160v-112q0-34 17-62.5t47-43.5q60-30 124.5-46T400-440q35 0 70 6t70 14l-34 34-34 34q-18-5-36-6.5t-36-1.5q-58 0-113.5 14T180-306q-10 5-15 14t-5 20v32h240v80H80Zm320-80Zm56.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5Z"/></svg> Moderators</div>
<div class="nav-btn" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>

<style>
.nav-btn{padding:12px 15px;border-radius:10px;cursor:pointer;background:#1e293b;transition:0.25s;font-weight:500;}
.nav-btn:hover{background:#334155;transform:translateX(5px);}
.nav-btn.active{background:#3b82f6;box-shadow:0 0 10px rgba(59,130,246,0.7);}
.logout-btn{background:#7f1d1d;}
.logout-btn:hover{background:#991b1b;}
.vote-btn{padding:5px 10px;border:none;border-radius:5px;color:white;background:#16a34a;cursor:pointer;}
.vote-btn:hover{opacity:0.85;}
</style>

<!-- MAIN CONTENT -->
<div style="margin-left:260px;padding:30px;width:100%;">



</header>

<div class="election-container">
<div class="election-header">
  <h2>Election Management</h2>
  <button class="create-btn" id="openModalBtn">+ Create Election</button>
</div>

<!-- Election Table -->
<table class="election-table">
  <thead>
    <tr>
        <th>Title</th>
        <th>School Year</th>
        <th>Filing Start</th>
        <th>Filing End</th>
        <th>Filing Status</th>
        <th>Election Start</th>
        <th>Election End</th>
        <th>Election Status</th>
        <th>Actions</th> </tr>
</thead>
  <tbody>
<?php
$query = "SELECT * FROM elections ORDER BY created_at DESC";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row['id'];
        $now = date('Y-m-d H:i:s');
        
        // Logical Status for Display
        if ($now < $row['start_datetime']) $computedStatus='UPCOMING';
        elseif ($now >= $row['start_datetime'] && $now <= $row['end_datetime']) $computedStatus='ACTIVE';
        else $computedStatus='ENDED';

        $statusClass = strtolower($computedStatus);
        $fStart = date("m/d/Y g:i A", strtotime($row['filing_start']));
        $fEnd   = date("m/d/Y g:i A", strtotime($row['filing_end']));
        $eStart = date("m/d/Y g:i A", strtotime($row['start_datetime']));
        $eEnd   = date("m/d/Y g:i A", strtotime($row['end_datetime']));

        // --- FILING BUTTONS ---
        if ($row['filing_status'] == 0) {
            $filingBtn = "<button class='vote-btn' onclick='updateStatus($id, \"start_filing\")'>Open Filing</button>";
        } elseif ($row['filing_status'] == 1) {
            $filingBtn = "<button class='vote-btn' style='background:#f59e0b;' onclick='updateStatus($id, \"close_filing\")'>Close Filing</button>";
        } else {
            $filingBtn = "<button class='vote-btn' style='background:#64748b;' onclick='updateStatus($id, \"start_filing\")'>Re-open Filing</button>";
        }

        // --- ELECTION BUTTONS ---
        if ($row['status'] == 'upcoming') {
            $electionBtn = "<button class='vote-btn' style='background:#3b82f6;' onclick='updateStatus($id, \"start_election\")'>Start Election</button>";
        } elseif ($row['status'] == 'active') {
            $electionBtn = "<button class='vote-btn' style='background:#dc2626;' onclick='updateStatus($id, \"close_election\")'>End Election</button>";
        } else {
            $electionBtn = "<button class='vote-btn' style='background:#64748b;' onclick='updateStatus($id, \"start_election\")'>Re-open Election</button>";
        }
?>
<tr>
    <td><?= htmlspecialchars($row['title']) ?></td>
    <td><?= htmlspecialchars($row['school_year']) ?></td>
    <td><?= $fStart ?></td>
    <td><?= $fEnd ?></td>
    <td><span class="filing-status"><?= ($row['filing_status']==1 ? 'OPEN' : ($row['filing_status']==2 ? 'CLOSED' : 'NOT OPEN')) ?></span></td>
    <td><?= $eStart ?></td>
    <td><?= $eEnd ?></td>
    <td><span class="status <?= $statusClass ?>"><?= $computedStatus ?></span></td>
    
    <td style="padding: 10px; min-width: 160px;">
        <div style="display:flex; flex-direction:column; gap:5px;">
            <?= $filingBtn ?>
            <?= $electionBtn ?>
        </div>
    </td>
</tr>
<?php
    }
} else {
    echo "<tr><td colspan='9' style='text-align:center;'>No elections found</td></tr>";
}
?>
</tbody>
</table>

<!-- Create Election Modal -->
<div id="createElectionModal" class="modal">
  <div class="modal-content">
    <h2>Create New Election</h2>
    <!-- <form method="POST" action="create_election_process.php">
      <label>Title</label>
      <input type="text" name="title" required>
      <input type="hidden" name="school_year" value="<php echo $schoolYear; ?>">
      <label>Start Date & Time</label>
      <input type="datetime-local" name="start_datetime" min="<php echo $currentDateTime; ?>" max="<php echo $schoolYearEnd; ?>" required>
      <label>End Date & Time</label>
      <input type="datetime-local" name="end_datetime" min="<php echo $currentDateTime; ?>" max="<php echo $schoolYearEnd; ?>" required>
      <div class="modal-buttons">
        <button type="button" class="cancel-btn" id="closeModalBtn">Cancel</button>
        <button type="submit" class="create-btn" onclick="return confirm('Once created, this election cannot be edited. Continue?')">Create Election</button>
      </div>
    </form> -->
    <form method="POST" action="create_election_process.php">

<label>Title</label>
<input type="text" name="title" required>

<input type="hidden" name="school_year" value="<?php echo $schoolYear; ?>">

<label>Filing Start Date & Time</label>
<input type="datetime-local"
name="filing_start"
min="<?php echo $currentDateTime; ?>"
max="<?php echo $schoolYearEnd; ?>"
required>

<label>Filing End Date & Time</label>
<input type="datetime-local"
name="filing_end"
min="<?php echo $currentDateTime; ?>"
max="<?php echo $schoolYearEnd; ?>"
required>

<label>Election Start Date & Time</label>
<input type="datetime-local"
name="start_datetime"
min="<?php echo $currentDateTime; ?>"
max="<?php echo $schoolYearEnd; ?>"
required>

<label>Election End Date & Time</label>
<input type="datetime-local"
name="end_datetime"
min="<?php echo $currentDateTime; ?>"
max="<?php echo $schoolYearEnd; ?>"
required>

<div class="modal-buttons">
<button type="button" class="cancel-btn" id="closeModalBtn">Cancel</button>

<button type="submit" class="create-btn"
onclick="return confirm('Once created, this election cannot be edited. Continue?')">
Create Election
</button>
</div>

</form>
  </div>
</div>
</div>
</div>

<script>
// --- MODAL CONTROLS ---
const createModal = document.getElementById("createElectionModal");
document.getElementById("openModalBtn").onclick = () => createModal.style.display = "flex";
document.getElementById("closeModalBtn").onclick = () => createModal.style.display = "none";
window.onclick = (e) => { if(e.target === createModal) createModal.style.display = "none"; }

// --- AUTOMATIC DATE VALIDATION (UI) ---
// 1. Kapag binago ang Filing Start, i-set ang minimum ng Filing End
document.querySelector('input[name="filing_start"]').addEventListener('change', function() {
    document.querySelector('input[name="filing_end"]').min = this.value;
});

// 2. Kapag binago ang Filing End, i-set ang minimum ng Election Start
document.querySelector('input[name="filing_end"]').addEventListener('change', function() {
    const filingEndValue = this.value;
    const electionStartInput = document.querySelector('input[name="start_datetime"]');
    
    electionStartInput.min = filingEndValue;
    
    if(electionStartInput.value && electionStartInput.value < filingEndValue) {
        electionStartInput.value = filingEndValue;
    }
});

// 3. Kapag binago ang Election Start, i-set ang minimum ng Election End
document.querySelector('input[name="start_datetime"]').addEventListener('change', function() {
    document.querySelector('input[name="end_datetime"]').min = this.value;
});

// --- AJAX STATUS UPDATE FUNCTION ---
function updateStatus(electionId, action) {
    if(!confirm("Are you sure you want to " + action.replace('_', ' ') + "?")) return;
    
    fetch('update_election_status.php', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ election_id: electionId, action: action })
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            alert('Status updated successfully!');
            location.reload();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(err => {
        console.error(err);
        alert('Connection error.');
    });
}
</script>
</body>
</html>