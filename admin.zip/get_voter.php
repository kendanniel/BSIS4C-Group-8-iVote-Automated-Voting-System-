<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success'=>false, 'message'=>'Invalid ID']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM voters WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($result) {
    echo json_encode(['success'=>true, 'voter'=>$result]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Voter not found']);
}
