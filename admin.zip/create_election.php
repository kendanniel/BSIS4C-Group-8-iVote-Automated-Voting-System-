<?php
session_start();
require '../inc/db.php';

// ✅ Only Admin can access
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Election</title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin_election.css">
  <style>
    .main-content {
      padding: 30px;
    }

    .content {
      background: #fff;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      max-width: 800px;
      margin: 20px auto;
    }

    .content h2 {
      color: #1a165e;
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    label {
      font-weight: 600;
      color: #333;
    }

    input, select {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      width: 100%;
    }

    .form-actions {
      text-align: right;
      margin-top: 15px;
    }

    .btn {
      padding: 10px 18px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
    }

    .btn-primary {
      background-color: #1a165e;
      color: white;
    }

    .btn-primary:hover {
      background-color: #2a25a0;
    }

    .btn-cancel {
      background-color: #ccc;
      color: #333;
      margin-right: 10px;
    }

    .btn-cancel:hover {
      background-color: #bbb;
    }
  </style>
</head>
<body>

  <!-- SIDEBAR -->
  <div class="sidebar">
    <div class="logo">
      <img src="images/logo.png" alt="School Logo">
      <h3>SAN ROQUE NHS</h3>
    </div>
    <ul class="nav-links">
      <li onclick="location.href='dashboard.php'"><i class="icon">🏠</i>Dashboard</li>
      <li class="active" onclick="location.href='election.php'"><i class="icon">🗳️</i>Elections</li>
      <li onclick="location.href='candidates.php'"><i class="icon">👤</i>Candidates</li>
      <li onclick="location.href='voters.php'"><i class="icon">🧾</i>Voters</li>
      <li onclick="location.href='reports.php'"><i class="icon">📊</i>Reports</li>
    </ul>
    <a class="logout" href="logout.php">🚪 Log Out</a>
  </div>

  <!-- MAIN CONTENT -->
  <div class="main-content">
    <header>
      <h2>Create New Election</h2>
      <div class="datetime">
        <?php
          date_default_timezone_set('Asia/Manila');
          echo date("F d, Y") . "<br>" . date("g:i A");
        ?>
      </div>
    </header>

    <div class="content">
      <form action="create_election_process.php" method="POST">
        <div class="form-group">
          <label for="title">Election Title</label>
          <input type="text" id="title" name="title" placeholder="e.g. Supreme Student Government 2025" required>
        </div>

        <div class="form-group">
          <label for="school_year">School Year</label>
          <input type="text" id="school_year" name="school_year" placeholder="e.g. 2024-2025" required>
        </div>

        <div class="form-group">
          <label for="start_datetime">Start Date & Time</label>
          <input type="datetime-local" id="start_datetime" name="start_datetime" required>
        </div>

        <div class="form-group">
          <label for="end_datetime">End Date & Time</label>
          <input type="datetime-local" id="end_datetime" name="end_datetime" required>
        </div>

        <div class="form-actions">
          <button type="button" class="btn btn-cancel" onclick="window.location.href='election.php'">Cancel</button>
          <button type="submit" class="btn btn-primary">Create Election</button>
        </div>
      </form>
    </div>
  </div>

</body>
</html>
