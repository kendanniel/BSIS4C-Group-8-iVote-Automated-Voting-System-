<?php
require '../inc/db.php'; // your database connection

date_default_timezone_set('Asia/Manila');

// --- Dummy candidate for abstentions ---
$dummy_candidate_id = 0;

// --- Get current election positions ---
$positions = [];
$positionResult = $conn->query("SELECT id FROM positions");
if ($positionResult && $positionResult->num_rows > 0) {
    while ($pos = $positionResult->fetch_assoc()) {
        $positions[] = $pos['id'];
    }
}

// --- Get all active voters ---
$votersResult = $conn->query("SELECT id FROM voters WHERE status = 'active'");
if ($votersResult && $votersResult->num_rows > 0) {
    while ($voter = $votersResult->fetch_assoc()) {
        $voter_id = $voter['id'];

        foreach ($positions as $position_id) {
            // --- Check if voter has already voted for this position ---
            $check = $conn->query("
                SELECT * FROM votes 
                WHERE voter_id = $voter_id 
                  AND position_id = $position_id
                  AND candidate_id != $dummy_candidate_id
            ");

            // --- If voter has not voted for this position, insert dummy vote ---
            if ($check && $check->num_rows == 0) {
                // --- Make sure we don’t insert duplicate dummy vote ---
                $dummyCheck = $conn->query("
                    SELECT * FROM votes 
                    WHERE voter_id = $voter_id 
                      AND position_id = $position_id 
                      AND candidate_id = $dummy_candidate_id
                ");

                if ($dummyCheck && $dummyCheck->num_rows == 0) {
                    $insert = $conn->prepare("
                        INSERT INTO votes (voter_id, candidate_id, position_id, created_at) 
                        VALUES (?, ?, ?, NOW())
                    ");
                    $insert->bind_param("iii", $voter_id, $dummy_candidate_id, $position_id);
                    $insert->execute();
                }
            }
        }
    }
}

echo "Auto-abstain process completed safely. No duplicate dummy votes were inserted.";
?>
