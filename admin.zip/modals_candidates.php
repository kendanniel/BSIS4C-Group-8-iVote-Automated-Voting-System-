<!-- Partylist Modal -->
<div id="partylistModal" class="modal">
  <div class="modal-content">
    <h3>Add Partylist</h3>
    <form method="post">
      <label>Partylist Name</label>
      <input type="text" name="partylist_name" required>
      <label><input type="checkbox" name="is_independent"> Independent</label>
      <div class="modal-buttons">
        <button type="submit" name="save_partylist" class="btn-save">Save</button>
        <button type="button" class="btn-cancel" onclick="closeModal('partylistModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Candidate Modal -->
<div id="candidateModal" class="modal">
  <div class="modal-content">
    <h3>Add Candidate</h3>
    <form method="post" enctype="multipart/form-data">
      <label>Student ID</label>
      <input type="text" name="student_id" required>
      <label>Firstname</label>
      <input type="text" name="firstname" required>
      <label>Lastname</label>
      <input type="text" name="lastname" required>
      <label>Grade/Section</label>
      <input type="text" name="grade" required>
      <label>Position</label>
      <select name="position_id" required>
        <option value="">Select Position</option>
        <?php foreach ($positions as $p) echo "<option value='{$p['id']}'>{$p['name']}</option>"; ?>
      </select>
      <label>Partylist</label>
      <select name="partylist_id">
        <option value="">Select Partylist</option>
        <?php foreach ($partylists as $pl) echo "<option value='{$pl['id']}'>{$pl['name']}</option>"; ?>
      </select>
      <label>Biography</label>
      <textarea name="biography"></textarea>
      <label>Photo</label>
      <input type="file" name="photo">
      <div class="modal-buttons">
        <button type="submit" name="save_candidate" class="btn-save">Save</button>
        <button type="button" class="btn-cancel" onclick="closeModal('candidateModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Position Modal -->
<div id="positionModal" class="modal">
  <div class="modal-content">
    <h3>Add Position</h3>
    <form method="post">
      <label>Position Name</label>
      <input type="text" name="position_name" required>
      <label>Election</label>
      <select name="election_id" required>
        <option value="">Select Election</option>
        <?php foreach ($elections as $e) echo "<option value='{$e['id']}'>{$e['title']}</option>"; ?>
      </select>
      <label>Partylist (Optional)</label>
      <select name="partylist_id">
        <option value="">Select Partylist</option>
        <?php foreach ($partylists as $pl) echo "<option value='{$pl['id']}'>{$pl['name']}</option>"; ?>
      </select>
      <div class="modal-buttons">
        <button type="submit" name="save_position" class="btn-save">Save</button>
        <button type="button" class="btn-cancel" onclick="closeModal('positionModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>
