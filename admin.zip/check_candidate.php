<?php
require '../inc/db.php';

$student_id = $_POST['student_id'] ?? '';
$position_id = $_POST['position_id'] ?? '';

if (!$student_id || !$position_id) {
    echo 'ok'; // default
    exit;
}

$result = db_prepare_execute(
    "SELECT * FROM candidates WHERE student_id = ? AND position_id = ?",
    [$student_id, $position_id]
); 

if ($use_pdo) {
    $exists = $result->fetch(PDO::FETCH_ASSOC);
} else {
    $exists = $result->get_result()->fetch_assoc();
}

echo $exists ? 'exists' : 'ok';
exit;