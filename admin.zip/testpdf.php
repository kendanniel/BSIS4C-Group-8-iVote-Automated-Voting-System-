<?php
require_once '../vendor/autoload.php'; // path relative to testpdf.php

$mpdf = new \Mpdf\Mpdf();
$mpdf->WriteHTML('<h1>PDF Test</h1><p>If you see this, mPDF works!</p>');
$mpdf->Output(); // will open or download a PDF
