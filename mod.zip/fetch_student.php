<?php
require '../inc/db.php'; // mysqli connection

$student_id = $_GET['student_id'] ?? '';
if (!$student_id) {
    echo json_encode(['success' => false, 'error' => 'Student ID required']);
    exit;
}

$stmt = $conn->prepare("SELECT *, CONCAT(grade_level,' / ',strand,' ',section) AS grade_section FROM voters WHERE student_id=? LIMIT 1");
$stmt->bind_param('s', $student_id);
$stmt->execute();
$res = $stmt->get_result();
$student = $res->fetch_assoc();
$stmt->close();

if (!$student) {
    echo json_encode(['success' => false, 'error' => 'Student not found']);
    exit;
}

if ($student['is_candidate']) {
    echo json_encode(['success' => false, 'error' => 'This student is already a candidate']);
    exit;
}

echo json_encode([
    'success' => true,
    'firstname' => $student['firstname'],
    'lastname' => $student['lastname'],
    'grade_section' => $student['grade_section']
]);
