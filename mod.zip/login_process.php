<?php
session_start();
require '../inc/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $faculty_id = trim($_POST['faculty_id']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM moderators WHERE faculty_id = ? LIMIT 1");
    $stmt->bind_param("s", $faculty_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $moderator = $result->fetch_assoc();

        if (password_verify($password, $moderator['password'])) {
            // ✅ Store moderator info in session
            $_SESSION['moderator_id'] = $moderator['id'];
            $_SESSION['first_name'] = $moderator['first_name'];
            $_SESSION['last_name'] = $moderator['last_name'];
            $_SESSION['school_year'] = $moderator['school_year'];
            $_SESSION['level'] = $moderator['level'];
            $_SESSION['grades_handled'] = $moderator['grades_handled'];

            header("Location: dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid password. Please try again.'); window.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('Faculty ID not found.'); window.location.href='login.php';</script>";
    }
}
?>
