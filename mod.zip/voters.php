<?php
session_start();
require '../inc/db.php';            // must define $conn (mysqli)
require '../vendor/autoload.php';   // composer autoloader - PhpSpreadsheet installed

use PhpOffice\PhpSpreadsheet\IOFactory;

if (!isset($_SESSION['moderator_id'])) {
    header("Location: login.php");
    exit();
}
$current_page = basename($_SERVER['PHP_SELF']);

// ensure mysqli connection available
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection not found. Ensure inc/db.php defines \$conn as mysqli.");
}

/* ---------- helper ---------- */
function mysqli_prepare_execute($conn, $sql, $params = []) {
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    if (!empty($params)) {
        $types = str_repeat('s', count($params)); // treat all as strings
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

/* ---------- Fetch moderator's grades handled ---------- */
$moderator_id = $_SESSION['moderator_id'];
$grades_handled = '';
$mod_stmt = $conn->prepare("SELECT grades_handled FROM moderators WHERE id=? AND status='active'");
$mod_stmt->bind_param("i", $moderator_id);
$mod_stmt->execute();
$mod_res = $mod_stmt->get_result()->fetch_assoc();
$grades_handled = $mod_res['grades_handled'] ?? '';
$mod_stmt->close();

// normalize grades for matching with voters.grade_level
$grades_array = [];
if (!empty($grades_handled)) {
    $grades_array = array_map(function($g) {
        return preg_replace('/[^0-9]/', '', $g); // keep only digits
    }, array_map('trim', explode(',', $grades_handled)));
}

/* ---------- Fetch voters for display ---------- */
$voters = [];
if (!empty($grades_array)) {
    $placeholders = implode(',', array_fill(0, count($grades_array), '?'));
    $types = str_repeat('s', count($grades_array));

    $sql = "SELECT * FROM voters WHERE grade_level IN ($placeholders) AND status='active' ORDER BY id DESC";
    $stmt = $conn->prepare($sql);

    // bind params dynamically
    $stmt_params = [];
    foreach ($grades_array as $k => $grade) $stmt_params[$k] = &$grades_array[$k];
    array_unshift($stmt_params, $types);
    call_user_func_array([$stmt, 'bind_param'], $stmt_params);

    $stmt->execute();
    $res = $stmt->get_result();
    $voters = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

/* ---------- Handle single add voter ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_voter'])) {
    $student_id  = trim($_POST['student_id'] ?? '');
    $grade_section = trim($_POST['grade_section'] ?? '');
    $first_name  = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name   = trim($_POST['last_name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $password    = '@srnhs01';
    $status      = 'active';

    $grade_level = '';
    $strand = '';
    $section = '';

    if (!empty($grade_section)) {
        $parts = preg_split('/[-,]/', $grade_section);
        if (count($parts) >= 2) {
            $grade_level = trim($parts[0]);
            $rest = trim($parts[1]);
            $restParts = explode(' ', $rest, 2);
            $strand = trim($restParts[0]);
            $section = $restParts[1] ?? '';
        } else {
            $grade_level = trim($grade_section);
        }
    }

    if ($student_id === '' || $first_name === '' || $last_name === '') {
        $error = "Student ID, First Name and Last Name are required.";
    } else {
        // check duplicate student_id
        $chk = $conn->prepare("SELECT COUNT(*) AS c FROM voters WHERE student_id = ?");
        $chk->bind_param('s', $student_id);
        $chk->execute();
        $res = $chk->get_result()->fetch_assoc();
        $chk->close();
        $exists = $res['c'] ?? 0;

        if ($exists > 0) {
            $error = "Student ID already exists.";
        } else {
            try {
                mysqli_prepare_execute($conn,
                    "INSERT INTO voters (student_id, lastname, firstname, middlename, strand, grade_level, section, email, password, status)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$student_id, $last_name, $first_name, $middle_name, $strand, $grade_level, $section, $email, $password, $status]
                );
                $success = "Voter saved successfully.";
                header("Location: voters.php"); // reload after add
                exit();
            } catch (Exception $e) {
                $error = "Failed to add voter: " . $e->getMessage();
            }
        }
    }
}

/* ---------- Handle bulk import ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_voters'])) {
    if (!empty($_FILES['file']['tmp_name'])) {
        $fileTmp = $_FILES['file']['tmp_name'];
        try {
            $inputFileType = IOFactory::identify($fileTmp);
            $reader = IOFactory::createReader($inputFileType);
            $spreadsheet = $reader->load($fileTmp);
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray(null, true, true, true);

            $inserted = 0;
            foreach ($rows as $index => $row) {
                if ($index == 1) continue; // skip header
                $student_id = trim($row['A'] ?? '');
                $lastname   = trim($row['B'] ?? '');
                $firstname  = trim($row['C'] ?? '');
                $middlename = trim($row['D'] ?? '');
                $strand     = trim($row['E'] ?? '');
                $grade_level= trim($row['F'] ?? '');
                $section    = trim($row['G'] ?? '');
                $email      = trim($row['H'] ?? '');
                $password   = '@srnhs01';
                $status     = 'active';

                if ($student_id === '' || $firstname === '' || $lastname === '') continue;
                if (!in_array($grade_level, $grades_array)) continue; // skip grades not handled by moderator

                $chk = $conn->prepare("SELECT COUNT(*) AS c FROM voters WHERE student_id = ?");
                $chk->bind_param('s', $student_id);
                $chk->execute();
                $cres = $chk->get_result()->fetch_assoc();
                $chk->close();
                $exists = $cres['c'] ?? 0;
                if ($exists > 0) continue;

                mysqli_prepare_execute($conn,
                    "INSERT INTO voters (student_id, lastname, firstname, middlename, strand, grade_level, section, email, password, status)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$student_id, $lastname, $firstname, $middlename, $strand, $grade_level, $section, $email, $password, $status]
                );
                $inserted++;
            }

            $success = "$inserted voter(s) successfully imported.";
            header("Location: voters.php"); // reload after import
            exit();
        } catch (Exception $e) {
            $error = "Import error: " . $e->getMessage();
        }
    } else {
        $error = "Please select a file to upload.";
    }
}

/* ---------- Handle voter edit ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_voter'])) {
    $id = intval($_POST['voter_id'] ?? 0);
    $student_id = trim($_POST['student_id'] ?? '');
    $grade_section = trim($_POST['grade_section'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    $grade_level = '';
    $strand = '';
    $section = '';
    if (!empty($grade_section)) {
        $parts = preg_split('/[-,]/', $grade_section);
        if (count($parts) >= 2) {
            $grade_level = trim($parts[0]);
            $rest = trim($parts[1]);
            $restParts = explode(' ', $rest, 2);
            $strand = trim($restParts[0]);
            $section = $restParts[1] ?? '';
        } else {
            $grade_level = trim($grade_section);
        }
    }

    if ($id > 0 && $student_id !== '' && $first_name !== '' && $last_name !== '') {
        if (!in_array($grade_level, $grades_array)) {
            $error = "You cannot assign a voter to a grade you don't handle.";
        } else {
            $stmt = $conn->prepare("UPDATE voters SET student_id=?, firstname=?, middlename=?, lastname=?, grade_level=?, strand=?, section=?, email=? WHERE id=?");
            $stmt->bind_param('ssssssssi', $student_id, $first_name, $middle_name, $last_name, $grade_level, $strand, $section, $email, $id);
            if ($stmt->execute()) {
                $success = "Voter updated successfully.";
                header("Location: voters.php");
                exit();
            } else {
                $error = "Failed to update voter.";
            }
            $stmt->close();
        }
    } else {
        $error = "Required fields cannot be empty.";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Moderator - Manage Voters</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin_voters.css">
  <style>
    .modal { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1000; justify-content:center; align-items:center; padding:20px; }
    .modal-content { background:#fff; border-radius:10px; padding:20px; width:100%; max-width:560px; max-height:90vh; overflow:auto; box-shadow:0 8px 30px rgba(0,0,0,0.2); }
    .notice { background:#eafbea; color:#006600; padding:8px; border-radius:6px; margin:10px 0; }
    .error { background:#ffecec; color:#b00; padding:8px; border-radius:6px; margin:10px 0; }
  </style>
</head>
<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<!-- SIDE PANEL -->
<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(180deg,#0f172a,#1e293b);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Moderator</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">

<div class="nav-btn" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn active" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>

<style>
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}
</style>

<!-- MAIN CONTENT -->
<div style="margin-left:260px;padding:30px;width:100%;">



</header>
    <div class="content">
      <div class="page-header">
        <h3>Manage Voters</h3>
        <div class="buttons">
          <button class="btn blue" id="openImportBtn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-480ZM202-65l-56-57 118-118h-90v-80h226v226h-80v-89L202-65Zm278-15v-80h240v-440H520v-200H240v400h-80v-400q0-33 23.5-56.5T240-880h320l240 240v480q0 33-23.5 56.5T720-80H480Z"/></svg> Bulk Registration</button>
          <button class="btn blue" id="addVoterBtn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M440-280h80v-160h160v-80H520v-160h-80v160H280v80h160v160Zm40 200q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg> Register</button>
        </div>
      </div>

      <?php if (!empty($error)): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <?php if (!empty($success)): ?><div class="notice"><?= htmlspecialchars($success) ?></div><?php endif; ?>

      <div class="stat-box purple">
        <p>Total Voters</p>
        <h1><?= count($voters); ?></h1>
      </div>
      <!-- 🔍 SEARCH BAR -->
<div class="search-bar-container" style="margin-bottom:16px; display:flex; align-items:center; gap:8px;">
  <input type="text" id="searchInput" placeholder="🔍 Enter Student ID or Name"
         style="padding:8px 12px; border:1px solid #ccc; border-radius:6px; width:300px;">
  <button id="searchBtn" class="btn-save" style="padding:8px 14px;">Search</button>
  <button id="resetBtn" class="btn-cancel" style="padding:8px 14px;">Reset</button>
</div>


      <table class="data-table">
    <thead>
        <tr>
            <th>Student ID</th>
            <th>Grade Level</th>
            <th>Strand</th>
            <th>Section</th>
            <th>Name</th>
            <th>Email</th>
            <!--<th>Status</th>-->
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if (count($voters) > 0): ?>
        <?php foreach ($voters as $v): ?>
        <?php
            $strand = $v['strand'] ?? '';
            $grade = $v['grade_level'] ?? '';
            $section = $v['section'] ?? '';

            if (is_numeric($strand) || preg_match('/^(7|8|9|10|11|12)$/', $strand)) {
                $temp = $strand;
                $strand = $grade;
                $grade = $temp;
            }

            if (preg_match('/^(STEM|HUMSS|ABM|TVL|GAS)$/i', $grade)) {
                $temp = $grade;
                $grade = $strand;
                $strand = $temp;
            }
        ?>
        <tr>
    <td><?= htmlspecialchars($v['student_id']); ?></td>
    <td><?= htmlspecialchars($grade); ?></td>
    <td><?= htmlspecialchars($strand); ?></td>
    <td><?= htmlspecialchars($section); ?></td>
    <td><?= htmlspecialchars($v['firstname'].' '.$v['middlename'].' '.$v['lastname']); ?></td>
    <td><?= htmlspecialchars($v['email']); ?></td>
    <!--<td><?= htmlspecialchars(strtoupper($v['status'])); ?></td>-->
    <td class="actions">
    <button class="action-btn view" data-id="<?= $v['id'] ?>" title="View"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M607.5-372.5Q660-425 660-500t-52.5-127.5Q555-680 480-680t-127.5 52.5Q300-575 300-500t52.5 127.5Q405-320 480-320t127.5-52.5Zm-204-51Q372-455 372-500t31.5-76.5Q435-608 480-608t76.5 31.5Q588-545 588-500t-31.5 76.5Q525-392 480-392t-76.5-31.5ZM214-281.5Q94-363 40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200q-146 0-266-81.5ZM480-500Zm207.5 160.5Q782-399 832-500q-50-101-144.5-160.5T480-720q-113 0-207.5 59.5T128-500q50 101 144.5 160.5T480-280q113 0 207.5-59.5Z"/></svg>️</button>
    <button class="action-btn edit" data-id="<?= $v['id'] ?>" title="Edit"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z"/></svg></button>
    <button class="action-btn archive" data-id="<?= $v['id'] ?>" title="Archive"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="m480-240 160-160-56-56-64 64v-168h-80v168l-64-64-56 56 160 160ZM200-640v440h560v-440H200Zm0 520q-33 0-56.5-23.5T120-200v-499q0-14 4.5-27t13.5-24l50-61q11-14 27.5-21.5T250-840h460q18 0 34.5 7.5T772-811l50 61q9 11 13.5 24t4.5 27v499q0 33-23.5 56.5T760-120H200Zm16-600h528l-34-40H250l-34 40Zm264 300Z"/></svg>️</button>
</td>

</tr>

        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="8" style="text-align:center;">No voters found</td></tr>
    <?php endif; ?>
    </tbody>
</table>

    </div>
  </div>

  <!-- Add Voter Modal -->
  <div class="modal" id="voterModal">
    <div class="modal-content">
      <div style="text-align:center;font-weight:700;font-size:20px;margin-bottom:10px;">Register New Voter</div>
      <form method="POST">
        <input type="hidden" name="save_voter" value="1">
        <div class="form-group"><label>Student ID</label><input type="text" name="student_id" required></div>
        <div class="form-group"><label>Grade/Strand & Section</label><input type="text" name="grade_section" placeholder="e.g. Grade 11 - STEM A" required></div>
        <div class="form-group"><label>First Name</label><input type="text" name="first_name" required></div>
        <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name"></div>
        <div class="form-group"><label>Last Name</label><input type="text" name="last_name" required></div>
        <div class="form-group"><label>Email Address</label><input type="email" name="email"></div>
        <div class="modal-buttons" style="display:flex;justify-content:end;gap:10px;">
          <button type="button" id="cancelAdd" class="btn-cancel">Cancel</button>
          <button type="submit" class="btn-save">Save</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Import Modal -->
  <div class="modal" id="importModal">
    <div class="modal-content">
      <div style="text-align:center;font-weight:700;font-size:20px;margin-bottom:10px;">Bulk Import Voters</div>
      <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" accept=".xlsx,.xls,.csv" required>
        <div style="margin-top:10px;display:flex;justify-content:end;gap:10px;">
          <button type="button" id="cancelImportBtn" class="btn-cancel">Cancel</button>
          <button type="submit" name="import_voters" class="btn-save">Import</button>
        </div>
      </form>
    </div>
  </div>

  <!-- View Voter Modal -->
<div class="modal" id="viewModal">
  <div class="modal-content">
    <div style="text-align:center;font-weight:700;font-size:20px;margin-bottom:10px;">Voter Details</div>
    <div class="voter-details" id="viewContent">
      <p><strong>Student ID:</strong> <span id="v_student_id"></span></p>
      <p><strong>Name:</strong> <span id="v_name"></span></p>
      <p><strong>Grade / Strand / Section:</strong> <span id="v_grade_section"></span></p>
      <p><strong>Email:</strong> <span id="v_email"></span></p>
      <!--<p><strong>Status:</strong> <span id="v_status"></span></p>-->
    </div>
    <div style="text-align:right; margin-top:15px;">
      <button type="button" id="closeViewModal" class="btn-cancel">Close</button>
    </div>
  </div>
</div>



  <div class="modal" id="editModal">
    <div class="modal-content">
        <div style="text-align:center;font-weight:700;font-size:20px;margin-bottom:10px;">Edit Voter</div>
        <form method="POST" id="editForm">
            <input type="hidden" name="edit_voter" value="1">
            <input type="hidden" name="voter_id" id="editVoterId">
            <div class="form-group"><label>Student ID</label><input type="text" name="student_id" id="editStudentId" required></div>
            <div class="form-group"><label>Grade/Strand & Section</label><input type="text" name="grade_section" id="editGradeSection" required></div>
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" id="editFirstName" required></div>
            <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" id="editMiddleName"></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" id="editLastName" required></div>
            <div class="form-group"><label>Email Address</label><input type="email" name="email" id="editEmail"></div>
            <div class="modal-buttons" style="display:flex;justify-content:end;gap:10px;">
                <button type="button" class="btn-cancel" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn-save">Update</button>
            </div>
        </form>
    </div>
</div>

<script>
  const voterModal = document.getElementById('voterModal');
  const importModal = document.getElementById('importModal');
  document.getElementById('addVoterBtn').onclick = () => voterModal.style.display='flex';
  document.getElementById('cancelAdd').onclick = () => voterModal.style.display='none';
  document.getElementById('openImportBtn').onclick = () => importModal.style.display='flex';
  document.getElementById('cancelImportBtn').onclick = () => importModal.style.display='none';
  window.onclick = (e)=>{ if(e.target===voterModal)voterModal.style.display='none'; if(e.target===importModal)importModal.style.display='none'; }
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const resetBtn = document.getElementById('resetBtn');
  const tableBody = document.querySelector('.data-table tbody');

  function searchVoters() {
    const query = searchInput.value.trim();
    if (query === '') {
      alert('Please enter a student ID or name.');
      return;
    }

    fetch('search_voters.php?q=' + encodeURIComponent(query))
      .then(res => res.json())
      .then(data => {
        if (data.success && data.voters.length > 0) {
          let rows = '';
          data.voters.forEach(v => {
            rows += `
              <tr>
                <td>${v.student_id}</td>
                <td>${v.grade_level}</td>
                <td>${v.strand}</td>
                <td>${v.section}</td>
                <td>${v.firstname} ${v.middlename ?? ''} ${v.lastname}</td>
                <td>${v.email}</td>
                <td>${v.status.toUpperCase()}</td>
              </tr>`;
          });
          tableBody.innerHTML = rows;
        } else {
          tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:red;">No voters found.</td></tr>`;
        }
      })
      .catch(err => {
        console.error(err);
        alert('Search failed. Check console.');
      });
  }

  searchBtn.addEventListener('click', searchVoters);
  searchInput.addEventListener('keypress', e => { if (e.key === 'Enter') searchVoters(); });
  resetBtn.addEventListener('click', () => location.reload());
});
function openEditModal(id) {
    fetch('get_voter.php?id=' + id)
        .then(res => res.json())
        .then(v => {
            if (v.success) {
                document.getElementById('editVoterId').value = v.voter.id;
                document.getElementById('editStudentId').value = v.voter.student_id;
                document.getElementById('editGradeSection').value = `${v.voter.grade_level} - ${v.voter.strand} ${v.voter.section}`;
                document.getElementById('editFirstName').value = v.voter.firstname;
                document.getElementById('editMiddleName').value = v.voter.middlename;
                document.getElementById('editLastName').value = v.voter.lastname;
                document.getElementById('editEmail').value = v.voter.email;
                document.getElementById('editModal').style.display = 'flex';
            } else alert('Voter not found');
        });
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function openViewModal(id) {
    fetch('get_voter.php?id=' + id)
        .then(res => res.json())
        .then(v => {
            if (v.success) {
                const c = v.voter;
                document.getElementById('viewContent').innerHTML = `
                    <p><strong>Student ID:</strong> ${c.student_id}</p>
                    <p><strong>Name:</strong> ${c.firstname} ${c.middlename ?? ''} ${c.lastname}</p>
                    <p><strong>Grade / Strand / Section:</strong> ${c.grade_level} - ${c.strand} ${c.section}</p>
                    <p><strong>Email:</strong> ${c.email}</p>
                    <p><strong>Status:</strong> ${c.status.toUpperCase()}</p>
                `;
                document.getElementById('viewModal').style.display = 'flex';
            } else alert('Voter not found');
        });
}


function closeViewModal() {
    document.getElementById('viewModal').style.display = 'none';
}

function archiveVoter(id) {
    if (!confirm('Are you sure you want to archive this voter?')) return;
    fetch('archive_voter.php?id=' + id)
        .then(res => res.json())
        .then(r => {
            if (r.success) location.reload();
            else alert('Failed to archive voter');
        });
}

document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.querySelector('.data-table tbody');
    const viewModal = document.getElementById('viewModal');
    const viewContent = document.getElementById('viewContent');
    const closeViewModalBtn = document.getElementById('closeViewModal');

    closeViewModalBtn.onclick = () => viewModal.style.display = 'none';

    tableBody.addEventListener('click', function(e) {
        const btn = e.target;
        const id = btn.dataset.id;
        if (!id) return;

        // VIEW
        if (btn.classList.contains('view')) {
            fetch('get_voter.php?id=' + id)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const v = data.voter;
                        viewContent.innerHTML = `
                            <p><strong>Student ID:</strong> ${v.student_id}</p>
                            <p><strong>Name:</strong> ${v.firstname} ${v.middlename ?? ''} ${v.lastname}</p>
                            <p><strong>Grade / Strand / Section:</strong> ${v.grade_level} - ${v.strand} ${v.section}</p>
                            <p><strong>Email:</strong> ${v.email}</p>
                            <p><strong>Status:</strong> ${v.status.toUpperCase()}</p>
                        `;
                        viewModal.style.display = 'flex';
                    } else alert(data.message || 'Voter not found');
                });
        }

        // EDIT
        if (btn.classList.contains('edit')) openEditModal(id);

        // ARCHIVE
        if (btn.classList.contains('archive')) archiveVoter(id);
    });

    // Close modals when clicking outside
    window.onclick = e => {
        ['voterModal','importModal','editModal','viewModal'].forEach(mid => {
            const modal = document.getElementById(mid);
            if (e.target === modal) modal.style.display = 'none';
        });
    };
});
document.getElementById('closeViewModal').onclick = () => {
    document.getElementById('viewModal').style.display = 'none';
};




</script>

</body>
</html>
