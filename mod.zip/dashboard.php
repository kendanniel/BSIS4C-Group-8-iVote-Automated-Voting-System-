<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'moderator') {
    header("Location: login.php");
    exit();
}

// ===== MODERATOR ACCESS CONTROL =====
$username = $_SESSION['username'] ?? '';
$allowedGrades = [];

if ($username === '2025-101') {
    $allowedGrades = [7, 8];
} elseif ($username === '2025-102') {
    $allowedGrades = [9, 10];
} elseif ($username === '2025-103') {
    $allowedGrades = [11];
} else {
    // Default for other moderators or admin-level access
    $allowedGrades = [7, 8, 9, 10, 11, 12];
}

// Convert allowed grades to a format for SQL
$gradePlaceholders = implode(',', array_fill(0, count($allowedGrades), '?'));

// ===== TOTAL VOTERS (Filtered by Moderator Access) =====
$stmtVoters = $conn->prepare("SELECT COUNT(*) as total FROM voters WHERE grade_level IN ($gradePlaceholders)");
$stmtVoters->bind_param(str_repeat('i', count($allowedGrades)), ...$allowedGrades);
$stmtVoters->execute();
$totalVoters = $stmtVoters->get_result()->fetch_assoc()['total'] ?? 0;

// ===== OTHER STATS =====
$totalCandidates = ($conn->query("SELECT COUNT(*) as t FROM candidates")->fetch_assoc()['t']) ?? 0;
$totalModerators = ($conn->query("SELECT COUNT(*) as t FROM users WHERE role='moderator'")->fetch_assoc()['t']) ?? 0;

// ===== VOTERS PER GRADE STATS (Detailed for Filter) =====
$gradeStats = [];
foreach ($allowedGrades as $g) {
    // Total in this grade
    $stmtT = $conn->prepare("SELECT COUNT(*) as count FROM voters WHERE grade_level = ?");
    $stmtT->bind_param("i", $g);
    $stmtT->execute();
    $total_g = $stmtT->get_result()->fetch_assoc()['count'] ?? 0;

    // Voted in this grade
    $stmtV = $conn->prepare("SELECT COUNT(DISTINCT voter_id) as count FROM votes v JOIN voters vt ON v.voter_id = vt.id WHERE vt.grade_level = ?");
    $stmtV->bind_param("i", $g);
    $stmtV->execute();
    $voted_g = $stmtV->get_result()->fetch_assoc()['count'] ?? 0;

    $gradeStats[] = [
        'grade_level' => $g,
        'total_voters' => $total_g,
        'voted_count' => $voted_g,
        'not_voted' => $total_g - $voted_g,
        'percent' => ($total_g > 0) ? round(($voted_g / $total_g) * 100) : 0
    ];
}

// ===== POSITIONS =====
$positionsData = $conn->query("SELECT id, name FROM positions ORDER BY position_order ASC");
$positions = [];
while ($row = $positionsData->fetch_assoc()) $positions[$row['id']] = $row['name'];

// ===== CANDIDATES + VOTES (Filtered by Moderator Grades) =====
$votesData = [];
foreach ($positions as $pos_id => $pos_name) {
    $stmt = $conn->prepare("
        SELECT c.id, c.firstname, c.lastname,
               (SELECT COUNT(*) FROM votes v 
                JOIN voters vt ON v.voter_id = vt.id 
                WHERE v.candidate_id = c.id AND v.position_id = c.position_id 
                AND vt.grade_level IN ($gradePlaceholders)) AS votes
        FROM candidates c
        WHERE c.position_id = ?
        ORDER BY votes DESC
    ");
    
    $params = array_merge($allowedGrades, [$pos_id]);
    $types = str_repeat('i', count($allowedGrades)) . 'i';
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();

    $votesData[$pos_id] = [];
    while ($row = $res->fetch_assoc()) {
        $row['fullname'] = $row['firstname'] . ' ' . $row['lastname'];
        $row['percent'] = ($totalVoters > 0) ? round(($row['votes'] / $totalVoters) * 100) : 0;
        $votesData[$pos_id][] = $row;
    }
}

// ===== MESSAGE HOLDER =====
$message = '';

// ===== RESET PASSWORDS (Targeted) =====
if (isset($_POST['reset_all'])) {
    $defaultHash = password_hash('@srnhs01', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE voters SET password = ?, password_changed = 0 WHERE grade_level IN ($gradePlaceholders)");
    $stmt->bind_param("s" . str_repeat('i', count($allowedGrades)), $defaultHash, ...$allowedGrades);
    $message = ($stmt->execute()) ? "✅ Passwords for your assigned grades have been reset." : "❌ Failed to reset passwords.";
}

// ===== DELETE VOTES / CANDIDATES (Global Actions) =====
if (isset($_POST['delete_votes'])) {
    $message = ($conn->query("DELETE FROM votes")) ? "🗑️ All votes deleted." : "❌ Failed.";
}
if (isset($_POST['delete_candidates'])) {
    $photoQuery = $conn->query("SELECT photo FROM candidates WHERE photo IS NOT NULL AND photo != ''");
    if ($photoQuery) {
        while ($photo = $photoQuery->fetch_assoc()) {
            $file = "../uploads/" . $photo['photo'];
            if (file_exists($file)) unlink($file);
        }
    }
    $message = ($conn->query("DELETE FROM candidates") && $conn->query("DELETE FROM votes")) ? "🗑️ Data wiped." : "❌ Failed.";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Moderator Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
* { box-sizing: border-box; }
body { margin: 0; font-family: 'DM Sans', Poppins, sans-serif; background: #f0f4f8; }
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}

.stat-card { flex: 1; min-width: 200px; padding: 24px 22px; border-radius: 16px; color: white; box-shadow: 0 8px 24px rgba(0,0,0,0.12); position: relative; overflow: hidden; }
.stat-card-label { font-size: 11.5px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; opacity: 0.75; margin-bottom: 10px; }
.stat-card-value { font-size: 38px; font-weight: 700; line-height: 1; margin-bottom: 6px; }
.stat-card-sub { font-size: 12px; opacity: 0.65; }

.turnout-card { flex: 1; min-width: 280px; padding: 24px; border-radius: 16px; color: white; box-shadow: 0 8px 24px rgba(0,0,0,0.12); transition: all 0.3s ease; }
.grade-group { margin-bottom: 15px; transition: all 0.3s ease; }
.grade-row { display: flex; justify-content: space-between; align-items: center; font-size: 13px; background: rgba(255,255,255,0.1); padding: 5px 10px; border-radius: 8px; }
.turnout-progress-track { margin-top: 5px; background: rgba(255,255,255,0.25); border-radius: 10px; height: 6px; overflow: hidden; }
.turnout-progress-fill { height: 100%; border-radius: 10px; background: rgba(255,255,255,0.9); }

.section-heading { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
.section-heading-bar { width: 4px; height: 26px; background: linear-gradient(180deg, #3b82f6, #6366f1); border-radius: 3px; }
.section-heading-title { font-family: 'Playfair Display', serif; font-size: 19px; font-weight: 700; color: #1e293b; }

.tally-section { background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 4px 18px rgba(15,23,42,0.07); border: 1px solid #e8eef5; }
.position-tally { margin-bottom: 32px; padding-bottom: 32px; border-bottom: 1px solid #f1f5f9; }
.position-tally-header { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.position-tally-icon { width: 32px; height: 32px; border-radius: 8px; background: linear-gradient(135deg, #1e3a5f, #266bc5); display: flex; align-items: center; justify-content: center; }
.position-tally-name { font-family: 'Playfair Display', serif; font-size: 16px; font-weight: 700; color: #1e293b; }

.tally-bar-row { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.tally-bar-name { width: 160px; font-size: 12.5px; font-weight: 600; color: #334155; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.tally-bar-track { flex: 1; height: 10px; background: #f1f5f9; border-radius: 99px; overflow: hidden; }
.tally-bar-fill { height: 100%; border-radius: 99px; background: linear-gradient(90deg, #3b82f6, #6366f1); }
.tally-bar-votes { font-size: 12px; font-weight: 700; color: #3b82f6; width: 70px; text-align: right; }

.anim { animation: fadeInUp 0.45s ease both; }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
.sticky-header { position: sticky; top: 0; z-index: 100; background: #f1f5f9; padding: 20px 0; margin-bottom: 20px !important; }
</style>
</head>

<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<!-- SIDE PANEL -->
<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(180deg,#0f172a,#1e293b);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Moderator</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">

<div class="nav-btn active" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>

<style>
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}
</style>


<div style="margin-left: 240px; padding: 0 32px 48px; width: calc(100% - 240px);">
    <header class="anim sticky-header" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
            <h2 style="margin:0; font-size:26px; font-weight:700; color:#1e293b;">Welcome, Moderator!</h2>
            <div style="margin-top:10px; display:flex; align-items:center; gap:10px;">
                <span style="font-size:13px; font-weight:600; color:#64748b;">Filter View:</span>
                <select id="gradeFilter" onchange="applyGradeFilter()" style="padding:6px 12px; border-radius:8px; border:1px solid #cbd5e1; background:white; cursor:pointer; font-family:inherit;">
                    <option value="all">All Assigned Grades</option>
                    <?php foreach($gradeStats as $grade): ?>
                        <option value="<?= $grade['grade_level'] ?>">Grade <?= $grade['grade_level'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div style="text-align:right; font-weight:500; color:#64748b;">
            <?php date_default_timezone_set('Asia/Manila'); echo date("F d, Y") . "<br>" . date("g:i A"); ?>
        </div>
    </header>

    <?php if ($message): ?>
        <div style="padding: 15px; background: white; border-left: 4px solid #3b82f6; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);"><?= $message ?></div>
    <?php endif; ?>

    <div style="display:flex; gap:18px; flex-wrap:wrap; margin-bottom:24px;">
        <div class="stat-card anim" style="background:linear-gradient(135deg,#1e3a5f 0%,#266bc5 100%);">
            <div class="stat-card-label">Assigned Voters</div>
            <div class="stat-card-value" id="voterMainCount"><?= $totalVoters ?></div>
            <div class="stat-card-sub" id="voterMainLabel">Total Registered</div>
        </div>
        <div class="stat-card anim" style="background:linear-gradient(135deg,#4f46e5 0%,#7872fa 100%);">
            <div class="stat-card-label">Total Candidates</div>
            <div class="stat-card-value"><?= $totalCandidates ?></div>
            <div class="stat-card-sub">Global Count</div>
        </div>
       
    </div>

    <div style="display:flex; gap:18px; flex-wrap:wrap; margin-bottom:32px;">
        <div class="turnout-card anim" style="background:linear-gradient(135deg,#25a18e 0%,#1a7f6b 100%);">
            <div style="font-size:11.5px; font-weight:600; text-transform:uppercase; opacity:0.75; margin-bottom:12px;">Voter Turnout</div>
            <?php foreach($gradeStats as $grade): ?>
            <div class="grade-group" data-grade="<?= $grade['grade_level'] ?>">
                <div class="grade-row">
                    <span>Grade <?= $grade['grade_level'] ?></span>
                    <span style="font-weight:700;"><?= $grade['voted_count'] ?> / <?= $grade['total_voters'] ?> (<?= $grade['percent'] ?>%)</span>
                </div>
                <div class="turnout-progress-track"><div class="turnout-progress-fill" style="width:<?= $grade['percent'] ?>%;"></div></div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="turnout-card anim" style="background:linear-gradient(135deg,#1e6091 0%,#155e75 100%);">
            <div style="font-size:11.5px; font-weight:600; text-transform:uppercase; opacity:0.75; margin-bottom:12px;">Pending Votes</div>
            <?php foreach($gradeStats as $grade): 
                $remP = ($grade['total_voters'] > 0) ? round(($grade['not_voted'] / $grade['total_voters']) * 100) : 0; ?>
            <div class="grade-group" data-grade="<?= $grade['grade_level'] ?>">
                <div class="grade-row">
                    <span>Grade <?= $grade['grade_level'] ?></span>
                    <span style="font-weight:700;"><?= $grade['not_voted'] ?> left</span>
                </div>
                <div class="turnout-progress-track"><div class="turnout-progress-fill" style="width:<?= $remP ?>%; background:rgba(255,255,255,0.6);"></div></div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="anim" style="flex:1; min-width:280px; background:#fff; border-radius:16px; padding:22px; border:1px solid #e2e8f0; box-shadow:0 4px 18px rgba(0,0,0,0.06);">
            <div style="font-size:12px; font-weight:600; text-transform:uppercase; color:#94a3b8; margin-bottom:12px;">Snapshot</div>
            <div style="overflow-y:auto; max-height:220px;">
                <?php foreach($gradeStats as $grade): ?>
                <div class="grade-group" data-grade="<?= $grade['grade_level'] ?>" style="margin-bottom:15px; border-bottom:1px solid #f1f5f9; padding-bottom:8px;">
                    <div style="font-size:13px; font-weight:700; color:#1e293b;">Grade <?= $grade['grade_level'] ?></div>
                    <div style="display:flex; justify-content:space-between; font-size:12px; color:#64748b;">
                        <span>Voted: <b style="color:#10b981;"><?= $grade['voted_count'] ?></b></span>
                        <span>Turnout: <b style="color:#3b82f6;"><?= $grade['percent'] ?>%</b></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="tally-section anim">
        <div class="section-heading"><span class="section-heading-bar"></span><span class="section-heading-title">Votes Tally (Your Assigned Grades)</span></div>

        <?php foreach ($votesData as $pos_id => $candidates): ?>
        <div class="position-tally">
            <div class="position-tally-header">
                <div class="position-tally-icon"><svg height="16" width="16" fill="#fff" viewBox="0 -960 960 960"><path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-160v-112q0-34 17-62.5t47-43.5q60-30 124.5-46T480-440q66 0 130 15.5T736-378q30 15 47 43.5t17 62.5v112H160Z"/></svg></div>
                <span class="position-tally-name"><?= htmlspecialchars($positions[$pos_id]) ?></span>
            </div>

            <div style="display:flex; align-items:center; gap:28px; flex-wrap:wrap;">
                <div style="flex:1; min-width:220px;">
                    <?php 
                    $maxVotes = max(array_column($candidates, 'votes') ?: [1]);
                    foreach ($candidates as $idx => $cand):
                        $barWidth = ($maxVotes > 0) ? round(($cand['votes'] / $maxVotes) * 100) : 0;
                        $isLeader = ($idx === 0 && $cand['votes'] > 0);
                    ?>
                    <div class="tally-bar-row">
                        <div class="tally-bar-name"><?= ($isLeader ? '🏆 ' : '') . htmlspecialchars($cand['fullname']) ?></div>
                        <div class="tally-bar-track">
                            <div class="tally-bar-fill" style="width:<?= $barWidth ?>%; background: <?= $isLeader ? '#0ea5e9' : '#6366f1' ?>;"></div>
                        </div>
                        <div class="tally-bar-votes"><?= $cand['votes'] ?> <span style="font-size:10px; color:#94a3b8;">(<?= $cand['percent'] ?>%)</span></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div style="text-align:center;"><canvas id="pie-<?= $pos_id ?>" width="140" height="140"></canvas></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
const gradeStats = <?php echo json_encode($gradeStats); ?>;
const totalGlobalVoters = <?= $totalVoters ?>;

function applyGradeFilter() {
    const val = document.getElementById('gradeFilter').value;
    const groups = document.querySelectorAll('.grade-group');
    const mainCount = document.getElementById('voterMainCount');
    const mainLabel = document.getElementById('voterMainLabel');

    if (val === 'all') {
        groups.forEach(g => g.style.display = 'block');
        mainCount.innerText = totalGlobalVoters;
        mainLabel.innerText = "Total Assigned";
    } else {
        groups.forEach(g => {
            g.style.display = (g.getAttribute('data-grade') === val) ? 'block' : 'none';
        });
        const selected = gradeStats.find(s => s.grade_level == val);
        mainCount.innerText = selected ? selected.total_voters : 0;
        mainLabel.innerText = "Grade " + val + " Voters";
    }
}

const votesData = <?php echo json_encode($votesData); ?>;
const colors = ['#3b82f6', '#6366f1', '#14b8a6', '#f59e0b', '#ec4899'];

for (let pos_id in votesData) {
    const canvas = document.getElementById('pie-' + pos_id);
    if (!canvas) continue;
    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: votesData[pos_id].map(c => c.fullname),
            datasets: [{
                data: votesData[pos_id].map(c => c.votes),
                backgroundColor: colors,
                borderWidth: 0
            }]
        },
        options: { plugins: { legend: { display: false } }, responsive: false }
    });
}
</script>
</body>
</html>