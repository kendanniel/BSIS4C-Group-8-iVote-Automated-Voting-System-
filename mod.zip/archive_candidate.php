<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['moderator_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$id = $_POST['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Candidate ID missing']);
    exit;
}
$candidate_id = $_POST['id'];

try {
    // Archive candidate
    $stmt = $conn->prepare("UPDATE candidates SET status='archived' WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    // Mark corresponding voter as NOT a candidate
    $stmt = $conn->prepare("
        UPDATE voters v
        JOIN candidates c ON v.student_id = c.student_id
        SET v.is_candidate = 0
        WHERE c.id = ?
    ");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
