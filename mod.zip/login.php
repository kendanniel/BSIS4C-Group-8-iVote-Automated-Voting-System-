<?php
session_start();
require '../inc/db.php'; // correct path to your database file
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>iVote | Moderator Login</title>
  <link rel="stylesheet" href="login.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
  <div class="login-container">
    <!-- LEFT PANEL -->
    <div class="left-panel">
      <img src="srnhs-logo.png" alt="School Logo">
    </div>

    <!-- RIGHT PANEL -->
    <div class="right-panel">
      <div class="logo-text">
        <small>i</small><span>Vote</span>
      </div>

      <!-- LOGIN FORM -->
      <form action="login_process.php" method="POST">
        <div class="input-group">
          <i class="fa fa-user"></i>
          <input type="text" name="faculty_id" placeholder="Faculty ID" required>
        </div>

        <div class="input-group">
          <i class="fa fa-lock"></i>
          <input type="password" name="password" placeholder="Password" required>
        </div>

        <div class="forgot-pass">
          <a href="forgot_password.php">Forgot Password?</a>
        </div>

        <button type="submit" class="login-btn">LOG IN</button>
      </form>
    </div>
  </div>
 </body>
 </html>