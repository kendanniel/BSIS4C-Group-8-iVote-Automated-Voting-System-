<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['moderator_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Candidate ID required']);
    exit;
}

$id = intval($_GET['id']);
$query = "SELECT * FROM candidates WHERE id = $id LIMIT 1";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $candidate = $result->fetch_assoc();
    echo json_encode($candidate);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Candidate not found']);
}
?>
