<?php
session_start();
require '../inc/db.php';

if (!isset($_SESSION['moderator_id'])) {
    header("Location: ../login.php");
    exit();
}

// Sanitize POST
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$student_id = $_POST['student_id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$grade_section = $_POST['grade_section'];
$position_id = intval($_POST['position_id']);
$partylist_id = isset($_POST['partylist_id']) ? intval($_POST['partylist_id']) : null;
$status = $_POST['status'] ?? 'active';

// Handle photo upload
$photo_name = '';
if (!empty($_FILES['photo']['name'])) {
    $target_dir = "../uploads/";
    $photo_name = time() . "_" . basename($_FILES["photo"]["name"]);
    move_uploaded_file($_FILES["photo"]["tmp_name"], $target_dir . $photo_name);
}

if ($id > 0) {
    // UPDATE
    $update_sql = "UPDATE candidates SET 
                    student_id = '$student_id',
                    firstname = '$firstname',
                    lastname = '$lastname',
                    grade_section = '$grade_section',
                    position_id = $position_id,
                    partylist_id = " . ($partylist_id ?? "NULL") . ",
                    status = '$status'";

    if ($photo_name) {
        $update_sql .= ", photo = '$photo_name'";
    }

    $update_sql .= " WHERE id = $id";

    if ($conn->query($update_sql)) {
        $_SESSION['message'] = "Candidate updated successfully.";
    } else {
        $_SESSION['error'] = "Error updating candidate: " . $conn->error;
    }
} else {
    // INSERT
    $insert_sql = "INSERT INTO candidates (student_id, firstname, lastname, grade_section, position_id, partylist_id, status, photo)
                   VALUES ('$student_id', '$firstname', '$lastname', '$grade_section', $position_id, " . ($partylist_id ?? "NULL") . ", '$status', '$photo_name')";
    if ($conn->query($insert_sql)) {
        $_SESSION['message'] = "Candidate added successfully.";
    } else {
        $_SESSION['error'] = "Error adding candidate: " . $conn->error;
    }
}

header("Location: candidates.php");
exit();
?>
