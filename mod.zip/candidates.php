<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


session_start();
require '../inc/db.php'; // your existing connection file

if (!isset($_SESSION['moderator_id'])) {
    header("Location: login.php");
    exit();
}

/*
  Compatibility layer:
  - If your db.php defines $pdo (PDO instance), we use it.
  - If it defines $conn or $mysqli (mysqli instance), we use mysqli.
  - If it defines DB_HOST / DB_USER constants, we try to create a PDO.
*/
$use_pdo = false;
$use_mysqli = false;
$pdo = $pdo ?? null;
$mysqli = null;

if ($pdo instanceof PDO) {
    $use_pdo = true;
} elseif (isset($conn) && $conn instanceof mysqli) {
    $mysqli = $conn;
    $use_mysqli = true;
} elseif (isset($mysqli) && $mysqli instanceof mysqli) {
    // some projects name it $mysqli
    $use_mysqli = true;
} else {
    // try creating PDO if constants are defined in db.php
    if (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER') && defined('DB_PASS')) {
        try {
            $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            $use_pdo = true;
        } catch (Exception $e) {
            // leave both false and we'll throw an explicit error below
        }
    }
}

if (!$use_pdo && !$use_mysqli) {
    die("Database connection not found. Please ensure ../inc/db.php creates either a PDO instance in \$pdo or a mysqli instance in \$conn / \$mysqli, or define DB_HOST / DB_NAME / DB_USER / DB_PASS constants.");
}

/* Helper wrappers so the rest of the code can use the same functions */
function db_query_all($sql, $params = []) {
    global $use_pdo, $use_mysqli, $pdo, $mysqli;

    if ($use_pdo) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($use_mysqli) {
        if (!empty($params)) {
            // Prepare statement
            $stmt = $mysqli->prepare($sql);
            if ($stmt === false) die("MySQL prepare error: " . $mysqli->error);

            // Bind all parameters as strings (simplest)
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
            
            $stmt->execute();
            $res = $stmt->get_result();
            $rows = [];
            while ($r = $res->fetch_assoc()) $rows[] = $r;
            $stmt->close();
            return $rows;
        } else {
            // No parameters, safe to use query()
            $res = $mysqli->query($sql);
            $rows = [];
            if ($res) {
                while ($r = $res->fetch_assoc()) $rows[] = $r;
            }
            return $rows;
        }
    } else {
        die("No database connection.");
    }
}
function db_prepare_execute($sql, $params = []) {
    global $use_pdo, $use_mysqli, $pdo, $mysqli;

    if ($use_pdo) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt; // PDOStatement object
    } elseif ($use_mysqli) {
        $stmt = $mysqli->prepare($sql);
        if ($stmt === false) die("MySQL prepare error: " . $mysqli->error);

        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        return $stmt; // MySQLi statement
    } else {
        die("No database connection available.");
    }
}


// ----------------- DEFAULT POSITIONS -----------------
$default_positions = [
    ['name' => 'PRESIDENT', 'grade_level' => 'Incoming Gr. 11–12'],
    ['name' => 'VICE PRESIDENT', 'grade_level' => 'Incoming Gr. 11–12'],
    ['name' => 'SECRETARY', 'grade_level' => 'Incoming Gr. 8–12'],
    ['name' => 'TREASURER', 'grade_level' => 'Incoming Gr. 8–12'],
    ['name' => 'AUDITOR', 'grade_level' => 'Incoming Gr. 8–12'],
    ['name' => 'PUBLIC INFORMATION OFFICER', 'grade_level' => 'Incoming Gr. 8–12'],
    ['name' => 'PROTOCOL OFFICER', 'grade_level' => 'Incoming Gr. 8–12'],
    ['name' => 'GRADE 8 REPRESENTATIVE ', 'grade_level' => 'Gr. 8'],
   // ['name' => 'GRADE 8 REPRESENTATIVE 2', 'grade_level' => 'Gr. 8'],
    ['name' => 'GRADE 9 REPRESENTATIVE ', 'grade_level' => 'Gr. 9'],
   // ['name' => 'GRADE 9 REPRESENTATIVE 2', 'grade_level' => 'Gr. 9'],
    ['name' => 'GRADE 10 REPRESENTATIVE ', 'grade_level' => 'Gr. 10'],
   // ['name' => 'GRADE 10 REPRESENTATIVE 2', 'grade_level' => 'Gr. 10'],
    ['name' => 'GRADE 11 REPRESENTATIVE ', 'grade_level' => 'Gr. 11'],
   // ['name' => 'GRADE 11 REPRESENTATIVE 2', 'grade_level' => 'Gr. 11'],
    ['name' => 'GRADE 12 REPRESENTATIVE ', 'grade_level' => 'Gr. 12'],
   // ['name' => 'GRADE 12 REPRESENTATIVE 2', 'grade_level' => 'Gr. 12'],
];

// Fetch elections and partylists
$elections = db_query_all("SELECT * FROM elections ORDER BY id DESC");
$partylists = db_query_all("SELECT * FROM partylist ORDER BY name ASC");

// Choose selected election
$selected_election_id = $_GET['election_id'] ?? ($elections[0]['id'] ?? null);

// Check positions for this election
if ($selected_election_id) {
    $positions = db_query_all("SELECT * FROM positions WHERE election_id = ? ORDER BY position_order ASC", [$selected_election_id]);

    // Auto-insert defaults if empty
    if (empty($positions)) {
        foreach ($default_positions as $i => $pos) {
            db_prepare_execute(
                "INSERT INTO positions (election_id, name, position_order) VALUES (?, ?, ?)",
                [$selected_election_id, $pos['name'], $i+1]
            );
        }
        $positions = db_query_all("SELECT * FROM positions WHERE election_id = ? ORDER BY position_order ASC", [$selected_election_id]);
        
// Add this after fetching $positions
$position_grades = [
    'PRESIDENT' => ['Incoming Gr. 11', 'Incoming Gr. 12'],
    'VICE PRESIDENT' => ['Incoming Gr. 11', 'Incoming Gr. 12'],
    'SECRETARY' => ['Incoming Gr. 8', 'Incoming Gr. 9', 'Incoming Gr. 10', 'Incoming Gr. 11', 'Incoming Gr. 12'],
    'TREASURER' => ['Incoming Gr. 8', 'Incoming Gr. 9', 'Incoming Gr. 10', 'Incoming Gr. 11', 'Incoming Gr. 12'],
    'AUDITOR' => ['Incoming Gr. 8', 'Incoming Gr. 9', 'Incoming Gr. 10', 'Incoming Gr. 11', 'Incoming Gr. 12'],
    'PUBLIC INFORMATION OFFICER' => ['Incoming Gr. 8', 'Incoming Gr. 9', 'Incoming Gr. 10', 'Incoming Gr. 11', 'Incoming Gr. 12'],
    'PROTOCOL OFFICER' => ['Incoming Gr. 8', 'Incoming Gr. 9', 'Incoming Gr. 10', 'Incoming Gr. 11', 'Incoming Gr. 12'],
    'GRADE 8 REPRESENTATIVE ' => ['Gr. 8'],
    'GRADE 9 REPRESENTATIVE ' => ['Gr. 9'],
    'GRADE 10 REPRESENTATIVE ' => ['Gr. 10'],
    'GRADE 11 REPRESENTATIVE ' => ['Gr. 11'],
    'GRADE 12 REPRESENTATIVE ' => ['Gr. 12'],
];


    }
    
} else {
    $positions = [];
}

/* ---------- Handle form submissions ---------- */

// Add Partylist
if (isset($_POST['save_partylist'])) {
    $name = trim($_POST['partylist_name'] ?? '');
    $independent = isset($_POST['is_independent']) ? 1 : 0;
    if ($name !== '') {
        $sql = "INSERT INTO partylist (name, is_independent, created_at) VALUES (?, ?, NOW())";
        db_prepare_execute($sql, [$name, $independent]);
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// // Add Position
// if (isset($_POST['save_position'])) {
//     $election = $_POST['election_id'] ?? null;
//     $position = trim($_POST['position_name'] ?? '');
//     $partylist = ($_POST['partylist_id'] ?? '') === '' ? null : $_POST['partylist_id'];
//     if ($position !== '' && $election) {
//         $sql = "INSERT INTO positions (election_id, name, partylist_id) VALUES (?, ?, ?)";
//         db_prepare_execute($sql, [$election, $position, $partylist]);
//         header("Location: " . $_SERVER['PHP_SELF']);
//         exit();
//     }
// }

// ---------- Add Candidate ----------
if (isset($_POST['save_candidate'])) {
    $student_id = trim($_POST['student_id'] ?? '');
    $position   = $_POST['position_id'] ?? null;
    $partylist  = $_POST['partylist_id'] ?? null;
    $bio        = trim($_POST['biography'] ?? '');

    // Validate student exists
    $voter = db_prepare_execute("SELECT * FROM voters WHERE student_id = ?", [$student_id]);
    if ($use_pdo) {
        $voter = $voter->fetch(PDO::FETCH_ASSOC);
    } else {
        $voter = $voter->get_result()->fetch_assoc();
    }

    if (!$voter) {
        die("Error: Student not found in voters database.");
    }

    // Prevent duplicate candidate
    if ($voter['is_candidate']) {
        die("Error: This student is already registered as a candidate.");
    }

    // Handle photo upload
    $photo_name = null;
    if (!empty($_FILES['photo']['name'])) {
        $upload_dir = __DIR__ . '/uploads';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        $original = basename($_FILES['photo']['name']);
        $ext = pathinfo($original, PATHINFO_EXTENSION);
        $photo_name = time() . '_' . preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $original);
        $target = $upload_dir . '/' . $photo_name;
        if (!move_uploaded_file($_FILES['photo']['tmp_name'], $target)) {
            $photo_name = null; // upload failed
        }
    }

    // Insert into candidates table
    $grade_section = $voter['grade_level'] . ' / ' . $voter['strand'] . ' ' . $voter['section'];
    $sql = "INSERT INTO candidates (student_id, grade_section, firstname, lastname, position_id, partylist_id, biography, photo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    db_prepare_execute($sql, [
        $student_id,
        $grade_section,
        $voter['firstname'],
        $voter['lastname'],
        $position,
        $partylist,
        $bio,
        $photo_name
    ]);

    // Mark voter as candidate
    db_prepare_execute("UPDATE voters SET is_candidate = 1 WHERE student_id = ?", [$student_id]);

    // Redirect back
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

/* ---------- Fetch data for display ---------- */
$candidates = db_query_all("
    SELECT c.*, 
           v.firstname, 
           v.lastname, 
           CONCAT(v.grade_level, ' / ', v.strand, ' ', v.section) AS grade_section,
           p.name AS position_name, 
           pl.name AS partylist_name
    FROM candidates c
    JOIN voters v ON c.student_id = v.student_id
    LEFT JOIN positions p ON c.position_id = p.id
    LEFT JOIN partylist pl ON c.partylist_id = pl.id
    ORDER BY c.id DESC
");

$total_candidates = count($candidates);
$elections = db_query_all("SELECT * FROM elections ORDER BY id DESC");
$partylists = db_query_all("SELECT * FROM partylist ORDER BY name ASC");
$positions = db_query_all("SELECT * FROM positions ORDER BY position_order ASC, name ASC");


?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Manage Candidates</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin_responsive.css">
  <link rel="stylesheet" href="admin_candidates.css">
  <style>


  /* === GENERAL MODAL STYLES === */
  .modal {
    display: none;
    position: fixed;
    z-index: 999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    justify-content: center;
    align-items: center;
    overflow-y: auto; /* ✅ allows scrolling when form is long */
    padding: 20px;
  }

  .modal-content {
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    width: 100%;
    max-width: 480px; /* ✅ keeps modal a good size */
    max-height: 90vh; /* ✅ prevents fullscreen overflow */
    overflow-y: auto; /* ✅ scrollable inside */
    box-shadow: 0 5px 25px rgba(0,0,0,0.3);
    animation: fadeIn 0.25s ease-in-out;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* === FORM ELEMENTS === */
  .form-group { margin-bottom: 12px; }
  label { display:block; margin-bottom:5px; font-weight:600; }
  input, select, textarea {
    width:100%;
    padding:8px;
    border-radius:6px;
    border:1px solid #ccc;
    font-size:14px;
  }
  textarea { resize: vertical; }

  .modal-buttons {
    display:flex;
    gap:10px;
    justify-content:flex-end;
    margin-top:15px;
  }

  .btn {
    padding:8px 12px;
    border-radius:6px;
    border:none;
    cursor:pointer;
    font-size:14px;
  }
  .btn-save { background:#1b4fff; color:#fff; }
  .btn-cancel { background:#777; color:#fff; }

  .profile-img {
    width:48px;
    height:48px;
    border-radius:50%;
    object-fit:cover;
  }

  table.candidate-table {
    width:100%;
    border-collapse:collapse;
  }
  table.candidate-table th,
  table.candidate-table td {
    padding:10px;
    border-bottom:1px solid #eee;
    text-align:left;
  }

  /* === RESPONSIVE (MOBILE) === */
  @media (max-width: 600px) {
    .modal-content {
      width: 100%;
      max-width: 95%;
      border-radius: 12px;
      padding: 16px;
    }
    /* Flex container for action buttons */
.action-buttons {
  display: flex !important; /* force flex */
  gap: 8px;                 /* space between buttons */
  justify-content: flex-start; /* align left */
  align-items: center;        /* vertical alignment */
}

/* Optional: make buttons uniform size */
.action-buttons .btn {
  flex-shrink: 0;        /* prevent shrinking */
  padding: 6px 10px;
  font-size: 14px;
}
.candidate-table td:last-child {
  white-space: nowrap; /* prevent wrapping */
}

    
  }
</style>

</head>
<body style="margin:0;font-family:Poppins, sans-serif;background:#f1f5f9;">

<!-- SIDE PANEL -->
<div style="
width:240px;
height:100vh;
position:fixed;
top:0;
left:0;
background:linear-gradient(180deg,#0f172a,#1e293b);
padding-top:20px;
box-shadow:4px 0 15px rgba(0,0,0,0.4);
color:white;
">

<div style="text-align:center;margin-bottom:30px;">
<img src="srnhs-logo.png" style="width:70px;">
<h3 style="margin-top:10px;">SRNHS Moderator</h3>
</div>

<div style="display:flex;flex-direction:column;gap:10px;padding:0 15px;">

<div class="nav-btn" onclick="location.href='dashboard.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg> Dashboard</div>
<div class="nav-btn active" onclick="location.href='candidates.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z"/></svg> Candidates</div>
<div class="nav-btn" onclick="location.href='voters.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18q30 0 58.5 3t55.5 9l-70 70q-11-2-21.5-2H400q-71 0-127.5 17T180-306q-9 5-14.5 14t-5.5 20v32h250l80 80H80Zm542 16L484-282l56-56 82 82 202-202 56 56-258 258ZM287-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47Zm123 287Zm46.5-343.5Q480-607 480-640t-23.5-56.5Q433-720 400-720t-56.5 23.5Q320-673 320-640t23.5 56.5Q367-560 400-560t56.5-23.5ZM400-640Z"/></svg> Voters</div>
<div class="nav-btn" onclick="location.href='reports.php'"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-280h80v-200h-80v200Zm320 0h80v-400h-80v400Zm-160 0h80v-120h-80v120Zm0-200h80v-80h-80v80ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg> Reports</div>

<div class="nav-btn logout-btn"
onclick="if(confirm('Are you sure you want to log out?')) location.href='logout.php'">
<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Logout
</div>

</div>
</div>

<style>
.nav-btn{
padding:12px 15px;
border-radius:10px;
cursor:pointer;
background:#1e293b;
transition:0.25s;
font-weight:500;
}

.nav-btn:hover{
background:#334155;
transform:translateX(5px);
}

.nav-btn.active{
background:#3b82f6;
box-shadow:0 0 10px rgba(59,130,246,0.7);
}

.logout-btn{
background:#7f1d1d;
}

.logout-btn:hover{
background:#991b1b;
}
</style>

<!-- MAIN CONTENT -->
<div style="margin-left:260px;padding:30px;width:100%;">



    <section class="dashboard">
      <h3>Manage Candidates</h3>

      <div class="button-group" style="margin-bottom:16px;justify-content:flex-end;">
        <button class="btn btn-save" onclick="openModal('partylistModal')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M440-280h80v-160h160v-80H520v-160h-80v160H280v80h160v160Zm40 200q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg> Add Partylist</button>
        <!-- <button class="btn btn-save" onclick="openModal('positionModal')">➕ Add Position</button> -->
        <button class="btn btn-save" onclick="openModal('candidateModal')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M440-280h80v-160h160v-80H520v-160h-80v160H280v80h160v160Zm40 200q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg> Add Candidate</button>
      </div>
       <div class="total-voters" style="margin-bottom:18px;">
    <h3>Total Candidates</h3>
    <p style="font-size:28px;font-weight:700;"><?= $total_candidates ?></p>
  </div>
      <!-- Search Bar -->
<div class="search-bar-container" style="margin-bottom:20px;">
  <div class="search-wrapper" style="display:flex; align-items:center; gap:8px; max-width:400px;">
    <input type="text" id="searchInput" placeholder="🔍 Search by Student ID, Name, Position or Partylist..." 
           style="flex:1; padding:8px 10px; border:1px solid #ccc; border-radius:6px;">
    <button id="resetSearch" class="btn btn-cancel" style="padding:8px 12px;">Reset</button>
  </div>
</div>


  <div class="candidate-table-wrapper">

  <table class="candidate-table">
    <thead>
      <tr>
        <th>Photo</th>
        <th>Student ID</th>
        <th>Name</th>
        <th>Grade/Section</th>
        <th>Position</th>
        <th>Partylist</th>
        <th>Biography</th>
        <!-- <th>Status</th> -->
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($total_candidates === 0): ?>
        <tr><td colspan="8" style="text-align:center;padding:22px;">No candidates yet.</td></tr>
      <?php else: foreach ($candidates as $c): ?>
        <tr>
          <td>
            <?php if (!empty($c['photo']) && file_exists(__DIR__ . '/uploads/' . $c['photo'])): ?>
              <img src="uploads/<?= htmlspecialchars($c['photo']) ?>" class="profile-img" alt="">
            <?php else: ?>
              <img src="images/default.png" class="profile-img" alt="">
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($c['student_id']) ?></td>
          <td><?= htmlspecialchars($c['firstname'] . ' ' . $c['lastname']) ?></td>
          <td><?= htmlspecialchars($c['grade_section']) ?></td>
          <td><?= htmlspecialchars($c['position_name']) ?></td>
          <td><?= htmlspecialchars($c['partylist_name']) ?></td>
          <td style="max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
            <?= htmlspecialchars($c['biography']) ?>
          </td>
          
           <td>
  <div class="action-buttons">
    <button class="btn btn-edit" data-id="<?= $c['id'] ?>">✏️</button>
    <!-- <button class="btn btn-archive" data-id="<?= $c['id'] ?>">📦</button> -->
  </div>
</td>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

</div>

    </section>
  </div>

  <!-- Partylist modal -->
  <div class="modal" id="partylistModal">
    <div class="modal-content">
      <h3>Add Partylist</h3>
      <form method="POST">
        <div class="form-group">
          <label>Partylist Name</label>
          <input type="text" name="partylist_name" required>
        </div>
        <div class="form-group">
          <label><input type="checkbox" name="is_independent"> Independent Candidate</label>
        </div>
        <div class="modal-buttons">
          <button type="submit" name="save_partylist" class="btn btn-save">Save</button>
          <button type="button" class="btn btn-cancel" onclick="closeModal('partylistModal')">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Position modal -->
  <div class="modal" id="positionModal">
    <div class="modal-content">
      <h3>Add Position</h3>
      <form method="POST">
        <div class="form-group">
          <label>Select Election</label>
          <select name="election_id" required>
            <?php foreach ($elections as $e): ?>
              <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['title'] . ' (' . $e['school_year'] . ')') ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Position Name</label>
          <input type="text" name="position_name" required>
        </div>
        <div class="form-group">
          <label>Partylist (optional)</label>
          <select name="partylist_id">
            <option value="">-- None --</option>
            <?php foreach ($partylists as $p): ?>
              <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="modal-buttons">
          <button type="submit" name="save_position" class="btn btn-save">Save</button>
          <button type="button" class="btn btn-cancel" onclick="closeModal('positionModal')">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Candidate modal -->
  <div class="modal" id="candidateModal">
    <div class="modal-content">
      <h3>Add Candidate</h3>
      <form method="POST" enctype="multipart/form-data">
        <div class="form-group"><label>Student ID</label><input type="text" name="student_id" required><small id="student-warning" style="color:red; font-weight:600; display:none; margin-top:4px;"></small></div>
        <div class="form-group"><label>Grade/Strand & Section</label><input type="text" name="grade"></div>
        <div class="form-group"><label>First Name</label><input type="text" name="firstname" required></div>
        <div class="form-group"><label>Last Name</label><input type="text" name="lastname" required></div>
        <div class="form-group">
          <label>Position</label>
          <select name="position_id" required>
  <?php foreach ($positions as $i => $pos): ?>
    <option value="<?= $pos['id'] ?>" <?= $i===0?'selected':'' ?>><?= htmlspecialchars($pos['name']) ?></option>
  <?php endforeach; ?>
</select>

        </div>
        <div class="form-group">
          <label>Partylist</label>
          <select name="partylist_id" required>
            <option value="">-- Select Partylist --</option>
            <?php foreach ($partylists as $p): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group"><label>Biography</label><textarea name="biography" rows="3"></textarea></div>
        <div class="form-group"><label>Photo</label><input type="file" name="photo" accept="image/*"></div>
        <div class="modal-buttons">
          <button type="submit" name="save_candidate" class="btn btn-save">Save</button>
          <button type="button" class="btn btn-cancel" onclick="closeModal('candidateModal')">Cancel</button>
        </div>
      </form>
    </div>
  </div>
  <!-- Edit Candidate Modal -->
<div class="modal" id="editCandidateModal">
  <div class="modal-content">
    <h3>Edit Candidate</h3>
    <form id="editCandidateForm">
      <input type="hidden" name="id">
      <div class="form-group"><label>First Name</label><input type="text" name="firstname" required></div>
      <div class="form-group"><label>Last Name</label><input type="text" name="lastname" required></div>
      <div class="form-group"><label>Grade/Section</label><input type="text" name="grade_section"></div>
      <div class="form-group">
        <label>Position</label>
        <select name="position_id" required>
          <option value="">-- Select Position --</option>
          <?php foreach ($positions as $pos): ?>
            <option value="<?= $pos['id'] ?>"><?= htmlspecialchars($pos['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Partylist</label>
        <select name="partylist_id" required>
          <option value="">-- Select Partylist --</option>
          <?php foreach ($partylists as $p): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>Biography</label><textarea name="biography" rows="3"></textarea></div>
      <div class="modal-buttons">
        <button type="submit" class="btn btn-save">Save Changes</button>
        <button type="button" class="btn btn-cancel" onclick="closeModal('editCandidateModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

    <script>
function openModal(id) {
  const modal = document.getElementById(id);
  modal.style.display = 'flex';
  const content = modal.querySelector('.modal-content');
  if (content) content.scrollTop = 0;
}

function closeModal(id) {
  const modal = document.getElementById(id);
  modal.style.display = 'none';

  // ✅ Reset form fields
  const form = modal.querySelector('form');
  if (form) form.reset();

  // ✅ Scroll back to top
  const content = modal.querySelector('.modal-content');
  if (content) content.scrollTop = 0;

  // ✅ Remove warnings and re-enable inputs
  const warningBox = modal.querySelector('#student-warning');
  const studentInput = modal.querySelector("input[name='student_id']");
  const saveButton = modal.querySelector("button[name='save_candidate']");
  const otherFields = modal.querySelectorAll(
    "input[name='grade'], input[name='firstname'], input[name='lastname'], select, textarea, input[name='photo']"
  );

  if (warningBox) {
    warningBox.style.display = 'none';
    warningBox.textContent = '';
  }
  if (studentInput) studentInput.style.borderColor = '';
  if (saveButton) saveButton.disabled = false;

  // ✅ Re-enable all fields
  otherFields.forEach(el => el.disabled = false);
}

window.onclick = function(e) {
  document.querySelectorAll('.modal').forEach(function(m) {
    if (e.target === m) {
      closeModal(m.id);
    }
  });
};

// === AUTO-FILL STUDENT DETAILS (with in-modal warning & disable fields) ===
document.addEventListener("DOMContentLoaded", function() {
  const modal = document.querySelector("#candidateModal");
  const studentInput = modal.querySelector("input[name='student_id']");
  const gradeInput   = modal.querySelector("input[name='grade']");
  const fnameInput   = modal.querySelector("input[name='firstname']");
  const lnameInput   = modal.querySelector("input[name='lastname']");
  const warningBox   = modal.querySelector("#student-warning");
  const saveButton   = modal.querySelector("button[name='save_candidate']");
  const otherFields  = modal.querySelectorAll(
    "input[name='grade'], input[name='firstname'], input[name='lastname'], select, textarea, input[name='photo']"
  );

  function showWarning(msg) {
    warningBox.textContent = msg;
    warningBox.style.display = "block";
    studentInput.style.borderColor = "red";
    saveButton.disabled = true;
    // ✅ Disable all other fields
    otherFields.forEach(el => el.disabled = true);
  }

  function clearWarning() {
    warningBox.textContent = "";
    warningBox.style.display = "none";
    studentInput.style.borderColor = "";
    saveButton.disabled = false;
    // ✅ Enable all other fields
    otherFields.forEach(el => el.disabled = false);
  }

  studentInput.addEventListener("blur", function() {
    const id = studentInput.value.trim();
    if (id === '') {
      clearWarning();
      gradeInput.value = '';
      fnameInput.value = '';
      lnameInput.value = '';
      return;
    }

    fetch('fetch_student.php?student_id=' + encodeURIComponent(id))
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          clearWarning();
          gradeInput.value = data.grade_section || '';
          fnameInput.value = data.firstname || '';
          lnameInput.value = data.lastname || '';
        } else {
          gradeInput.value = '';
          fnameInput.value = '';
          lnameInput.value = '';
          showWarning(data.error || "Student not found in voters list.");
        }
      })
      .catch(() => {
        showWarning("Error fetching student data.");
      });
  });

  // ✅ Clear warning & re-enable fields when cancel is clicked
  document.querySelectorAll('.btn-cancel').forEach(btn => {
    btn.addEventListener('click', clearWarning);
  });
});
// === CANDIDATE TABLE SEARCH FUNCTION ===
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('searchInput');
  const resetSearch = document.getElementById('resetSearch');
  const rows = document.querySelectorAll('.candidate-table tbody tr');

  function normalize(text) {
    return text ? text.toLowerCase().trim() : '';
  }

  function filterTable() {
    const query = normalize(searchInput.value);

    rows.forEach(row => {
      const studentId = normalize(row.children[1]?.textContent);
      const name = normalize(row.children[2]?.textContent);
      const position = normalize(row.children[4]?.textContent);
      const partylist = normalize(row.children[5]?.textContent);

      // Check if any field matches the query
      const matches = 
        studentId.includes(query) || 
        name.includes(query) || 
        position.includes(query) || 
        partylist.includes(query);

      row.style.display = matches ? '' : 'none';
    });
  }

  searchInput.addEventListener('input', filterTable);

  resetSearch.addEventListener('click', () => {
    searchInput.value = '';
    filterTable();
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const editButtons = document.querySelectorAll('.btn-edit');
  const archiveButtons = document.querySelectorAll('.btn-archive');
  const editModal = document.getElementById('editCandidateModal');
  const editForm = document.getElementById('editCandidateForm');

  // --- OPEN EDIT MODAL ---
  editButtons.forEach(btn => {
    btn.addEventListener('click', e => {
      const row = e.target.closest('tr');
      const cells = row.children;

      editForm.id.value = btn.dataset.id;
      editForm.firstname.value = cells[2].textContent.split(' ')[0];
      editForm.lastname.value = cells[2].textContent.split(' ')[1] || '';
      editForm.grade_section.value = cells[3].textContent;
      editForm.position_id.value = [...editForm.position_id.options]
        .find(o => o.text === cells[4].textContent)?.value || '';
      editForm.partylist_id.value = [...editForm.partylist_id.options]
        .find(o => o.text === cells[5].textContent)?.value || '';
      editForm.biography.value = cells[6].textContent;

      openModal('editCandidateModal');
    });
  });

  // --- SUBMIT EDIT FORM ---
  editForm.addEventListener('submit', async e => {
    e.preventDefault();
    const formData = new FormData(editForm);

    try {
      const res = await fetch('update_candidate.php', { method: 'POST', body: formData });
      const text = await res.text();

      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error("Invalid response from server:\n" + text);
      }

      if (data.success) {
        alert('Candidate updated successfully.');
        location.reload();
      } else {
        alert('Update failed: ' + (data.message || 'Unknown error'));
      }
    } catch (err) {
      alert('Error updating candidate:\n' + err.message);
    }
  });

  // // --- ARCHIVE CANDIDATE ---
  // archiveButtons.forEach(btn => {
  //   btn.addEventListener('click', async () => {
  //     if (!confirm('Archive this candidate?')) return;

  //     try {
  //       const res = await fetch('archive_candidate.php', {
  //         method: 'POST',
  //         headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  //         body: 'id=' + encodeURIComponent(btn.dataset.id)
  //       });
  //       const text = await res.text();

  //       let data;
  //       try {
  //         data = JSON.parse(text);
  //       } catch {
  //         throw new Error("Invalid response from server:\n" + text);
  //       }

  //       if (data.success) {
  //         alert('Candidate archived.');
  //         // Update the status cell immediately without reload
  //         const row = btn.closest('tr');
  //         const statusCell = row.children[7]; // Status column
  //         statusCell.innerHTML = '<span style="color:#fff; background:#777; padding:2px 6px; border-radius:4px; font-size:12px;">Archived</span>';
  //       } else {
  //         alert('Error: ' + (data.message || 'Unknown error'));
  //       }
  //     } catch (err) {
  //       alert('Archive failed:\n' + err.message);
  //     }
  //   });
  // });
});


</script>
</body>
</html>
